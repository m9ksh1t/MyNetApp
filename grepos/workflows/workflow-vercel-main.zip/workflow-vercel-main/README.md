# Reusable Workflow
Reusable workflow to deploy vercel projects

## Usage

```yaml
name: Deploy Vercel Project

on:
   workflow_dispatch:

jobs:
  deploy:
    uses: BHGitOps/workflow-vercel/.github/workflows/workflow.yml@v2.0.2
    with: 
      deploy-runner-type: '[value]' 
      deploy-environment: '[value]'
      framework-type: '[value]'
      framework-version: '[value]'
      vercel-version: 'latest'
      working-directory: '[value]'
      vercel-environment: '[value]'
      deploy-prod: [value]
    secrets:
      VERCEL_TOKEN: ${{ secrets.VERCEL_TOKEN }}
      VERCEL_ORG_ID: ${{ secrets.VERCEL_ORG_ID }}
      VERCEL_PROJECT_ID: ${{ secrets.VERCEL_PROJECT_ID }}

```
