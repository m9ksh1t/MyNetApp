<h1 align="center">
  <a href=".github/workflows/workflow.yml">workflow-k8s-secret-handler-aks</a>
</h1>

## Overview
This GitHub Actions workflow provides a reusable solution for managing Kubernetes secrets in **Azure AKS**. It supports fetching secrets from multiple sources—including **CyberArk Conjur, GitHub Secrets, and Azure Key Vault** and deploying them as **Kubernetes Secrets** with support for **Generic and TLS types**. The workflow also enables secure deletion of existing Kubernetes secrets.

The workflow seamlessly integrates with Azure AKS for authentication, kubectl installation, and secret management, ensuring secure handling of sensitive data throughout the deployment lifecycle.

---

## Getting Started

These documents will help you get up to speed with our engineering practices and tools.

## Reusable Workflow Summary

The table outlines the essential details of the reusable Kubernetes secret management workflow, including its name, current stable version, supported cloud environment and services, compatible integration sources, and confirmation of Conjur integration.

| Workflow Name | [**workflow-k8s-secret-handler-aks**](.github/workflows/workflow.yml) |
| :------| :-------------|
| **Latest Stable Version** | v1 |
| **Current Version** | v1 |
| **Cloud Environment** | Azure AKS |
| **Cloud Services** | Azure Kubernetes Service (AKS), Azure Keyvault |
| **Secret Sources** | CyberArk Conjur, GitHub Secrets, Azure Key Vault |
| **Secret Types** | Generic Kubernetes Secrets, TLS Secrets |
| **Is Conjur integrated** | Yes (optional) |
| **High Availability Supported** | Yes |

---

## Mock Caller Workflows

A mock workflow, shown below, provides a solid starting point for implementing this reusable workflow. Refer to the table below for the list of available caller workflows.

| Mock Repository URL | Purpose |
|------------------|-------------|
| [**mock-k8s-secrets**](https://github.com/BHGitOps/mock-k8s-secrets.git) | Provides a reference implementation for deploying Kubernetes secrets to AKS using this reusable workflow |

> **Tip:** In the mock repository, you can find examples of how to invoke this reusable workflow for different secret operations and management scenarios.

---

## Features
- Fetch secrets securely from **CyberArk Conjur** using appliance URL, account, and credentials.
- Create **Generic** and **TLS** Kubernetes Secrets from multiple sources (GitHub Secrets, Conjur, Azure Key Vault).
- **Delete** Kubernetes secrets by name (full secret or selected keys).
- Secure authentication using **Azure Service Principal** for AKS access.
- Flexible secret operations via `secret-operation` parameter (`create-generic-secret`, `conjur-to-generic-secret`, `create-tls-secret`, `conjur-to-tls-secret`, `create-keyvault-secret`, `delete-k8s-secret`).
- Automated runner workspace cleanup after execution.
- Support for multiple secret sources and deployment strategies.
- Seamless Azure AKS cluster authentication and kubectl integration.

## Usage

**Current Version:** `v1`

To use this workflow in your repository:

```yaml
jobs:
  manage-k8s-secrets:
    uses: BHGitOps/workflow-k8s-secret-handler-aks/.github/workflows/workflow.yml@v1
    with:
      cluster-type: "aks"
      deploy-environment: "dev"
      deploy-runner-type: "ubuntu-latest"
      azure-resource-group: "my-resource-group"
      cluster-name: "my-aks-cluster"
      namespace: "default"
      secret-name: "my-k8s-secret"
      secret-operation: "create-generic-secret"
      keyvault-name: "my-keyvault"
      conjur-variable-json: |
        {
          "CApp_DSO_Dev": {
            "dso-conjur-secret1": "DSO_CONJUR_SECRET1",
            "conjursecret3": "CONJURSECRET3"         
          },
          "CApp_GitOrgSecrets": {
            "GitHub-WIZ_CLIENT_ID": "WIZ_CLIENT_ID",
            "GitHub-WIZ_CLIENT_SECRET": "WIZ_CLIENT_SECRET"
          }
        }
    secrets:
      github-token: ${{ secrets.GITHUB_TOKEN }}
      conjur-appliance-url: ${{ secrets.conjur_appliance_url }}
      conjur-account: ${{ secrets.conjur_account }}
      conjur-workload-id: ${{ secrets.conjur_workload_id }}
      conjur-api-key: ${{ secrets.conjur_api_key }}
      secrets-json: |
        {
          "DB_USER": "${{ secrets.DB_USER }}",
          "DB_PASS": "${{ secrets.DB_PASS }}"
        }
      tls-cert: "${{ secrets.TLS_CERT }}"
      tls-key: "${{ secrets.TLS_KEY }}"
      client-id: "${{ secrets.AZURE_CLIENT_ID }}"
      tenant-id: "${{ secrets.AZURE_TENANT_ID }}"
      subscription-id: "${{ secrets.AZURE_SUBSCRIPTION_ID }}"
```

---

## Inputs

| Name | Description | Required | Type | Default |
|------|-------------|----------|------|---------|
| `cluster-type` | Choose Kubernetes cluster deployment type (e.g., `aks`) | ✅ | `string` | - |
| `deploy-environment` | Target deployment environment (e.g., `dev`, `qa`, `prod`) | ✅ | `string` | - |
| `deploy-runner-type` | GitHub Actions runner type (e.g., `ubuntu-latest`, `self-hosted`) | ✅ | `string` | `ubuntu-latest` |
| `secret-name` | Unique name for the Kubernetes secret to create/update/delete | ✅ | `string` | - |
| `namespace` | Kubernetes namespace where the secret will be deployed | ✅ | `string` | - |
| `secret-operation` | Operation to perform: `create-generic-secret`, `conjur-to-generic-secret`, `create-tls-secret`, `conjur-to-tls-secret`, `create-keyvault-secret`, `delete-k8s-secret` | ✅ | `string` | - |
| `cluster-name` | Name of the Kubernetes cluster (AKS) | ✅ | `string` | - |
| `secrets-keys` | Comma-separated list of secret keys to include in the Kubernetes secret | ❌ | `string` | - |
| `keyvault-name` | Azure Key Vault name | ❌ | `string` | - |
| `azure-resource-group` | Azure Resource Group name | ❌ | `string` | - |
| `conjur-variable-json` | JSON file mapping vaults and secrets to fetch from Conjur | ❌ | `string` | - |

---

## Secrets

| Name | Description | Required |
|------|-------------|----------|
| `github-token` | GitHub token used for authentication when accessing GitHub Packages | ❌ |
| `conjur-appliance-url` | Base URL of the Conjur appliance used for secret retrieval | ❌ |
| `conjur-account` | Name of the Conjur account that holds the secrets | ❌ |
| `conjur-workload-id` | Unique identifier for the workload or host in Conjur | ❌ |
| `conjur-api-key` | API key associated with the Conjur workload ID | ❌ |
| `secrets-json` | JSON object containing secret values from GitHub Secrets | ❌ |
| `tls-cert` | TLS certificate (PEM format) for creating TLS secrets | ❌ |
| `tls-key` | TLS private key (PEM format) for creating TLS secrets | ❌ |
| `client-id` | Azure Service Principal Client ID for AKS authentication | ❌ |
| `subscription-id` | Azure Subscription ID where resources are deployed | ❌ |
| `tenant-id` | Azure Active Directory Tenant ID for Service Principal authentication | ❌ |

---

## Jobs & Steps

### Actions Reference

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checkout repository code |
| [**action-conjur-fetch-secrets**](https://github.com/BHGitOps/action-conjur-fetch-secrets) | Securely fetch secrets from CyberArk Conjur using API key authentication |
| [**action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Authenticate to Azure using Service Principal credentials |
| [**action-azure-install-cli**](https://github.com/BHGitOps/action-azure-install-cli) | Install Azure CLI for resource management |
| [**action-install-kubectl**](https://github.com/BHGitOps/action-install-kubectl) | Download and install kubectl for Kubernetes cluster management |
| [**action-authenticate-aks**](https://github.com/BHGitOps/action-authenticate-aks) | Configure kubectl access to Azure AKS cluster |
| [**action-gh-secrets-to-k8s**](https://github.com/BHGitOps/action-gh-secrets-to-k8s) | Create generic Kubernetes secrets from GitHub Secrets JSON payload |
| [**action-conjur-k8s-secret**](https://github.com/BHGitOps/action-conjur-k8s-secret) | Create generic Kubernetes secrets from Conjur secrets |
| [**action-k8s-tls-cert**](https://github.com/BHGitOps/action-k8s-tls-cert) | Create TLS Kubernetes secrets from certificate and key in GitHub Secrets |
| [**action-conjur-k8s-tls-secret**](https://github.com/BHGitOps/action-conjur-k8s-tls-secret) | Create TLS Kubernetes secrets from Conjur-managed certificates and keys |
| [**action-azure-keyvault-to-k8s**](https://github.com/BHGitOps/action-azure-keyvault-to-k8s) | Create Kubernetes secrets by retrieving values from Azure Key Vault |
| [**action-delete-k8s-secrets**](https://github.com/BHGitOps/action-delete-k8s-secrets) | Delete Kubernetes secrets or selected keys from a namespace |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Clean up artifacts and workspace after workflow execution |

---

### AKS Job (`cluster-type == 'aks'`)
The workflow executes the following steps when deploying to Azure AKS:

- **Checkout** (`BHGitOps/action-checkout@v2.1.0`)
  - Checks out the repository code

- **Fetch Secret from CyberArk Conjur** (`BHGitOps/action-conjur-fetch-secrets@v2`)
  - Conditionally executed if `conjur-variable-json` is provided
  - Retrieves secrets from Conjur appliance

- **Login to Azure** (`BHGitOps/action-azlogin@v1.2.0`)
  - Authenticates to Azure using provided Service Principal credentials

- **Install Azure CLI** (`BHGitOps/action-azure-install-cli@v1`)
  - Installs the Azure CLI for resource management

- **Download and Install kubectl** (`BHGitOps/action-install-kubectl@v1`)
  - Installs kubectl for Kubernetes cluster management

- **Authenticate to Azure AKS** (`BHGitOps/action-authenticate-aks@v1`)
  - Configures kubectl access to the specified AKS cluster

- **Create Kubernetes Secret from GitHub Secrets** (`BHGitOps/action-gh-secrets-to-k8s@v2`)
  - Conditionally executed if `secret-operation == 'create-generic-secret'`
  - Creates a generic Kubernetes secret from GitHub Secrets JSON payload

- **Create Generic Kubernetes Secrets from Conjur** (`BHGitOps/action-conjur-k8s-secret@v1`)
  - Conditionally executed if `secret-operation == 'conjur-to-generic-secret'`
  - Creates a generic Kubernetes secret from Conjur secrets

- **Create TLS Secrets from GitHub Secrets** (`BHGitOps/action-k8s-tls-cert@v1`)
  - Conditionally executed if `secret-operation == 'create-tls-secret'`
  - Creates a TLS Kubernetes secret from certificate and key in GitHub Secrets

- **Create TLS Secrets from Conjur Secrets** (`BHGitOps/action-conjur-k8s-tls-secret@v1`)
  - Conditionally executed if `secret-operation == 'conjur-to-tls-secret'`
  - Creates a TLS Kubernetes secret from Conjur-managed certificate and key

- **Create Kubernetes Secret from Azure Keyvault** (`BHGitOps/action-azure-keyvault-to-k8s@v1`)
  - Conditionally executed if `secret-operation == 'create-keyvault-secret'`
  - Creates a Kubernetes secret by retrieving values from Azure Key Vault

- **Delete Kubernetes Secret** (`BHGitOps/action-delete-k8s-secrets@v1`)
  - Conditionally executed if `secret-operation == 'delete-k8s-secret'`
  - Deletes an existing Kubernetes secret or selected keys

- **Clean Up Runner Workspace** (`BHGitOps/action-clean-runner-artifacts@v1`)
  - Executes after workflow completion (success or failure)
  - Removes artifacts and cleans up the runner workspace

---

## Example Scenarios

### Scenario 1: Creating a Generic Secret from GitHub Secrets
Fetch credentials stored in GitHub Secrets and create a generic Kubernetes Secret in AKS:

```yaml
with:
  secret-operation: "create-generic-secret"
  secret-name: "app-credentials"
  namespace: "production"
secrets:
  secrets-json: |
    {
      "DATABASE_USER": "${{ secrets.DB_USER }}",
      "DATABASE_PASSWORD": "${{ secrets.DB_PASSWORD }}"
    }
```

### Scenario 2: Creating a Generic Secret from Conjur
Fetch secrets from CyberArk Conjur and deploy them as a Kubernetes Secret:

```yaml
with:
  secret-operation: "conjur-to-generic-secret"
  secret-name: "conjur-app-secrets"
  namespace: "default"
  conjur-variable-json: |
    {
      "prod-vault": {
        "db-username": "DATABASE_USER",
        "db-password": "DATABASE_PASSWORD"
      }
    }
secrets:
  conjur-appliance-url: ${{ secrets.CONJUR_APPLIANCE_URL }}
  conjur-account: ${{ secrets.CONJUR_ACCOUNT }}
  conjur-workload-id: ${{ secrets.CONJUR_WORKLOAD_ID }}
  conjur-api-key: ${{ secrets.CONJUR_API_KEY }}
```

### Scenario 3: Creating a TLS Secret
Deploy TLS certificate and key as a Kubernetes Secret:

```yaml
with:
  secret-operation: "create-tls-secret"
  secret-name: "app-tls"
  namespace: "ingress-nginx"
secrets:
  tls-cert: ${{ secrets.TLS_CERTIFICATE }}
  tls-key: ${{ secrets.TLS_KEY }}
```

### Scenario 4: Creating a Secret from Azure Key Vault
Retrieve secrets from Azure Key Vault and create a Kubernetes Secret:

```yaml
with:
  secret-operation: "create-keyvault-secret"
  secret-name: "azure-vault-secret"
  namespace: "default"
  keyvault-name: "my-keyvault"
  azure-resource-group: "my-resource-group"
```

### Scenario 5: Deleting a Kubernetes Secret
Remove an existing Kubernetes Secret from AKS:

```yaml
with:
  secret-operation: "delete-k8s-secret"
  secret-name: "old-secret"
  namespace: "default"
```

---

## Best Practices
- **Store Sensitive Values:** Keep Conjur credentials, TLS certificates, and API keys in **GitHub Secrets**, never in code or configuration files.
- **Validate Data Formats:** Ensure TLS certificates are in valid PEM format and JSON payloads are properly structured before deployment.
- **Audit and Monitoring:** Monitor workflow executions and review uploaded artifacts for traceability and compliance.
- **Limit Permissions:** Restrict the `secret-operation` types allowed in your workflows to approved security operations.
- **Use Environment-Specific Secrets:** Leverage GitHub Environments to manage different secret sets for dev, staging, and production deployments.
- **Test Thoroughly:** Test secret creation and deletion operations in non-production environments before rolling out to production.
- **Clean Up Resources:** Always verify that secrets are properly created or deleted as intended to avoid stale or missing secrets in your clusters.

---

## Changelog 📝

| Version | Date | Tags | Changes |
|--------|--------|------------------------|----------|
| v1 | 2025-02-18 | Initial Release | Support for creating Kubernetes secrets from GitHub Secrets, Conjur, and Azure Key Vault; Delete Kubernetes secrets functionality with optional key-scoped deletion; AKS authentication and kubectl integration; Clean up runner workspace; Support for both self-hosted and GitHub-hosted runners |
 
---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>
  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1399652510/workflow-k8s-secret-handler">Workflow-k8s-secret-handlerᵈ²</a>
    </strong>
    <p>
      Workflow-k8s-secret-handler - Reusable GitHub workflow for configuring Kubernetes secrets in EKS or AKS.
    </p>
  </article>  

---

## Feedback/Need Help? 📬
If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!.
