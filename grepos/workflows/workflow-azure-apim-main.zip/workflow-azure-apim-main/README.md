<h1 align="center">
  <a href=".github/workflows/workflow.yml">workflow-azure-apim</a>
</h1>

## Overview

This repository provides a reusable GitHub Actions workflow for deploying and managing APIs in **Azure API Management (APIM)**. It automates optional application build and OpenAPI specification generation, along with key APIM operations including API import, version set creation, policy management, product creation, named value deployment, diagnostic log configuration, and product subscription management.

The workflow supports secure secret management for named values, which can reference Azure Key Vault, **GitHub Secrets**, GitHub Variables, or plain‑text values. Secrets and configuration values can be sourced through multiple mechanisms, including CyberArk Conjur, **GitHub Secrets**, and GitHub Variables, enabling flexible and secure configuration across environments.

---

## Getting Started

These documents will help you get up to speed with our engineering practices and tools.

---

## Reusable Workflow Summary

The table outlines the essential details of the reusable Azure APIM deployment workflow, including its name, current stable version, supported cloud environment and services, compatible tech stacks, and confirmation of Conjur integration

| • Workflow Name | [**workflow-azure-apim**](.github/workflows/workflow.yml) |
| :-------------- | :------------------ |
| • **Latest Stable Version** | v6 |
| • **Current Version** | v6 |
| • **Cloud Environment** | Azure |
| • **Cloud Services** | API Management (APIM) |
| • **TechStacks** | Any API (Swagger/OpenAPI) |
| • **Is Conjur integrated** | Yes*¹ |
| **High Availability Supported** | No |
| • **Logging** | Yes |

*¹ - CyberArk Conjur is integrated into this workflow to securely manage sensitive information such as API keys, credentials, and environment variables. Secrets can be fetched dynamically during policy deployment, named values creation, or API import, ensuring compliance and security.

---

## Mock Caller Repositories

A mock workflow, shown below, provides a solid starting point for implementing this reusable workflow to support API deployments to Azure APIM.

| Mock Repository | Purpose | Technology Stack |
|------------------|---------|----------------|
| [**mock-azure-apim-deploy**](https://github.com/BHGitOps/mock-azure-apim-deploy) | Demonstrates APIM API deployments | Azure APIM |

---

## Key Features & Capabilities

* Optional build stage for compiling applications and generating deployment artifacts
* Optional OpenAPI (Swagger) specification generation during build using Swashbuckle CLI
* Supports importing OpenAPI specifications into APIM from build artifacts or repository files
* Import API specifications (OpenAPI/Swagger)
* Apply API, product, and operation policies
* Create API version sets
* Create APIM products
* Manage subscriptions and attach API to product
* Deploy named values from Conjur or GitHub secrets
* Configure diagnostic log settings
* Azure OIDC authentication for secure access
* Clean runner workspace after execution
* Full support for multi-version API deployments
* Fail-fast validation for named values
* Enables or disables Application Insights diagnostics for a specific APIM API
* Supports optional configuration file
* Applies default/basic logging when config file is not provided


## Build & OpenAPI Specification Flow

This workflow supports an optional **Build phase** that can generate an OpenAPI (Swagger) specification and publish it as a build artifact for downstream APIM deployment.

### When does the Build job run?
The Build job executes only when:
- `skip-build-job` is set to `false`
- `file-name-to-build` is provided

### What happens during the Build phase?
- Framework and dependency setup
- Application build and publish
- Optional installation of Swashbuckle CLI
- OpenAPI (Swagger) specification generation
- Upload of generated files as build artifacts

### How is the API spec deployed?
- **If Build runs successfully** → OpenAPI spec is downloaded from artifacts and imported into APIM
- **If Build is skipped** → OpenAPI spec is read directly from the repository path provided via `apim-specs-file-path`

This dual-path approach supports both **dynamic spec generation** and **static spec deployments**.

> [!TIP]  
> This workflow fully supports **versioned and non-versioned** API deployments. Begin with a simple, single-version setup, and scale to multiple versions when needed.

> [!NOTE]  
> Secrets can originate from **either GitHub Secrets** or **Conjur**.  
> Use `conjur-variable-json` to retrieve values from Conjur, or `secrets-json` when using GitHub Environment Secrets.

---

## Prerequisites

> [!IMPORTANT]  
> Before using this reusable workflow to deploy APIs into Azure API Management (APIM), ensure the following prerequisites are met for every environment (dev/qa/prod):

- Existing Azure API Management (APIM) instance
- APIM resource group and service name
- API identifiers, product identifiers (if needed)
- API specification files (Swagger/OpenAPI)
- Policy XML files (base and operation-level)
- Diagnostic Log Config JSON file (if needed)
- Proper role assignments for SPN:
  - `API Management Service Contributor`
  - `API Management Reader`
  - `Contributor` (optional depending on policy tasks)
- Conjur workload ID + API key (if using Conjur)
- GitHub → Azure OIDC trust configured

---

## Usage
#### Example: Deploy API to Azure APIM

```yaml
uses: BHGitOps/workflow-azure-apim/.github/workflows/workflow.yml@v6
with:
  deploy-environment: dev
  deploy-runner-type: ubuntu-latest
  apim-resource-group: rg-api-dev
  apim-service-name: apim-dev
  apim-api-id: example-api
  apim-specs-file-path: specs/api.json
secrets:
  client-id: ${{ secrets.CLIENT_ID }}
  tenant-id: ${{ secrets.TENANT_ID }}
  apim-subscription-id: ${{ secrets.APIM_SUBSCRIPTION_ID }}
  secrets-json: ${{ secrets.SECRETS_JSON }}
  conjur-appliance-url: ${{ secrets.CONJUR_APPLIANCE_URL }}
  conjur-account: ${{ secrets.CONJUR_ACCOUNT }}
  conjur-workload-id: ${{ secrets.CONJUR_WORKLOAD_ID }}
  conjur-api-key: ${{ secrets.CONJUR_API_KEY }}
```


#### Example: Build Application, Generate OpenAPI Spec, and Deploy to APIM

```yaml
uses: BHGitOps/workflow-azure-apim/.github/workflows/workflow.yml@v6.3.2
with:
  deploy-environment: dev
  deploy-runner-type: ubuntu-latest

  # Enable build and OpenAPI generation
  skip-build-job: false
  framework-type: dotnet
  file-name-to-build: src/MyApi/MyApi.csproj
  generate-openapi: true

  # APIM configuration
  apim-resource-group: rg-api-dev
  apim-service-name: apim-dev
  apim-api-id: example-api
  apim-specs-file-path: output/swagger.json
secrets:
  client-id: ${{ secrets.CLIENT_ID }}
  tenant-id: ${{ secrets.TENANT_ID }}
  apim-subscription-id: ${{ secrets.APIM_SUBSCRIPTION_ID }}
```
---


## Inputs

| Name | Description | Required | Type | Default |
|------|-------------|:--------:|-------|---------|
| deploy-environment | Specifies the target environment (e.g., dev, qa, prod) where the APIM deployment should run. This controls environment‑specific configurations and resource selections. | ✅ | string | - |
| deploy-runner-type | Defines the type of GitHub runner (hosted or self‑hosted) that will execute the deployment job. This determines where the workflow runs and what environment it has access to. | ✅ | string | [Refer GitHub Reusable Workflow](#resources-) |
| apim-resource-group | Name of the Azure Resource Group that contains the APIM instance. Used to identify where APIM resources are deployed. | ❌ | string | - |
| apim-service-name | The name of the Azure API Management (APIM) service instance where the API will be created or updated. | ❌ | string | - |
| apim-api-id | A unique identifier for the API inside APIM. This ID is used for referencing and updating the API. | ❌ | string | - |
| apim-product-id | Identifier of the APIM Product to which the API should be associated or published. | ❌ | string | - |
| apim-specs-file-path | File path to the API specification document (OpenAPI/Swagger). Used as the source definition for creating or updating the API. | ❌ | string | - |
| apim-base-policy-file-path | Path to the base API-level policy XML file. This policy applies globally to the entire API. | ❌ | string | - |
| apim-operation-policy-folder-path | Folder path containing operation-level policy files. Each file corresponds to a specific API operation policy. | ❌ | string | - |
| apim-specification-format | Specifies the format of the API spec file (e.g., openapi+json, openapi+yaml). Determines how APIM interprets the file. | ❌ | string | - |
| apim-api-tags | Comma-separated tag values used for categorizing or grouping the API within APIM. | ❌ | string | - |
| api-version-required | Enables or disables API versioning in APIM. Determines whether the workflow should configure version sets. | ❌ | boolean | - |
| api-namedvalues-required | Indicates whether named values (key–value pairs) should be deployed or updated as part of the workflow. | ❌ | boolean | - |
| apim-api-versions | Comma-separated list of API version values that should be created or updated in APIM. | ❌ | string | - |
| apim-api-versionset-id | Identifier of the APIM version set the API belongs to. Required when versioning is enabled. | ❌ | string | - |
| apim-api-version-scheme | Specifies the versioning scheme (e.g., Segment, Query) used by the APIM version set. | ❌ | string | - |
| apim-api-display-name | Human‑readable display name for the API as it appears in the APIM portal. | ❌ | string | - |
| apim-api-url-suffix | URL suffix appended to the APIM gateway URL (e.g., /orders). Defines the API’s public endpoint. | ❌ | string | - |
| apim-api-subscription-required | Indicates whether clients must present a subscription key to access the API. | ❌ | string | 'false' |
| apim-product-name | Display name of the Product to be created or updated in APIM. | ❌ | string | - |
| apim-product-description | Description of the APIM Product, visible to developers in the Developer Portal. | ❌ | string | - |
| apim-product-state | Defines whether the product is published or notPublished in APIM. | ❌ | string | - |
| apim-product-subscription-required | Indicates if consumers need to subscribe before using the product. | ❌ | boolean | - |
| apim-product-approval-required | Determines whether subscription requests require manual approval. | ❌ | boolean | - |
| apim-product-subscriptions-limit | Limits the number of subscriptions allowed for the product. | ❌ | string | - |
| apim-product-legal-terms | Legal terms or usage policies associated with the product. | ❌ | string | - |
| apim-subscriptions-file-path | Path to a JSON file defining APIM subscriptions to be created or updated. | ❌ | string | - |
| api-loggingconfig-file-path | Path to a JSON file containing all logging configuration inputs. | ❌ | string | - |
| vars-json | JSON-formatted string containing environment variables used during deployment or transformations. | ❌ | string | - |
| apim-named-values-file-path | Path to a JSON file containing APIM Named Values (app-level settings) to be deployed. | ❌ | string | - |
| api-version | API version for APIM REST API used during management operations. | ❌ | string | 2024-05-01 |
| failOnUpsertErrorForNamedValues | If true, the workflow fails when a named value cannot be created or updated. Ensures strict validation. | ❌ | boolean | true |
| conjur-variable-json | JSON string defining mapping between Conjur variables and APIM named values. Used for secure secret injection. | ❌ | string | - |
| skip-build-job | Skips the build phase when set to true. When false, the workflow builds the application and publishes artifacts for APIM deployment. | ❌ | boolean | true |
| file-name-to-build | Project or solution file (.csproj/.sln) used during the build phase. Required when build is enabled. | ❌ | string | - |
| generate-openapi | Enables OpenAPI (Swagger) specification generation during the build phase using Swashbuckle CLI. | ❌ | boolean | false |
| swashbuckle-version | Version of Swashbuckle.AspNetCore.Cli used for OpenAPI generation. | ❌ | string | 6.6.2 |
| artifact-name | Name of the build artifact that contains generated OpenAPI specifications. | ❌ | string |  'build-artifacts'|
| framework-type | Type of framework used to build the application (e.g., dotnet, angular, python). Determines framework-specific setup and build steps. | ❌ | string | - |
| framework-version | Version of the framework to install on the runner (e.g., .NET SDK version). | ❌ | string | - |
| working-directory | Path to the working directory that contains the application source code. | ❌ | string | - |
| configuration | Build configuration to use during compilation (e.g., Debug, Release). | ❌ | string | - |
| file-name-to-restore | Solution or project file (.sln / .csproj) to restore dependencies from. Useful when multiple files exist. | ❌ | string | - |
| nuget-config-path | Path to the NuGet.config file used during dependency restore. | ❌ | string | - |
| dependency-version | Version of the dependency manager or tooling to install (e.g., NuGet version). | ❌ | string | - |
| file-name-to-publish | Path to the project file (.csproj) used during the publish step. | ❌ | string | - |
| build-artifacts | Directory where build outputs and generated OpenAPI specs are stored before upload. | ❌ | string | output/ |
| artifact-download-path | Local path where build artifacts are downloaded during the deploy job. | ❌ | string | . |
| apim-logger-name | Logger name (used if not in config file) | ❌ | string | - |

---

## Secrets

| Name | Description | Required | Type | Default |
|------|-------------|:--------:|-------|---------|
| client-id | Azure Service Principal Client ID used for authentication when deploying or managing APIM resources. Required when not using Conjur-based authentication. | ❌*¹ | string | - |
| tenant-id | Azure Active Directory Tenant ID associated with the Service Principal. Required when SPN-based login is used. | ❌*¹ | string | - |
| apim-subscription-id | Azure Subscription ID that contains the APIM instance. Needed when using Azure SPN authentication. | ❌*¹ | string | - |
| conjur-appliance-url | URL of the Conjur appliance used for secure secret retrieval. Enables Conjur-based authentication in the workflow. | ❌*² | string | vars.CONJUR_APPLIANCE_URL |
| conjur-account | Conjur account name required to communicate with the Conjur appliance. | ❌*² | string | vars.CONJUR_ACCOUNT |
| conjur-workload-id | Workload identity (Host ID) used to authenticate to Conjur and fetch secrets securely. | ❌*² | string | - |
| conjur-api-key | API key associated with the Conjur workload identity, used for authenticating to fetch secrets. | ❌*² | string | - |
| secrets-json | JSON containing GitHub environment secrets. Used when deploying environment-specific API settings or configurations. | ❌ | string | - |

*¹ Required for Azure authentication using Service Principal.  
*² Required for Conjur-based secret retrieval for APIM deployments.

> [!CAUTION]  
> Secrets must never be logged, printed, or written to output. If a credential leak is suspected, rotate immediately.

---

## Jobs & Steps


### **1. Build Application & Generate OpenAPI (Optional)**

This job builds the application, generates OpenAPI specifications when enabled, and uploads build artifacts for downstream APIM deployment.

---

### **2. Deploy Azure APIM API**

This job deploys APIs into Azure APIM using either:
- OpenAPI specs generated during the Build phase (artifact-based), or
- Static OpenAPI specs stored in the repository

---

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checkout repository |
| [**action-setup-framework**](https://github.com/BHGitOps/action-setup-framework) | Setup Framework |
| [**action-setup-dependency**](https://github.com/BHGitOps/action-setup-dependency) | Setup Dependency |
| [**action-azpslogin**](https://github.com/BHGitOps/action-azpslogin) | Login to Azure |
| [**action-azure-devops-access-token**](https://github.com/BHGitOps/action-azure-devops-access-token) | Fetch Azure DevOps Access Token |
| [**action-authorize-nuget-restore**](https://github.com/BHGitOps/action-authorize-nuget-restore) | Configure NuGet Package Source |
| [**action-restore-dependencies**](https://github.com/BHGitOps/action-restore-dependencies) | Restore Dependencies |
| [**action-build**](https://github.com/BHGitOps/action-build) | Build Action |
| [**action-publish**](https://github.com/BHGitOps/action-publish) | Publish Action |
| [**action-upload-artifacts**](https://github.com/BHGitOps/action-upload-artifacts) | Upload Artifacts |
| [**action-download-artifact**](https://github.com/BHGitOps/action-download-artifact) | Download and Extract Artifact |
| [**action-install-az-module**](https://github.com/BHGitOps/action-install-az-module) | Install Az PowerShell modules |
| [**action-azure-apim-named-values**](https://github.com/BHGitOps/action-azure-apim-named-values) | Deploy named values using GH secrets |
| [**action-conjur-fetch-secrets**](https://github.com/BHGitOps/action-conjur-fetch-secrets) | Fetch secrets from Conjur |
| [**action-conjur-azure-apim-named-values**](https://github.com/BHGitOps/action-conjur-azure-apim-named-values) | Deploy named values from Conjur |
| [**action-azure-apim-versionset**](https://github.com/BHGitOps/action-azure-apim-versionset) | Create API version set |
| [**action-azure-apim-definitions**](https://github.com/BHGitOps/action-azure-apim-definitions) | Import API definition |
| [**action-azure-apim-api-policy-deploy**](https://github.com/BHGitOps/action-azure-apim-api-policy-deploy) | Apply base API policy |
| [**action-azure-apim-operation-policy-deploy**](https://github.com/BHGitOps/action-azure-apim-operation-policy-deploy) | Apply operation-level policies |
| [**action-azure-apim-product**](https://github.com/BHGitOps/action-azure-apim-product) | Create APIM product |
| [**action-azure-apim-subscriptions**](https://github.com/BHGitOps/action-azure-apim-subscriptions) | Manage APIM product subscriptions |
| [**action-azure-apim-attach-api-to-product**](https://github.com/BHGitOps/action-azure-apim-attach-api-to-product) | Attach API to product |
| [**action-azure-apim-logging**](https://github.com/BHGitOps/action-azure-apim-logging) | Configures Application Insights diagnostic logging for an Azure API Management (APIM) API |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Cleanup runner workspace |

---

## Changelog 📝

| Version | Date       | Tags | Changes |
|:--------:|:----------|------|---------|
| **v6.6.0** | 2026-12-06 | default logging support |  **Enhanced**: provided default APIM Application Insights diagnostics configuration when no custom JSON config is provided |
| **v6.5.0** | 2026-02-06 | Conjur Integration, Enhanced Named Values, APIM Policy Improvements | - **Added:** Conjur secret retrieval<br>- **Added:** Diagnostics Logs Configuration<br>- **Improved:** Named values fail-fast validation<br>- **Enhanced:** Policy deployment reliability |
| **v6.3.2** | 2026-04-09 | Build & OpenAPI Artifact Support | - **Added:** Optional build job<br>- **Added:** OpenAPI generation using Swashbuckle<br>- **Enhanced:** APIM import from build artifacts or repo |
| **v5** | 2025-12-09 | Policy Enhancements, Stability Updates | - **Improved:** API/product/operation policy handling<br>- **Updated:** APIM import behavior |
| **v4** | 2025-10-28 | Version Sets + API Versioning | - **Added:** Version set creation<br>- **Enhanced:** Versioning scheme support |
| **v3** | 2025-09-16 | Product + Subscription Support | - **Added:** Product creation<br>- **Added:** Subscription mgmt |
| **v2** | 2025-07-30 | Named Values + Spec Import | - **Improved:** OpenAPI import<br>- **Added:** Named values support |
| **v1** | 2025-02-27 | Initial Release | - **Added:** Basic APIM API creation |

---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

<article>
  <strong>
    <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
  </strong>
  <p>
    Central documentation hub for all reusable workflows maintained by the DSO team.
  </p>
</article>

<article>
  <strong>
    <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1694924815/workflow-azure-apim+v4+APIM+Policy+Deployment">Workflow-azure-apimᵈ²</a>
  </strong>
  <p>
    Reusable GitHub workflow for deploying and managing APIs in Azure API Management.
  </p>
</article>

---

## Feedback/Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
