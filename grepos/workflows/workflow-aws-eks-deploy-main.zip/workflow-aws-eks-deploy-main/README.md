# [Workflow Name]

---

## Workflow usage and description
Workflow Description

---

## Features
- Feature 1
- Feature 1

---

## Usage
**Current Version:** `Current Verion#`
To use this workflow in your repository:
#### Example: What this workflow does
```yaml
jobs:

  [job-name]:
    uses: <ORG>/<REPO>/.github/workflows/workflow.yml@[version]
    with:
      [input-name]: "[value]"
    secrets:
      [secret-name]: ${{ secrets.[SECRET_NAME] }}
```

---
 
## Inputs
| Name | Description | Required | Type | Default |
|------|-------------|----------|------|---------|
| `framework-type` | Type of framework used to build and deploy code | ❌ | string | - |
| `deploy-environment` | Target deployment environment (`dev`, `qa`, `prod`) | ✅ | `string` | - |
| `deploy-runner-type` | GitHub Actions runner type | ✅ | `string` | ubuntu-latest |

---

## Secrets
| Name | Description |
|------|-------------|
| `client-id` | Azure Service Principal Client ID |
| `tenant-id` | Azure Tenant ID |
| `apim-subscription-id` | Azure Subscription ID |
| `secrets-json` | JSON string containing environment-specific secrets |

---
 

## Jobs & Steps
### Job Name
- **Job step 1**
- **Job step 2**

---

## Example Scenarios
- Example Scenarios 1
- Example Scenarios 2

---

## Best Practices
- Best Practices 1 **For Bold**
- Best Practices 1

---


## 📜 Changelog
All notable changes to this project will be documented in this section.


### [v5] - 2025-10-31 
**Tags:** Breaking Changes 
- **Added:** Source/Target EKS support
- **Changed:** Comments

 
### [v4] - 2025-10-28 
**Tags:** Major Update, Breaking Changes 
- **Changed:** Optimized workflow for full APIM deployment 

---

## Mock Caller Workflows
Below are examples of workflows that call this reusable workflow:
- [Mock Caller link](https://github.com/BHGitOps/mock-repo-link)
These mock workflows illustrate how to invoke the reusable workflow with different environments and configurations.

 

## Documentation
Refer the documentation below for more detailed explanation:
- [Documentation link](https://bannerhealth.atlassian.net/wiki/spaces/documentation-link)
