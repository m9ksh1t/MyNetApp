# Upgrade Guide: workflow-azure-aks (v2 → v3)

This document provides step-by-step instructions to migrate your GitHub workflows from **v2** to the **major v3 release** of the [**workflow-azure-aks**](../../../.github/workflows/workflow.yml) reusable workflow.

> [!NOTE]
> This upgrade includes **breaking changes**, and all application teams must migrate to the updated reusable workflow version to ensure compatibility with new enhancements, including **High Availability (HA)** support.
> 
> Any caller workflow referencing workflow versions **≤v2** must follow this upgrade path, as older versions are not compatible with the changes introduced in v3 and must be updated to ensure continued functionality and support.


> [!CAUTION]
> Migration deadline : Flexible (**Any new onboarding must adopt this version** to ensure compatibility and support.)

---

## 🔄 Overview of Changes
The v3 upgrade requires updates across all application caller workflows that reference the [**workflow-azure-aks**](../../../.github/workflows/workflow.yml) reusable workflow, specifically:
- Updating the reusable workflow version reference to v3
- Updating parameters for acr Matrix and AKS Deploy Matrix

Follow the instructions below to complete the migration safely.

---

## Mock Caller Repositories

A mock workflow, shown below, provides a solid starting point for implementing this version upgrade. Refer to the below mock example.

| Mock Repository URL | Purpose |
|------------------|-------------|
| [**mock-aks-deploy-dotnet:v4**](https://github.com/BHGitOps/mock-aks-deploy-dotnet/blob/main/.github/workflows/01-aks-single-env.yml) | Provides a reference implementation for deploying a .NET application using this reusable workflow including HA and Wiz upgrade |

> **Tip:** In the mock repository, an additional job—prepare-vars-for-environment—is included to source environment‑level variables. The subsequent job typically consumes these variables from the job outputs (e.g., dev-vars-json or qa-vars-json) and injects them into each matrix item using ${{ fromJSON(...) }}.

> Refer to the [**prepare-vars-for-environment**](../../common/prepare-vars-for-environment.md) guide for detailed instructions on retrieving environment‑level variables.
> This job is ***optional***, the values can be hardcoded, but using it is recommended.

---

## 📝 Step 1: Update the workflow-azure-aks version reference

Change your reusable workflow reference from **v2** to the **v3** release.

**Before:**
```yaml
uses: BHGitOps/workflow-azure-aks/.github/workflows/workflow.yml@v2
```

**After:**
```yaml
uses: BHGitOps/workflow-azure-aks/.github/workflows/workflow.yml@v3
```

---

## 📝 Step 2: Update parameters for High Availability (HA)
These steps explain all subsequent changes that are related to High Availability (HA). Although your application does not currently require HA, the workflow still requires passing the target acr/cluster parameter in the matrix. This ensures that the pipeline can support multi–acr image pushes and multi‑cluster deployments in the future, if needed.

### Parameter Mapping: v2 → v3 (Single-Target → Matrix Configuration)

This table summarizes how **v2 single-target parameters** map to the new **v3 matrix-based configuration** (`acr-matrix-config` and `deploy-matrix-config`). Use it as a quick reference when migrating your workflow inputs.

> [!NOTE]
> Refer **Mapping Table** below. Rename the v2 (Old Parameters) to v3 (New Parameters) and place them under the appropriate matrix location. This highlights that, instead of pushing images to a single acr repository, the workflow now supports using a matrix strategy to push images to multiple acr repositories.
> Similarly, this approach also enables deploying images from multiple acr repositories to multiple AKS clusters.

---

## 🔁 Mapping Table

| v2 (Old Parameter) | v3 (New Parameter) | Location | Notes |
|---|---|---|---|
| `target-container-repository` | `target-acr-container-repository` | **ACR matrix** | Target acr repository for image push.*² |
| `target-container-repository` | `target-acr-container-repository` | **AKS deploy matrix** | Target acr repository referenced to ensure consistent image paths during deployments.*³ |
| `target-container-registry` | `target-acr-container-registry` | **ACR matrix** | Target acr registry for image push.*² |
| `target-container-registry` | `target-acr-container-registry` | **AKS deploy matrix** | Target acr registry referenced to ensure consistent image paths during deployments.*³ |
| `target-namespace` | `target-namespace` | **AKS deploy matrix** | Target Kubernetes namespace moved inside the deploy matrix config.*¹ |
| `target-deployment-file` | `target-deployment-file` | **AKS deploy matrix** | Target Path to the manifest values moved inside the deploy matrix config.*¹ |
| `target-cluster-name` | `target-cluster-name` | **AKS deploy matrix** | Target Cluster identifier moved inside the deploy matrix config.*¹ |
| `target-azure-resource-group` | `target-azure-resource-group` | **AKS deploy matrix** | Target Azure resource group moved inside the deploy matrix config.*³ |

*¹ - The parameter names remain the same—however, these values are now placed inside the deploy-matrix-config, where each array item can define its own deployment‑specific values, enabling support for multiple deployments across different clusters.

*² - These values are specific to acr and are now placed inside the acr-matrix-config, where each array item defines the target acr repository to which images should be pushed—enabling support for copying images across multiple ACR locations.

*³ -  These values are specific to AKS and are now placed inside the deploy-matrix-config, where each array item can define its own deployment‑specific settings. This enables support for multiple deployments across different AKS clusters, each capable of pulling images from any ACR.

---

## 📋 Example Snippets (for QA)

**ACR Matrix (v3):**
```yaml
      acr-matrix-config: |
        [
          {
            "target-acr-container-repository": "mock-aks-deploy-dotnet-target-repo-1",
            "target-acr-container-registry": "dsoacr01"
          },
          {
            "target-acr-container-repository": "mock-aks-deploy-dotnet-target-repo-2",
            "target-acr-container-registry": "dsoacr01"
          }          
        ]
```

**AKS Deploy Matrix (v3):**
```yaml
      deploy-matrix-config: |
        [
          {
            "target-namespace": "dso",          
            "target-acr-container-repository": "mock-aks-deploy-dotnet-target-repo-1",
            "target-acr-container-registry": "dsoacr01",
            "target-deployment-file": "k8s/qadeployment.yml",
            "target-cluster-name": "dso-sb-aks-cluster01",
            "target-azure-resource-group": "bhx1-auw3-rg-sb-dso-sndbx001"
          },
          {
            "target-namespace": "dso",          
            "target-acr-container-repository": "mock-aks-deploy-dotnet-target-repo-2",
            "target-acr-container-registry": "dsoacr01",
            "target-deployment-file": "k8s/qadeployment.yml",
            "target-cluster-name": "dso-sb-aks-cluster01",
            "target-azure-resource-group": "bhx1-auw3-rg-sb-dso-sndbx001"
          }          
        ]
```

> [!WARNING]
> All parameter names and their value assignments inside the `acr-matrix-config` and `deploy-matrix-config` inputs must be wrapped in **double quotes** to prevent exceptions or value errors.

---

## 🧪 Step 3 : Deprecated or Renamed Parameters

- The following parameters have either been deprecated or renamed:

    - If a parameter is deprecated, it can be safely removed from your workflow.
    - If a parameter has been renamed, update your workflow to use the new parameter name in place of the old one.

### Parameter/Input Changes

| Status      | Old Input Name       | New Input Name       | Notes                                    |
|-------------|----------------------|----------------------|-------------------------------------------|
| Deprecated  | `artifact-path`      | —                    | Remove this parameter from your workflow. |
| Renamed     | `wiz_client_id`      | `wiz-client-id`      | Updated to hyphen-based naming.           |
| Renamed     | `wiz_client_secret`  | `wiz-client-secret`  | Updated to hyphen-based naming.           |


---

## 🧪 Step 4 (Optional): Validate the workflow

After updating:
1. Commit the changes  
2. Push to your branch  
3. Trigger the workflow manually or wait for the next run  
4. Confirm the job completes successfully without authentication or version issues  

---

## ✅ Migration Complete

Your project is now upgraded to the **v3** reusable workflow.  

---

## 📚 Resources

If you'd like a full updated workflow example or additional enhancements, please refer below!

| Mock Repository URL | Purpose | Technology Stack |
|------------------|-------------|----------|
| [**mock-aks-deploy-dotnet**](https://github.com/BHGitOps/mock-aks-deploy-dotnet) | Provides a reference implementation for deploying a .NET application using this reusable workflow | .NET |

---

## 📬 Feedback/Need Help?

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
