<h1 align="center">
  <a href=".github/workflows/workflow.yml">workflow-azure-aks</a>
</h1>

## Overview.
This repository provides a reusable GitHub workflow for building, containerizing, scanning, and deploying applications to **Azure Kubernetes Service (AKS)**.  
It supports **single and multi‑environment deployments**, allows seamless promotion across environments (e.g., dev → qa), integrates **CyberArk Conjur** for secure secrets management, and handles end‑to‑end Azure ACR and AKS operations.

This workflow brings enterprise-grade reliability, security, and consistency to your Azure-based CI/CD pipelines.

---

## Getting Started
These documents will help you get up to speed with our engineering practices and tools.

---

## Reusable Workflow Summary

| Workflow Name | [**workflow-azure-aks**](.github/workflows/workflow.yml) |
|-----------------|--------------------|
| **Latest Stable Version** | v3 |
| **Current Version** | v3 |
| **Cloud Environment** | Azure |
| **Cloud Services** | AKS, ACR |
| **TechStacks** | .NET, Node, Angular, Containers |
| **Is Conjur integrated** | Yes*¹ (optional) |
| **High Availability Supported** | Yes |

*¹ - CyberArk Conjur is integrated into this workflow to securely manage sensitive information such as API keys, credentials, and environment variables. Secrets can be fetched dynamically during build and deployment steps, ensuring compliance and security. **Using Conjur is optional**—you may supply the same values via GitHub environment secrets instead.

---

## Reusable Workflow Upgrade Guide

It is considered a best practice to keep your caller/application workflows updated to reference the latest stable version of the reusable workflow. Doing so ensures you benefit from the newest features, security patches, enhancements, and bug fixes provided in the reusable workflow.
For detailed upgrade paths, refer to the table below.

[**workflow-azure-aks (v2 → v3) - Wiz Upgrade Guide**](docs/upgrades/v2/01-v2-to-v3-wiz-upgrade-guide.md)

[**workflow-azure-aks (v2 → v3) - HA Upgrade Guide**](docs/upgrades/v2/02-v2-to-v3-ha-upgrade-guide.md)

---

## Mock Caller Repositories

| Mock Repository URL | Purpose | Tech Stack |
|----------------------|----------|-----------|
| [**mock-aks-deploy-dotnet**](https://github.com/BHGitOps/mock-aks-deploy-dotnet) | Demonstrates .NET app deployment to AKS using this reusable workflow | .NET |

> **Tip:** In the mock repository, an additional job—prepare-vars-for-environment—is included to source environment‑level variables. The subsequent job typically consumes these variables from the job outputs (e.g., dev-vars-json or qa-vars-json) and injects them into each matrix item using ${{ fromJSON(...) }}.

> Refer to the [**prepare-vars-for-environment**](docs/common/prepare-vars-for-environment.md) guide for detailed instructions on retrieving environment‑level variables.
> This job is optional, the values can be hardcoded, but using it is recommended.

---

## Key Features & Capabilities

* Build and publish application artifacts (framework‑based).
* Docker build, retagging, saving, and image scanning using **Wiz**.
* Push Docker images to **Azure Container Registry (ACR)**.
* Deploy application workloads to **Azure AKS clusters** across environments.
* Retrieve secure secrets from **CyberArk Conjur** at build and deploy time.
* Create Kubernetes resources:
  - Secrets (Github / Conjur)
  - ConfigMaps (Vars and Files)
  - Service Accounts (Azure AD Workload Identity)
* Extract application external IP from service/ingress.
* Support multi‑environment deployments (source → target).
* Promote images across Azure subscriptions and ACR instances.
* Fully supports Azure DevOps package feeds, GitHub packages, and private repositories.

> [!TIP]  
> Start with a single environment (source). The workflow works seamlessly without configuring a target cluster. Add a target environment later if needed.

> [!NOTE]  
> Conjur serves as the primary source of truth for secrets. Our reusable workflow supports GitHub Secrets as well, but all teams should move toward Conjur for improved compliance and centralization.

---

## Prerequisites

### Required Azure Setup  
- AKS clusters (source and optional target)  
- Azure Container Registry (ACR) for both environments  
- Azure Service Principal with push/pull and AKS access  
- Kubernetes namespaces and RBAC configured  
- Workload Identity/Service Account client IDs

### Required Conjur Setup  
- Conjur appliance URL & account  
- Workload ID & API key (source/target)  
- Conjur variable path mappings in JSON

> [!IMPORTANT]  
> Coordinate with the IAC team to ensure all Azure and Conjur configurations (cluster, identities, workload IDs, secrets, ACR access) are in place before using this workflow.

---

## Usage

### Example: Multi‑Environment Azure AKS Deployment (Dev → QA)

```yaml
uses: BHGitOps/workflow-azure-aks/.github/workflows/workflow.yml@v3

with:
  framework-type: "dotnet"
  framework-version: "8.x"
  working-directory: "./src"
  dependency-version: "8.x"
  configuration: "Release"
  file-name-to-build: "./src/MyApp/MyApp.csproj"
  file-name-to-publish: "./src/MyApp/MyApp.csproj"

  image-tag: "aks-deploy-${{ github.sha }}"

  source-cluster-name: "aks-dev-cluster"
  source-azure-resource-group: "dev-rg"
  source-container-repository: "myapp"
  source-container-registry: "devacr.azurecr.io"
  source-environment: "dev"

  target-cluster-name: "aks-qa-cluster"
  target-azure-resource-group: "qa-rg"
  target-container-repository: "myapp"
  target-container-registry: "qaacr.azurecr.io"
  target-environment: "qa"

  deploy-runner-type: "azure"
  docker-runner: "azure"

secrets:
  source-client-id: ${{ secrets.CLIENT_ID }}
  source-tenant-id: ${{ secrets.TENANT_ID }}
  source-subscription-id: ${{ secrets.SUBSCRIPTION_ID }}
  target-client-id: ${{ secrets.TARGET_CLIENT_ID }}
  target-tenant-id: ${{ secrets.TARGET_TENANT_ID }}
  target-subscription-id: ${{ secrets.TARGET_SUBSCRIPTION_ID }}

  secrets-json: ${{ secrets.SECRETS_JSON }}
```

---

## Inputs

### Build & Framework
| Name | Description | Required | Type | Default |
|------|-------------|--------|------|---------|
| `framework-type` | Framework (dotnet/node/angular) | ✅ | string | - |
| `framework-version` | Version to install | ✅ | string | - |
| `working-directory` | App working directory | ✅ | string | - |
| `dependency-version` | Dependency manager version | ✅ | string | - |
| `file-name-to-restore` | File to restore | ❌ | string | - |
| `nuget-config-path` | Path to nuget.config | ❌ | string | - |
| `configuration` | Build configuration | ✅ | string | - |
| `file-name-to-build` | File to build (.csproj/.sln) | ✅ | string | - |
| `file-name-to-publish` | File to publish (.csproj) | ✅ | string | - |
| `build-artifacts` | Artifact output folder | ❌ | string | output/ |
| `artifact-name` | Build artifact name | ❌ | string | - |

### Docker & Image Build
| Name | Description | Required | Type | Default |
|------|-------------|----------|------|---------|
| `image-name` | Docker image artifact name | ❌ | string | docker-image |
| `image-tag` | Docker tag | ❌ | string | - |
| `docker-runner` | Runner for Docker build | ✅ | string | ubuntu-latest |
| `docker-file-path` | Path to Dockerfile | ❌ | string | - |
| `docker-build-context` | Build context | ❌ | string | - |
| `image-artifact` | Image artifact name | ❌ | string | image.tar |

### Deployment & AKS
| Name | Description | Required | Type | Default |
|------|-------------|----------|------|---------|
| `deploy-runner-type` | Runner for deploy job | ✅ | string | ubuntu-latest |
| `source-cluster-name` | Source AKS cluster | ❌ | string | - |
| `target-cluster-name` | Target AKS cluster | ❌ | string | - |
| `source-azure-resource-group` | Source RG | ❌ | string | - |
| `target-azure-resource-group` | Target RG | ❌ | string | - |
| `source-container-repository` | Source ACR repo | ❌ | string | - |
| `target-container-repository` | Target ACR repo | ❌ | string | - |
| `source-container-registry` | Source ACR name | ❌ | string | - |
| `target-container-registry` | Target ACR name | ❌ | string | - |
| `source-environment` | Source env | ❌ | string | - |
| `target-environment` | Target env | ❌ | string | - |
| `source-namespace` | Source k8s namespace | ❌ | string | - |
| `target-namespace` | Target k8s namespace | ❌ | string | - |

### Conjur Integration
| Name | Description | Required | Type |
|------|-------------|----------|------|
| `conjur-variable-json` | JSON for Conjur variables | ✅ | string |
| `secrets-keys` | Keys to include in Kubernetes secret | ❌ | string |

### Control Flags
| Name | Purpose | Default |
|------|----------|---------|
| `skip-clean` | Skip clean build | false |
| `skip-docker-build` | Skip Docker build job | false |
| `skip-acr-push` | Skip ACR push | false |
| `skip-deploy-job` | Skip AKS deploy | false |
| `retag-image` | Whether to retag | true |

---

## Secrets

| Secret | Description | Required |
|--------|-------------|----------|
| `source-client-id` | Azure Service Principal client ID | ❌ |
| `source-tenant-id` | Azure tenant ID | ❌ |
| `source-subscription-id` | Source subscription ID | ❌ |
| `target-client-id` | Target client ID | ❌ |
| `target-tenant-id` | Target tenant ID | ❌ |
| `target-subscription-id` | Target subscription | ❌ |
| `conjur-appliance-url` | Conjur base URL | ✅ |
| `conjur-account` | Conjur account | ✅ |
| `source-conjur-workload-id` | Conjur workload ID (source) | ❌ |
| `source-conjur-api-key` | Conjur API key (source) | ❌ |
| `target-conjur-workload-id` | Conjur workload ID (target) | ❌ |
| `target-conjur-api-key` | Conjur API key (target) | ❌ |
| `secrets-json` | JSON of GitHub secrets | ❌ |
| `github-token` | GitHub token | ❌ |

> [!CAUTION]  
> Never log or echo secrets. If any secret is leaked, rotate it immediately and inform the security team.

---

## Jobs & Steps
- Build ➡️ Docker Build ➡️ ACR Push (Source) ➡️ Deploy ACR (Source) ➡️ ACR Push (Target) ➡️ Deploy AKS (Target).

### **1. Build** 🛠️
The Build job compiles the application from source code, restores dependencies, authenticates package sources, applies transformations, and prepares a publish-ready artifact.

| Action Name | Purpose |
|-------------|---------|
| [**action-generate-github-app-token**](https://github.com/BHGitOps/action-generate-github-app-token) | Generates a GitHub App installation token that can be used to access private repositories or submodules in your workflows. (optional when using submodules) |
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checkout repository (optionally with Super Linter) |
| [**action-docker-setup**](https://github.com/BHGitOps/action-docker-setup) | Sets up Docker and prepares the environment for container-based workflows |
| [**action-super-linter**](https://github.com/BHGitOps/action-super-linter) | Runs GitHub Super Linter to analyze and lint source code in a specified directory |
| [**action-setup-framework**](https://github.com/BHGitOps/action-setup-framework) | Installs and configures the required development framework and dependency manager |
| [**action-setup-dependency**](https://github.com/BHGitOps/action-setup-dependency) | Installs project‑specific dependencies needed for the build |
| [**action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Login to Azure Portal |
| [**action-azure-devops-access-token**](https://github.com/BHGitOps/action-azure-devops-access-token) | Generates an Azure DevOps access token for secure operations |
| [**action-authorize-nuget-restore**](https://github.com/BHGitOps/action-authorize-nuget-restore) | Authorizes NuGet restore, typically for private or authenticated azure devops feeds |
| [**action-restore-dependencies**](https://github.com/BHGitOps/action-restore-dependencies) | Restores dependencies required for the application build |
| [**action-clean**](https://github.com/BHGitOps/action-clean) | Cleans the project output or environment before building |
| [**action-json-transform**](https://github.com/BHGitOps/action-json-transform) | Performs JSON transformations (optional step for dynamic config) |
| [**action-build**](https://github.com/BHGitOps/action-build) | Builds the application based on its framework type |
| [**action-publish**](https://github.com/BHGitOps/action-publish) | Publishes build output based on the framework type |
| [**action-upload-artifacts**](https://github.com/BHGitOps/action-upload-artifacts) | Uploads build artifacts for later workflow stages |

### 2. Docker Build 🐳
This job converts the build output into a Docker image, scans it for security vulnerabilities, and produces an image artifact.

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checks out the repository to prepare for the Docker build workflow. |
| [**action-download-artifact**](https://github.com/BHGitOps/action-download-artifact) | Downloads previously generated build artifacts needed for image creation. |
| [**action-docker-setup**](https://github.com/BHGitOps/action-docker-setup) | Sets up Docker and prepares the runner for image build operations. |
| [**action-container-build**](https://github.com/BHGitOps/action-container-build) | Builds the Docker image using the specified Dockerfile and build context. |
| [**action-conjur-fetch-secrets**](https://github.com/BHGitOps/action-conjur-fetch-secrets) | Retrieves secrets from CyberArk Conjur for secure build-time use. |
| [**action-wiz-setup**](https://github.com/BHGitOps/action-wiz-setup) | Installs and configures the Wiz CLI for image security scanning. |
| [**action-container-scan**](https://github.com/BHGitOps/action-container-scan) | Runs Wiz security scanning on the built Docker image. |
| [**action-docker-save-image**](https://github.com/BHGitOps/action-docker-save-image) | Saves the Docker image into a tarball format for later consumption or upload. |
| [**action-upload-artifacts**](https://github.com/BHGitOps/action-upload-artifacts) | Uploads the generated Docker image tar or other artifacts. |
| [**action-docker-cleanup-images**](https://github.com/BHGitOps/action-docker-cleanup-images) | Cleans up Docker images to free runner space. |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Cleans remaining artifacts from the runner at the end of the job. |

### 3. ACR Push (Source) 📦 
Pushes the built Docker image from the pipeline into the Source Azure Account’s ACR registry.

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checks out the repository for the ECR push workflow. |
| [**action-download-artifact**](https://github.com/BHGitOps/action-download-artifact) | Downloads the previously built image artifact (e.g., the saved tar). |
| [**action-docker-setup**](https://github.com/BHGitOps/action-docker-setup) | Sets up Docker on the runner for image operations. |
| [**action-docker-tag-image**](https://github.com/BHGitOps/action-docker-tag-image) | Loads the saved image and applies the proper ACR repository tag(s). |
| [**action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Login to Azure Portal |
| [**action-azure-install-cli**](https://github.com/BHGitOps/action-azure-install-cli) | Install Azure CLI |
| [**action-acr-login**](https://github.com/BHGitOps/action-acr-login) | Action for Container Registry Login |
| [**action-acr-push**](https://github.com/BHGitOps/action-acr-push) | Pushes the tagged Docker image to the specified Azure ACR repository. |
| [**action-docker-cleanup-images**](https://github.com/BHGitOps/action-docker-cleanup-images) | Cleans up local Docker images to free runner space. |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Performs final runner cleanup (artifacts/temp files), always runs. |

### 4. Deploy AKS (Source) ☸️
Deploys the image stored in Source ACR into the Source Azure AKS cluster.
Also handles secret creation, configmaps, image scanning, and environment provisioning.

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checks out the repository to load deployment manifests and configuration. |
| [**action-docker-setup**](https://github.com/BHGitOps/action-docker-setup) | Sets up Docker for handling container images on the runner. |
| [**action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Login to Azure Portal |
| [**action-azure-install-cli**](https://github.com/BHGitOps/action-azure-install-cli) | Install Azure CLI |
| [**action-acr-login**](https://github.com/BHGitOps/action-acr-login) | Action for Container Registry Login |
| [**action-acr-pull**](https://github.com/BHGitOps/action-acr-pull) | Pulls the specified Docker image from Azure ACR. |
| [**action-get-image-digest**](https://github.com/BHGitOps/action-get-image-digest) | Retrieves the SHA256 digest of the container image for AKS deployment. |
| [**action-conjur-fetch-secrets**](https://github.com/BHGitOps/action-conjur-fetch-secrets) | Fetches secrets from CyberArk Conjur for Kubernetes deployment usage. |
| [**action-wiz-setup**](https://github.com/BHGitOps/action-wiz-setup) | Sets up the Wiz CLI for security scanning. |
| [**action-container-scan**](https://github.com/BHGitOps/action-container-scan) | Performs Wiz container scanning using image tag and digest. |
| [**action-install-kubectl**](https://github.com/BHGitOps/action-install-kubectl) | Installs kubectl to interact with the Kubernetes cluster. |
| [**action-authenticate-aks**](https://github.com/BHGitOps/action-authenticate-aks) | Authenticates to the Azure AKS cluster. |
| [**action-conjur-k8s-secret**](https://github.com/BHGitOps/action-conjur-k8s-secret) | Creates Kubernetes generic secrets using values sourced from Conjur. |
| [**action-gh-secrets-to-k8s**](https://github.com/BHGitOps/action-gh-secrets-to-k8s) | Creates Kubernetes secrets using GitHub‑stored JSON secrets. |
| [**action-create-k8s-configmaps**](https://github.com/BHGitOps/action-create-k8s-configmaps) | Creates ConfigMaps using files or variables. |
| [**action-create-k8s-service-account**](https://github.com/BHGitOps/action-create-k8s-service-account) | Provisions a Kubernetes service account with Azure AD Workload Identity or service account annotations. |
| [**action-azure-aks-deploy**](https://github.com/BHGitOps/action-azure-aks-deploy) | Deploys application workloads to AKS using Kubernetes manifests. |
| [**action-k8s-external-ip**](https://github.com/BHGitOps/action-k8s-external-ip) | Extracts the external IP from a Kubernetes service. |
| [**action-docker-tag-image**](https://github.com/BHGitOps/action-docker-tag-image) | Re‑tags the image for additional processing or promotion. |
| [**action-docker-save-image**](https://github.com/BHGitOps/action-docker-save-image) | Saves the Docker image as a .tar file for artifact storage. |
| [**action-upload-artifacts**](https://github.com/BHGitOps/action-upload-artifacts) | Uploads image tarballs and other build/deploy artifacts. |
| [**action-docker-cleanup-images**](https://github.com/BHGitOps/action-docker-cleanup-images) | Cleans up Docker images from the runner to save space. |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Performs final cleanup of runner artifacts and temporary files. |

### 5. ACR Push (Target) 📦
This job takes the Source image and pushes it into the Target Azure Account’s ACR registry, enabling cross-account promotion.

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checks out the repository for the ECR push workflow. |
| [**action-download-artifact**](https://github.com/BHGitOps/action-download-artifact) | Downloads the previously built image artifact (e.g., the saved tar). |
| [**action-docker-setup**](https://github.com/BHGitOps/action-docker-setup) | Sets up Docker on the runner for image operations. |
| [**action-docker-tag-image**](https://github.com/BHGitOps/action-docker-tag-image) | Loads the saved image and applies the proper ECR repository tag(s). |
| [**action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Login to Azure Portal |
| [**action-azure-install-cli**](https://github.com/BHGitOps/action-azure-install-cli) | Install Azure CLI |
| [**action-acr-login**](https://github.com/BHGitOps/action-acr-login) | Action for Container Registry Login |
| [**action-acr-push**](https://github.com/BHGitOps/action-acr-push) | Pushes the tagged Docker image to the specified Azure ACR repository. |
| [**action-docker-cleanup-images**](https://github.com/BHGitOps/action-docker-cleanup-images) | Cleans up local Docker images to free runner space. |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Performs final runner cleanup (artifacts/temp files), always runs. |

### 6. Deploy AKS (Target) ☸️
Deploys the image from Target ACR into the Target Azure AKS cluster, performing final production/stage deployment steps.

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checks out the repository to load deployment manifests and configuration. |
| [**action-docker-setup**](https://github.com/BHGitOps/action-docker-setup) | Sets up Docker for handling container images on the runner. |
| [**action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Login to Azure Portal |
| [**action-azure-install-cli**](https://github.com/BHGitOps/action-azure-install-cli) | Install Azure CLI |
| [**action-acr-login**](https://github.com/BHGitOps/action-acr-login) | Action for Container Registry Login |
| [**action-acr-pull**](https://github.com/BHGitOps/action-acr-pull) | Pulls the specified Docker image from Azure ACR. |
| [**action-get-image-digest**](https://github.com/BHGitOps/action-get-image-digest) | Retrieves the SHA256 digest of the container image for AKS deployment. |
| [**action-conjur-fetch-secrets**](https://github.com/BHGitOps/action-conjur-fetch-secrets) | Fetches secrets from CyberArk Conjur for Kubernetes deployment usage. |
| [**action-wiz-setup**](https://github.com/BHGitOps/action-wiz-setup) | Sets up the Wiz CLI for security scanning. |
| [**action-container-scan**](https://github.com/BHGitOps/action-container-scan) | Performs Wiz container scanning using image tag and digest. |
| [**action-install-kubectl**](https://github.com/BHGitOps/action-install-kubectl) | Installs kubectl to interact with the Kubernetes cluster. |
| [**action-authenticate-aks**](https://github.com/BHGitOps/action-authenticate-aks) | Authenticates to the Azure AKS cluster. |
| [**action-conjur-k8s-secret**](https://github.com/BHGitOps/action-conjur-k8s-secret) | Creates Kubernetes generic secrets using values sourced from Conjur. |
| [**action-gh-secrets-to-k8s**](https://github.com/BHGitOps/action-gh-secrets-to-k8s) | Creates Kubernetes secrets using GitHub‑stored JSON secrets. |
| [**action-create-k8s-configmaps**](https://github.com/BHGitOps/action-create-k8s-configmaps) | Creates ConfigMaps using files or variables. |
| [**action-create-k8s-service-account**](https://github.com/BHGitOps/action-create-k8s-service-account) | Provisions a Kubernetes service account with Azure AD Workload Identity or service account annotations. |
| [**action-azure-aks-deploy**](https://github.com/BHGitOps/action-azure-aks-deploy) | Deploys application workloads to AKS using Kubernetes manifests. |
| [**action-k8s-external-ip**](https://github.com/BHGitOps/action-k8s-external-ip) | Extracts the external IP from a Kubernetes service. |
| [**action-docker-cleanup-images**](https://github.com/BHGitOps/action-docker-cleanup-images) | Cleans up Docker images from the runner to save space. |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Performs final cleanup of runner artifacts and temporary files. |

---

## Changelog 📝

| Version | Date       | Tags                                                                 | Changes |
|--------|------------|----------------------------------------------------------------------|---------|
| **v3**  | 2025-12-15 | CyberArk Conjur integration, enhanced multi-cluster security, unified secret handling | - **Added:** Full CyberArk Conjur integration across Docker Build, Source Deploy, and Target Deploy jobs<br>- **Added:** `conjur-variable-json` input and Conjur-based secret creation using `action-conjur-k8s-secret@v1`<br>- **Added:** Support for Conjur TLS and config injection into AKS pipelines<br>- **Improved:** Wiz scanning flows with digest‑based scanning and environment‑specific Conjur authentication<br>- **Enhanced:** Secret management with source/target Conjur workload separation |
| **v2**  | 2025-11-03 | Multi-environment deployment, source–target promotion, advanced artifact handling | - **Added:** Full source → target AKS promotion pipeline (ACR Push + AKS Deploy)<br>- **Added:** Parallel source/target registry and cluster configurations<br>- **Added:** Docker retagging, improved artifact naming, and digest-based Wiz scanning<br>- **Improved:** Docker cleanup, artifact download/upload reliability, and ACR login handling<br>- **Enhanced:** Super-linter integration and GitHub App token support for submodules |
| **v1**  | 2025-06-17 | Initial release                                                       | - **Added:** AKS build → Docker build → ACR push → AKS deploy workflow<br>- **Added:** Basic Kubernetes secret, ConfigMap, and service account provisioning<br>- **Added:** Wiz image scanning and NuGet package restore support |

---
## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>
  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1613529089/workflow-azure-aks+v2+Reusable+CI+CD+Workflow+for+Azure+AKS+Deployment">workflow-azure-aks</a>
    </strong>
    <p>
      Workflow-azure-aks - Reusable GitHub workflow building and deploying applications to Azure AKS.
    </p>
  </article>  

---

## Feedback/Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
