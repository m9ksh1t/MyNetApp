# prepare-vars-for-environment

This file is a pointer to the canonical documentation maintained in the `workflow-aws-eks` repository.

👉 Please see the canonical `prepare-vars-for-environment.md` document here:  
[**prepare-vars-for-environment.md**](https://github.com/BHGitOps/workflow-aws-eks/blob/main/docs/common/prepare-vars-for-environment.md)
