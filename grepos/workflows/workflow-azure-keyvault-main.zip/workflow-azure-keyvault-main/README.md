<h1 align="center">
  <a href=".github/workflows/workflow.yml">workflow-azure-keyvault</a>
</h1>

## Overview
This GitHub Actions workflow provides a reusable solution for managing secrets in **Azure Key Vault**. It supports creating, updating, and deleting secrets, with optional CyberArk Conjur integration for dynamic secret retrieval. Secret operations can be driven by individual inputs or by a **JSON file** for bulk processing.

The workflow authenticates to Azure using a **Service Principal** and performs the requested Key Vault operation — upserting secrets with optional expiry and version management, deleting secrets, or syncing secrets from a JSON configuration file.

---

## Getting Started

These documents will help you get up to speed with our engineering practices and tools.

---

## Reusable Workflow Summary

The table outlines the essential details of the reusable Azure Key Vault workflow, including its name, current stable version, supported cloud environment and services, compatible tech stacks, and confirmation of Conjur integration.

| Workflow Name | [**workflow-azure-keyvault**](.github/workflows/workflow.yml) |
| :------| :-------------|
| **Latest Stable Version** | [**v4**](https://github.com/BHGitOps/workflow-azure-keyvault/tree/v4) |
| **Current Version** | [**v4**](https://github.com/BHGitOps/workflow-azure-keyvault/tree/v4) |
| **Cloud Environment** | Azure |
| **Cloud Services** | Azure Key Vault |
| **TechStacks** | N/A |
| **Is Conjur integrated** | Yes*¹ (optional) |
| **High Availability Supported** | N/A |

*¹ - CyberArk Conjur is integrated into this workflow to securely manage sensitive information such as API keys, credentials, and environment variables. Secrets can be fetched dynamically during build and deployment steps, ensuring compliance and security. **Using Conjur is optional**—you may supply the same values via GitHub environment secrets instead.

---

## Reusable Workflow Upgrade Guide

It is considered a best practice to keep your caller/application workflows updated to reference the latest stable version of the reusable workflow. Doing so ensures you benefit from the newest features, security patches, enhancements, and bug fixes provided in this reusable workflow
For detailed upgrade paths, refer to the table below.

**N/A**

---

## Mock Caller Repositories

A mock workflow, shown below, provides a solid starting point for implementing this reusable workflow to support application deployments. Refer to the table below for the list of available caller workflows.

| Mock Repository URL | Purpose | Technology Stack |
|------------------|-------------|----------|
| [**mock-azure-keyvault**](https://github.com/BHGitOps/mock-azure-keyvault) | Provides a reference implementation for deploying a .NET application using this reusable workflow | .NET |

> **Tip:** In the mock repository, an additional job—prepare-vars-for-environment—is included to source environment‑level variables. The subsequent job typically consumes these variables from the job outputs (e.g., dev-vars-json or qa-vars-json) and injects them into each matrix item using ${{ fromJSON(...) }}.

> Refer to the [**prepare-vars-for-environment**](docs/common/prepare-vars-for-environment.md) guide for detailed instructions on retrieving environment‑level variables.
> This job is optional, the values can be hardcoded, but using it is recommended.

---

## Usage
To use this workflow in your repository:

```yaml
jobs:
  sync-keyvault-secrets:
    uses: BHGitOps/workflow-azure-keyvault/.github/workflows/workflow.yml@v4
    with:
      keyvault-name: "my-keyvault"
      ...
    secrets:
      client-id: ${{ secrets.AZURE_CLIENT_ID }}
      tenant-id: ${{ secrets.AZURE_TENANT_ID }}
      subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}
      ...
```
---

## Features
- Fetch secrets from CyberArk Conjur using provided credentials and variable paths
- Authenticate with Azure using Service Principal credentials.
- Install Azure CLI for Key Vault operations
- Export Conjur secrets to Azure Key Vault
- Validates `secrets-json` for syntax, null or empty values and values containing single or double quotes 
- Create or update secrets with advanced options (disable versions, set expiry)
- Delete secrets from Azure Key Vault
- Perform bulk operations using JSON input
- Clean up runner workspace after execution

---

## Inputs

| Name | Description | Required | Default |
|------|-------------|----------|---------|
| `keyvault-name` | Name of the Azure Key Vault where the secret will be stored | <span style='color:green'>✔️</span> | - |
| `deploy-environment` | The deployment environment (e.g., dev, qa, prod) | <span style='color:green'>✔️</span> | - |
| `deploy-runner-type` | The type of runner configuration to use for deployment execution (e.g., `azure`) | <span style='color:green'>✔️</span> | `azure` |
| `secret-name` | Name of the secret to create or update in Azure Key Vault | <span style='color:red'>❌</span> | - |
| `secret-operation` | Type of operation to perform on the secrets (e.g., delete, upsert) | <span style='color:red'>❌</span> | - |
| `disable-specific-version` | Set to true to disable a specific version of the secret after updating | <span style='color:red'>❌</span> | `false` |
| `disable-previous-versions` | Set to true to disable all previous versions of the secret after updating | <span style='color:red'>❌</span> | `false` |
| `version-id` | Version ID of the secret to disable. Used only when disabling a specific version | <span style='color:red'>❌</span> | - |
| `expiry-days` | Number of days from now to set expiry. If greater than 0, expiry will be calculated. If 0 or not provided, no expiry is set | <span style='color:red'>❌</span> | `0` |
| `update-secret-expiry` | Set to true to update the expiration date of the Azure Key Vault secret during execution | <span style='color:red'>❌</span> | `false` |
| `secrets-file-path` | Path to JSON file containing secret operations | <span style='color:red'>❌</span> | - |
| `conjur-variable-json` | JSON string containing Conjur variable mappings used for dynamic secret retrieval | <span style='color:red'>❌</span> | - |
| `failOnError` | Set to true to fail the workflow when a secret operation encounters an error | <span style='color:red'>❌</span> | `true` |
| `fail-on-secrets-json-error` | Set to true to fail the workflow when a secret json encounters an error | <span style='color:red'>❌</span> | `true` |
| `resource-group` | Azure resource group containing the target Key Vault; required for RBAC validation | <span style='color:green'>✔️</span> | - |

---

## Secrets

| Name | Description | Required |
|------|-------------|----------|
| `client-id` | Azure Service Principal Client ID used for authentication with Azure resources | <span style='color:green'>✔️</span> |
| `subscription-id` | Azure Subscription ID where the resources are deployed | <span style='color:green'>✔️</span> |
| `tenant-id` | Azure Active Directory Tenant ID associated with the Service Principal for authentication | <span style='color:green'>✔️</span> |
| `secrets-json` | JSON object containing additional secret values required for deployment or configuration | <span style='color:red'>❌</span> |
| `conjur-appliance-url` | URL path to the CyberArk Conjur instance endpoint | <span style='color:red'>❌</span> |
| `conjur-account` | Account configured for the Conjur instance during deployment | <span style='color:red'>❌</span> |
| `conjur-workload-id` | Host ID granted to your application by Conjur when created via policy | <span style='color:red'>❌</span> |
| `conjur-api-key` | API key associated with your Host ID for authentication | <span style='color:red'>❌</span> |

---

## Jobs & Steps

### Job 1: sync-secrets
Authenticates to Azure and performs the requested Key Vault secret operation.

#### Steps
- Checkout Repository
- Login to Azure
- Install Azure CLI
- Fetch Secrets from Conjur (if `conjur-variable-json` is provided)
- Validates `secrets-json` for syntax, null or empty values and values containing single or double quotes
- Process Azure KeyVault Secrets operation based on JSON input file (if `secrets-file-path` is provided)
- Create or Update multiple Secrets in Azure Key Vault (if `secret-operation` is `upsert`)
- Delete Secret from Azure Key Vault (if `secret-operation` is `delete`)
- Clean Up Runner workspace

---

## **Example Scenarios**
- **Upsert** a secret in Azure Key Vault with an expiry date
- **Delete** a secret from Azure Key Vault
- **Disable** a specific version or all previous versions of a secret
- **Bulk sync** secrets from a JSON configuration file
- **Fetch secrets dynamically** from CyberArk Conjur before writing to Key Vault

---

## Best Practices
- Use Service Principal with least-privilege access scoped to the target Key Vault only
- Set expiry dates on all secrets using `expiry-days` to enforce secret rotation policies
- Use `disable-previous-versions: true` after updates to reduce the risk of stale credentials being used
- Store all Azure credentials (`client-id`, `tenant-id`, `subscription-id`) as GitHub environment secrets — never hardcode them
- Use `secrets-file-path` for bulk operations to keep caller workflows clean and maintainable
- Use Conjur integration for dynamic secret retrieval in environments where centralized credential management is enforced
- Separate environments by configuring distinct GitHub environments (`dev`, `qa`, `prod`) with their own secret sets
- Test secret operations in non-production environments before executing against production Key Vaults
- Review GitHub Actions logs after each run to confirm the expected operation was performed

---

## Changelog 📝

All notable changes to this project will be documented in this section.

| Version | Date       | Tags                        | Changes |
|:------:|:------------|------------------------------|---------|
| **v4** | 2026‑04‑13 | Stable Release, Azure Key Vault | **Added:** Reusable workflow for managing Azure Key Vault secrets with upsert, delete, expiry, and Conjur integration |

---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>
  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1577812021/workflow-azure-keyvault+-+Reusable+Workflow+to+Manage+Azure+Key+Vault+Secretsᵈ²</a>
    </strong>
    <p>
      workflow-azure-keyvault - Reusable GitHub workflow for creating, updating, and deleting secrets in Azure Key Vault.
    </p>
  </article>

---

## Feedback/Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
