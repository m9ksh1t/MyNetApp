<h1 align="center">workflow-azure-app-configuration</h1>

## Overview
This repository provides a reusable GitHub workflow to **manage Azure App Configuration**.  
It supports **upsert** and **delete** operations for **feature flags**, **key-values**, **Key Vault references**, and **configuration files**, and offers **import/export** synchronization with **Azure App Service**—all authenticated securely using an Azure Service Principal.

---

## Getting Started
These documents will help you get up to speed with our engineering practices and tools.

---

## Reusable Workflow Summary

| Workflow Name | workflow-azure-app-configuration |
| ------------- | ------------------------------- |
| **Latest Stable Version** | v2 |
| **Current Version** | v2 |
| **Cloud Environment** | Azure |
| **Cloud Services** | App Configuration, App Service *(integration)* |
| **TechStacks** | Any (language-agnostic; configuration management) |
| **Is Conjur integrated** | No |

---

## Mock Caller Repositories

A mock workflow is available to help you implement and validate this reusable workflow.

| Mock Repository URL | Purpose | Technology Stack |
|---------------------|---------|------------------|
| [**mock-azure-app-config**](https://github.com/BHGitOps/mock-azure-app-config) | Demonstrates feature flag, key-value, KV reference, and import/export operations with Azure App Configuration | Any |

---

## Key Features & Capabilities
* **Feature Flags**: Upsert or delete flags from **JSON string** or **file**.
* **Key-Values & Key Vault References**: Upsert or delete key-value pairs and **Key Vault references**.
* **Configuration Files**: Upsert or delete configuration files (e.g., **json**, **yml**, **properties**) to/from App Configuration.
* **Import/Export with App Service**: Sync configuration between **App Service** and **App Configuration**.
* **Azure Service Principal Authentication** for all operations.
* **Cleanup** of runner workspace to remove temporary artifacts.

> [!TIP]  
> Start by **upserting a single feature flag** or **one key-value** to validate access and scope. Add labels to logically separate environment-specific configuration.

> [!NOTE]  
> **App Configuration** is the recommended source of truth for feature flags and configuration values. Use labels for versioning and environment separation (e.g., `dev`, `qa`, `prod`).

---

## Prerequisites

- An existing **Azure App Configuration** instance (`appconfig-name`).
- **Azure Service Principal** with permissions on:
  - App Configuration data plane (for key-values, flags, references)
  - App Service (only if using import/export)
- (Optional) **Azure App Service** name if using import/export operations.
- **GitHub environment** configured for the target deployment environment.

> [!IMPORTANT]  
> Coordinate with your Cloud/IaC team to provision the App Configuration instance and to grant the Service Principal the **necessary role assignments** before running this workflow.

---

## Usage

### Example: Upsert Feature Flags from JSON

```yaml
uses: BHGitOps/workflow-azure-app-configuration/.github/workflows/workflow.yml@v2
with:
  operation: "upsert"
  appconfig-name: "my-app-config"
  manage-feature-flags: "true"
  feature-flags-json: '[{"id":"FeatureA","enabled":true}]'
  deploy-runner-type: "azure"
  deploy-environment: "dev"
secrets:
  client-id: ${{ secrets.CLIENT_ID }}
  tenant-id: ${{ secrets.TENANT_ID }}
  subscription-id: ${{ secrets.SUBSCRIPTION_ID }}
```

### Example: Upsert Key-Value and Key Vault Reference

```yaml
uses: BHGitOps/workflow-azure-app-configuration/.github/workflows/workflow.yml@v2
with:
  operation: "upsert"
  appconfig-name: "my-app-config"
  manage-key-value-vault: true
  configuration-explorer-create-type: "key-value"
  key-name: "app:settings:ServiceUrl"
  key-value: "https://api.dev.contoso.com"
  key-label: "dev"
  content-type: "text/plain"
  deploy-runner-type: "azure"
  deploy-environment: "dev"
secrets:
  client-id: ${{ secrets.CLIENT_ID }}
  tenant-id: ${{ secrets.TENANT_ID }}
  subscription-id: ${{ secrets.SUBSCRIPTION_ID }}
```

```yaml
# Example for Key Vault reference
uses: BHGitOps/workflow-azure-app-configuration/.github/workflows/workflow.yml@v2
with:
  operation: "upsert"
  appconfig-name: "my-app-config"
  manage-key-value-vault: true
  configuration-explorer-create-type: "key-vault-reference"
  key-name: "app:secrets:DbPassword"
  key-label: "dev"
  secret-identifier: "https://my-vault.vault.azure.net/secrets/DbPassword/<version>"
  deploy-runner-type: "azure"
  deploy-environment: "dev"
secrets:
  client-id: ${{ secrets.CLIENT_ID }}
  tenant-id: ${{ secrets.TENANT_ID }}
  subscription-id: ${{ secrets.SUBSCRIPTION_ID }}
```

---

## Inputs
| Name | Description | Required | Type | Default |
|------|-------------|--------|------|---------|
| `operation` | Operation mode: `upsert` or `delete` | ✅ | string | - |
| `appconfig-name` | Name of the Azure App Configuration instance | ✅ | string | - |
| `feature-flags-json` | JSON array of feature flags | ❌ | string | - |
| `feature-flags-file` | Path to a JSON file with feature flags | ❌ | string | - |
| `deploy-runner-type` | GitHub runner where the job executes | ✅ | string | azure (self-hosted Azure runner) |
| `deploy-environment` | Deployment environment (e.g., dev/qa/prod) | ✅ | string | - |
| `key-name` | Key name to add or upsert | ❌ | string | - |
| `key-value` | Value to set for the key | ❌ | string | - |
| `key-label` | Optional label (e.g., env) | ❌ | string | - |
| `content-type` | Content type (e.g., `application/json`, `text/plain`) | ❌ | string | - |
| `manage-feature-flags` | Manage feature flags (`"true"` to enable) | ❌ | string | false |
| `source-type` | Import/export source type (e.g., `appservice`) | ❌ | string | - |
| `file-path` | File path used for configuration file operations | ❌ | string | - |
| `file-format` | File format (`json`, `yml`, `properties`, etc.) | ❌ | string | - |
| `appservice-account` | Azure App Service application name (for import/export) | ❌ | string | - |
| `manage-key-value-vault` | Manage key-values and KV references | ❌ | boolean | false |
| `import-export-appservice-to-appconfig` | Enable import/export with App Service | ❌ | boolean | false |
| `manage-configuration-files` | Manage configuration files (upsert/delete) | ❌ | boolean | false |
| `configuration-explorer-create-type` | `key-value` or `key-vault-reference` | ❌ | string | - |
| `secret-identifier` | Key Vault secret URI (required for KV reference) | ❌ | string | - |

---

## Secrets
| Name | Description | Required | Type | Default |
|------|-------------|--------|------|---------|
| `client-id` | Azure Service Principal Client ID | ❌*¹ | string | - |
| `tenant-id` | Azure Active Directory Tenant ID | ❌*¹ | string | - |
| `subscription-id` | Azure Subscription ID | ❌*¹ | string | - |

*¹ Required for all Azure operations (login, App Configuration changes, and import/export).

> [!CAUTION]  
> Never log or echo secrets. If a secret is suspected to be exposed, **rotate immediately** and notify your security team.

---

## Jobs & Steps
- **Manage Feature Flags** → **Manage Key-Values / KV References** → **Manage Configuration Files** → **Import/Export App Service** → **Cleanup**

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checkout repository |
| [**action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Logs into Azure and optionally authorizes NuGet when using Azure Artifacts |
| [**action-azure-install-cli**](https://github.com/BHGitOps/action-azure-install-cli) | Install Azure CLI |
| [**action-gh-azure-app-configuration**](https://github.com/BHGitOps/action-gh-azure-app-configuration) | Creates missing Azure App Configuration feature flags and toggles them based on provided JSON input or file |
| [**action-delete-azure-app-configuration**](https://github.com/BHGitOps/action-delete-azure-app-configuration) | Deletes Azure App Configuration feature flags based on input |
| [**action-app-configuration-crud-operations**](https://github.com/BHGitOps/action-app-configuration-crud-operations) | Adds, updates, or deletes a key-value pair in Azure App Configuration, optionally as a Key Vault reference |
| [**action-app-configuration-file-handler**](https://github.com/BHGitOps/action-app-configuration-file-handler) | Upsert or delete leaf-only configuration values from JSON, YAML, or Properties file into Azure App Configuration |
| [**action-app-configuration-import-export-config**](https://github.com/BHGitOps/action-app-configuration-import-export-config) | Import or Export key-value pairs between Azure App Configuration and App Service |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Cleans remaining artifacts from the runner at the end of the job. |

---

## Changelog 📝

| Version | Date       | Tags                                         | Changes |
|--------|------------|----------------------------------------------|---------|
| **v2**  | 2025-11-17 | Feature expansion, reliability improvements  | - **Added:** Upsert/Delete for key-values and Key Vault references<br>- **Added:** Upsert/Delete of configuration files (json/yml/properties)<br>- **Added:** Import/Export flows with App Service<br>- **Improved:** Operational guards and cleanup |
| **v1**  | 2025-06-17 | Initial Release                              | - **Added:** Basic feature flag management (upsert/delete)<br>- **Added:** Azure login and CLI setup |

---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1695219714/workflow-azure-app-configuration+V1">workflow-azure-app-configurationᵈ²</a>
    </strong>
    <p>
      Reusable GitHub workflow to manage Azure App Configuration: feature flags, key-values, Key Vault references, configuration files, and import/export with App Service.
    </p>
  </article>  

---

## Feedback/Need Help? 📬
If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
