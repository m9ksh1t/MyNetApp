<h1 align="center">workflow-aws-amplify</h1>

## Overview
This repository provides a reusable GitHub workflow for **building and deploying applications to AWS Amplify**.  
It supports multi-framework builds (.NET, Node/Yarn, Angular, static sites), performs optional linting, handles artifact preparation, integrates Azure DevOps package feeds when needed, and deploys build artifacts to an **AWS Amplify App + Branch** using secure OIDC authentication.

This workflow provides a standardized CI/CD experience for Amplify‑based application hosting across multiple environments.

---

## Getting Started
These documents will help you get up to speed with our engineering practices and tools.

---

## Reusable Workflow Summary

| Workflow Name | workflow-aws-amplify |
|------------------|----------------------|
| **Latest Stable Version** | v1 |
| **Current Version** | v1 |
| **Cloud Environment** | AWS |
| **Cloud Services** | AWS Amplify |
| **TechStacks** | .NET, Angular, Node/Yarn, Static Web Apps |
| **Is Conjur integrated** | No |

---

## Mock Caller Repositories

A mock workflow is available to help you understand how to integrate AWS Amplify deployment in your pipelines.

| Mock Repository URL | Purpose | Technology Stack |
|----------------------|----------|------------------|
| [**mock-amplify-deploy-angular**](https://github.com/BHGitOps/mock-amplify-deploy-angular) | Sample implementation for AWS Amplify deployments | .NET / Angular / Node |

---

## Key Features & Capabilities
* Build and restore application dependencies across multiple frameworks.
* Optional linting via Super Linter.
* JSON environment transformation using GitHub Secrets.
* Support for Azure DevOps or GitHub-based package feeds.
* Publish build artifacts and upload them for downstream deployment.
* Deploy static websites or front-end applications to AWS Amplify via:
  - **Amplify App ID**
  - **Amplify Branch name**
* Uses AWS IAM OIDC for secure, short-lived authentication.
* Polls Amplify deployment status until completion using configurable wait intervals.
* Cleans runner workspace after deployment.

> [!TIP]  
> For multi-environment pipelines (dev → test → prod), use the same Amplify App ID and deploy to different branches (e.g., dev, staging, prod) for clean promotion.

> [!NOTE]  
> If your repo uses Git submodules, this workflow can generate GitHub App tokens for authenticated checkout.

---

## Prerequisites

### Required AWS Setup
- AWS Amplify App configured
- Amplify branches created for each environment
- IAM Role for OIDC with permissions:
  - `amplify:StartDeployment`
  - `amplify:GetJob`
  - `amplify:ListJobs`
  - S3 access to Amplify artifact buckets

### Required Azure Setup (Optional)
If your build requires Azure DevOps feed access:
- Active Azure organization
- Azure DevOps PAT
- Feed permissions assigned

### Required GitHub Setup
- Store GitHub App private key & App ID if using submodules
- Store environment secrets for JSON transformations if needed


> [!IMPORTANT]  
> Ensure you deploy from the correct Amplify branch/tag per environment:
> - **dev** → `develop`
> - **qa** → `main` *(qa can be deployed only from `main`)*
> - **prod** → `release/*` branch **or** a **release tag** *(prod can be deployed only from a release branch or a release tag)*

---

## Usage

### Example: Build and Deploy to AWS Amplify

```yaml
name: Build and Deploy to AWS Amplify

on:
  workflow_dispatch:

jobs:
  build-and-deploy:
    uses: BHGitOps/workflow-aws-amplify/.github/workflows/workflow.yml@v1
    with:
      deploy-environment: "dev"
      deploy-runner-type: "aws-westus2-pool"
      build-runner: "ubuntu-latest"
      amplify-app-id: "d2abc123example"
      amplify-branch: "develop"
      framework-type: "node"
      framework-version: "20.x"
      working-directory: "src/app"
      file-name-to-build: "unused-for-node"
      build-artifacts: "dist/"
      artifact-name: "app-artifact"
      oidc-assume-role: "arn:aws:iam::123456789012:role/GitHubOIDCRole"
      role-session-name: "amplify-deploy-session"
      aws-region: "us-west-2"
    secrets:
      github-token: ${{ secrets.GITHUB_TOKEN }}
      client-id: ${{ secrets.AZURE_CLIENT_ID }}
      tenant-id: ${{ secrets.AZURE_TENANT_ID }}
      subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}
      secrets-json: ${{ secrets.APP_SETTINGS_JSON }}
```

---

## Inputs

| Name | Description | Required | Type | Default |
|------|-------------|----------|------|---------|
| `framework-type` | Framework to use (dotnet, node, angular, etc.) | ❌ | string | - |
| `framework-version` | Version of the framework to install | ❌ | string | - |
| `yarn-version` | Version of Yarn to install | ❌ | string | - |
| `working-directory` | Working directory of the application | ❌ | string | - |
| `dependency-version` | Version of the dependency manager to install | ❌ | string | - |
| `file-name-to-restore` | File used for dependency restore | ❌ | string | - |
| `nuget-config-path` | Path to NuGet config for .NET | ❌ | string | - |
| `configuration` | Build configuration | ❌ | string | - |
| `file-name-to-build` | Solution/project file for .NET | ❌ | string | - |
| `file-name-to-publish` | Publish file for .NET | ❌ | string | - |
| `build-artifacts` | Build output folder | ❌ | string | output/ |
| `artifact-name` | Artifact name for build outputs | ❌ | string | build-artifacts |
| `deploy-runner-type` | Runner for deployment | ✅ | string | ubuntu-latest |
| `build-runner` | Runner for build | ❌ | string | ubuntu-latest |
| `skip-deploy-job` | Skip deployment stage | ❌ | boolean | false |
| `package-source-org` | GitHub/Azure DevOps org | ❌ | string | BHGitOps |
| `target-file` | JSON file for transformations | ❌ | string | - |
| `package-source` | NuGet package source | ❌ | string | azure-artifacts |
| `azure-org` | Azure DevOps org | ❌ | string | Bannerhealth |
| `azure-feed` | Azure Artifacts feed | ❌ | string | - |
| `azure-user-name` | Username for Azure DevOps | ❌ | string | AzureDevOps |
| `azure-pat` | Azure PAT | ❌ | string | - |
| `package-source-name` | NuGet source alias | ❌ | string | Azure |
| `repositories-owner` | GitHub org/user owning repos | ❌ | string | BHGitOps |
| `submodules` | Enable submodule token generation | ❌ | boolean | false |
| `repositories` | Repos requiring GitHub App token | ❌ | string | - |
| `skip-clean` | Skip clean step | ❌ | boolean | false |
| `deploy-environment` | Deployment environment | ✅ | string | - |
| `amplify-app-id` | AWS Amplify App ID (required when deploying) | ❌ | string | - |
| `amplify-branch` | Amplify branch name (required when deploying) | ❌ | string | - |
| `wait-seconds` | Seconds between status polling | ❌ | string | 10 |
| `oidc-assume-role` | AWS IAM role for OIDC | ❌ | string | - |
| `role-session-name` | AWS role session name | ❌ | string | - |
| `aws-region` | AWS region | ❌ | string | us-west-2 |
| `artifact-download-path` | Location to download artifact | ❌ | string | . |
| `include-super-linter` | Enable Super Linter for code analysis | ❌ | boolean | false |
| `linter-filter-regex-include` | Regex pattern for files to include in linting | ❌ | string | - |
| `linter-filter-regex-exclude` | Regex pattern for files to exclude from linting | ❌ | string | - |
| `linter-rules-config-path` | Path to Super Linter rules/config file | ❌ | string | - |
---

## Secrets

| Name | Description | Required |
|------|-------------|----------|
| `client-id` | Azure App Registration Client ID | ❌ |
| `tenant-id` | Azure Tenant ID | ❌ |
| `subscription-id` | Azure Subscription ID | ❌ |
| `secrets-json` | JSON used for transformations | ❌ |
| `gh-app-id` | GitHub App ID | ❌ |
| `gh-app-private-key` | GitHub App Private Key | ❌ |
| `github-token` | Token for GitHub packages or checkout | ❌ |

> [!CAUTION]  
> Never echo secrets in logs. Rotate secrets immediately if exposure is suspected.

---

## Jobs & Steps

### 1. Build 🛠️  
Builds the application, installs dependencies, performs linting, uploads artifacts.

**Key Actions**
| Action | Purpose |
|--------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Check out the repository with optional submodules |
| [**action-generate-github-app-token**](https://github.com/BHGitOps/action-generate-github-app-token) | Generates GitHub App token for private repos |
| [**action-super-linter**](https://github.com/BHGitOps/action-super-linter) | Framework linting |
| [**action-setup-framework**](https://github.com/BHGitOps/action-setup-framework) | Installs runtime/framework |
| [**action-setup-dependency**](https://github.com/BHGitOps/action-setup-dependency) | Installs dependency managers |
| [**action-restore-dependencies**](https://github.com/BHGitOps/action-restore-dependencies) | Restore project dependencies |
| [**action-clean**](https://github.com/BHGitOps/action-clean) | Optional clean operation |
| [**action-json-transform**](https://github.com/BHGitOps/action-json-transform) | JSON environment transformation |
| [**action-build**](https://github.com/BHGitOps/action-build) | Build the application |
| [**action-publish**](https://github.com/BHGitOps/action-publish) | Publish .NET artifacts |
| [**action-upload-artifacts**](https://github.com/BHGitOps/action-upload-artifacts) | Upload build outputs |

---

### 2. Deploy to Amplify 🚀  
Deploys the built artifact to AWS Amplify using OIDC.

**Key Actions**
| Action | Purpose |
|--------|---------|
| [**action-configure-aws-credentials**](https://github.com/BHGitOps/action-configure-aws-credentials) | Authenticates to AWS using OIDC |
| [**action-install-aws-cli**](https://github.com/BHGitOps/action-install-aws-cli) | Install AWS CLI |
| [**action-download-artifact**](https://github.com/BHGitOps/action-download-artifact) | Downloads build output |
| [**action-aws-amplify-deploy**](https://github.com/BHGitOps/action-aws-amplify-deploy) | Deploys to AWS Amplify application branch |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Final cleanup |

---

## Changelog 📝

| Version | Date | Tags | Changes |
|--------|------|------|---------|
| **v1** | 03-06-2026 | Initial Release | - Added AWS Amplify deployment flow<br>- Added multi-framework build pipeline<br>- Added OIDC-based AWS deployment |

---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>

---

## Feedback / Need Help? 📬  
If you have questions or need assistance, reach out to your team lead or Platform Engineering Support.  
We're here to help you succeed!
