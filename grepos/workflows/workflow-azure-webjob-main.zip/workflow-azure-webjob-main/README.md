# workflow-azure-webjob

A reusable GitHub Actions workflow to build and deploy WebJobs (and standard web apps) to an Azure Web App.

---

## Overview

This workflow is designed to be called from other workflows (`workflow_call`). It handles the full CI/CD lifecycle:

1. **Build** — checks out the repository, sets up the framework, restores dependencies, builds and publishes the application (single project or multiple WebJob projects), and uploads the resulting artifacts.
2. **Deploy** — downloads artifacts, authenticates to Azure, optionally updates App Settings and Connection Strings, and deploys to an Azure Web App.

---

## Usage

```yaml
jobs:
  deploy:
    uses: BHGitOps/workflow-azure-webjob/.github/workflows/workflow.yml@[full semantic version]
    with:
      deployment-resource-type: '[value]'
      deploy-environment: '[value]'
      deploy-runner-type: '[value]'
      skip-deploy-job: [value]
    secrets:
      client-id: ${{ secrets.AZURE_CLIENT_ID }}
      subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}
      tenant-id: ${{ secrets.AZURE_TENANT_ID }}
      secrets-json: ${{ secrets.SECRETS_JSON }}
