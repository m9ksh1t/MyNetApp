<h1 align="center">
  <a href=".github/workflows/workflow.yml">workflow-aws-lexbots</a>
</h1>

## Overview
This repository provides a reusable GitHub workflow for deploying and managing **Amazon Lex V2 Bots** across multiple environments (e.g., dev, test, prod).  
It enables secure authentication using AWS OIDC, automates bot resource creation (bots, locales, intents), supports version publishing and promotion, provides rollback capability, and includes environment-based smoke testing.

This reusable workflow helps teams maintain **consistent, repeatable, and secure Lex Bot deployments** across multiple AWS accounts or pipeline environments.

---

## Getting Started

These documents will help you get up to speed with our engineering practices and tools.

---

## Reusable Workflow Summary

The table below outlines essential details of the reusable AWS Lex Bots deployment workflow, including supported cloud provider, service, features, and availability.

| Workflow Name | <a href=".github/workflows/workflow.yml"><strong>workflow-aws-lexbots</strong></a> |
| :------ | :------------- |
| **Latest Stable Version** | **v1** |
| **Current Version** | **v1** |
| **Cloud Environment** | AWS |
| **Cloud Services** | Amazon Lex V2 |
| **TechStacks** | Lex Bot JSON Export Structure |
| **High Availability Supported** | Yes |
| **Supports Promotion Across Environments** | Yes |
| **Rollback Supported** | Yes |

---

## Mock Caller Repositories

A mock workflow is provided below to help teams quickly bootstrap deployments using this reusable workflow.

| Mock Repository URL | Purpose | Technology Stack |
|----------------------|---------|------------------|
| [**mock-aws-lexbots**](https://github.com/BHGitOps/mock-aws-lexbots) | Provides a reference implementation for deploying Amazon Lex V2 bots using this reusable workflow | Lex V2 |

> **Tip:** In the mock repository, `.env` files are used per environment (dev/test/prod) to supply configuration variables.  
> Your application workflow should load these variables before invoking this reusable workflow. This approach is recommended for consistency and maintainability.

---

## Key Features & Capabilities
* Automatically discover bots from folder structure.  
* Create or update Lex V2 bot drafts.  
* Apply locales and intents dynamically.  
* Build and validate locale configurations.  
* Publish bot versions with waiting support.  
* Promote bot versions using environment‑specific aliases.  
* Perform smoke‑testing using provided utterances.  
* Roll back aliases to previously published versions.  
* Secure AWS authentication using GitHub OIDC.  
* Clean up CI runner storage after workflow execution.  

> [!TIP]  
> It’s recommended to start with just a single environment (e.g., dev). Promotion workflows can be configured later for multi‑environment bot lifecycle management.

---

## Prerequisites

- AWS IAM Role configured for GitHub OIDC trust.  
- Proper AWS Lex V2 permissions attached to the role.  
- `.env` file in your repository defining environment-level variables used by bots.  
- A folder structure for bots similar to the following:

```
bots/
  ClaimsBot/
    locales/
    intents/
  ScheduleBot/
    locales/
    intents/
```

> [!IMPORTANT]  
> Before using this reusable workflow to deploy Amazon Lex V2 Bots, ensure your IAM Role ARN, AWS permissions, and bot folder structure are fully in place.  
> Please coordinate with the Platform Engineering (PE) / Infrastructure-as-Code teams for IAM and configuration setup.

---

## Usage

#### ✅ Example: Apply (Create/Update Bots)
```yaml
uses: BHGitOps/workflow-aws-lexbots/.github/workflows/workflow.yml@v1
with:
  action: "apply"
  deploy-environment: "dev"
  bot-directory: "bots/"
  env-file-path: "configs/dev.env"
  aws-region: "us-west-2"
  oidc-assume-role: "arn:aws:iam::111111111111:role/github-oidc-role"
  role-session-name: "dev-session"
  deploy-runner-type: "ubuntu-latest"
```

#### ✅ Example: Promote (Publish Versions + Alias Update)
```yaml
uses: BHGitOps/workflow-aws-lexbots/.github/workflows/workflow.yml@v1
with:
  action: "promote"
  deploy-environment: "test"
  bot-directory: "bots/"
  env-file-path: "configs/test.env"
  aws-region: "us-west-2"
  oidc-assume-role: "arn:aws:iam::111111111111:role/github-oidc-role"
  role-session-name: "test-session"
  deploy-runner-type: "ubuntu-latest"

```

#### ✅ Example: Rollback
```yaml

uses: BHGitOps/workflow-aws-lexbots/.github/workflows/workflow.yml@v1
with:
  action: "rollback"
  deploy-environment: "prod"
  bot-directory: "bots/"
  env-file-path: "configs/prod.env"
  aws-region: "us-west-2"
  oidc-assume-role: "arn:aws:iam::111111111111:role/github-oidc-role"
  role-session-name: "prod-session"
  deploy-runner-type: "ubuntu-latest"
  rollback-version: |
    {
      "ClaimsBot": "3",
      "ScheduleBot": "5"
    }
```

---

## Inputs
| Name | Description | Required | Type | Default |
|------|-------------|:--------:|------|---------|
| `deploy-environment` | Target environment name (dev/test/prod) | ✅ | string | - |
| `action` | apply / promote / rollback | ✅ | string | - |
| `bot-directory` | Folder containing Lex bot directories | ✅ | string | - |
| `rollback-version` | JSON map of botName → version | ❌ | string | - |
| `env-file-path` | Path to the `.env` file | ✅ | string | - |
| `aws-region` | AWS region | ✅ | string | us-west-2 |
| `role-session-name` | AWS session name | ✅ | string | - |
| `oidc-assume-role` | IAM role to assume via OIDC | ✅ | string | - |
| `locales-dir` | Directory inside bot folder for locales | ❌ | string | locales |
| `intents-dir` | Directory inside bot folder for intents | ❌ | string | intents |
| `locale-id` | Locale ID for smoke testing | ❌ | string | en_US |
| `text` | Test utterance | ❌ | string | hello |
| `wait` | Whether to wait for version availability | ❌ | string | true |
| `deploy-runner-type` | GitHub runner type | ✅ | string | - |

---


## Secrets

This reusable workflow does **not** require custom secrets because it authenticates to AWS using GitHub OIDC.  
The default `GITHUB_TOKEN` provided by GitHub Actions is sufficient.

No additional secrets need to be passed through `workflow_call.secrets`.

> [!CAUTION]  
> Teams using this workflow should continue following secure practices for managing secrets in their own repositories.  
> Secrets must never be logged. Rotate immediately if exposure is suspected.

---

## Jobs & Steps

---

## ✅ **1. Apply Draft (apply / promote)** 
This job creates/updates Lex Bots, Locales, and Intents.

### Actions Used
| Action | Purpose |
|--------|---------|
| <a href="https://github.com/BHGitOps/action-checkout">action-checkout</a> | Checkout repository |
| <a href="https://github.com/BHGitOps/action-configure-aws-credentials">action-configure-aws-credentials</a> | Configure AWS OIDC credentials |
| <a href="https://github.com/BHGitOps/action-install-aws-cli">action-install-aws-cli</a> | Install AWS CLI |
| <a href="https://github.com/BHGitOps/action-load-environment-variables">action-load-environment-variables</a> | Load environment variables (.env) |
| <a href="https://github.com/BHGitOps/action-discover-bots">action-discover-bots</a> | Discover available bots |
| <a href="https://github.com/BHGitOps/action-apply-bots">action-apply-bots</a> | Create/update Lex bots |
| <a href="https://github.com/BHGitOps/action-apply-locales">action-apply-locales</a> | Create/update locales |
| <a href="https://github.com/BHGitOps/action-apply-intents">action-apply-intents</a> | Create/update intents |
| <a href="https://github.com/BHGitOps/action-build-locales">action-build-locales</a> | Build locale configurations |
| <a href="https://github.com/BHGitOps/action-clean-runner-artifacts">action-clean-runner-artifacts</a> | Cleanup runner |

---

## ✅ **2. Promote (Version + Alias Update)**
Executed only when `action == 'promote'`.

### Actions Used
| Action | Purpose |
|--------|---------|
| <a href="https://github.com/BHGitOps/action-checkout">action-checkout</a> | Checkout |
| <a href="https://github.com/BHGitOps/action-configure-aws-credentials">action-configure-aws-credentials</a> | AWS OIDC auth |
| <a href="https://github.com/BHGitOps/action-install-aws-cli">action-install-aws-cli</a> | Install AWS CLI |
| <a href="https://github.com/BHGitOps/action-load-environment-variables">action-load-environment-variables</a> | Load env vars |
| <a href="https://github.com/BHGitOps/action-discover-bots">action-discover-bots</a> | Identify bots |
| <a href="https://github.com/BHGitOps/action-create-bot-versions">action-create-bot-versions</a> | Publish bot versions |
| <a href="https://github.com/BHGitOps/action-update-alias">action-update-alias</a> | Update alias for environment |
| <a href="https://github.com/BHGitOps/action-bot-smoke-test">action-bot-smoke-test</a> | Runtime smoke testing |
| <a href="https://github.com/BHGitOps/action-clean-runner-artifacts">action-clean-runner-artifacts</a> | Cleanup |

---

## ✅ **3. Rollback**
Executed only when `action == 'rollback'`.

### Actions Used
| Action | Purpose |
|--------|---------|
| <a href="https://github.com/BHGitOps/action-checkout">action-checkout</a> | Checkout |
| <a href="https://github.com/BHGitOps/action-configure-aws-credentials">action-configure-aws-credentials</a> | AWS auth |
| <a href="https://github.com/BHGitOps/action-install-aws-cli">action-install-aws-cli</a> | Install AWS CLI |
| <a href="https://github.com/BHGitOps/action-load-environment-variables">action-load-environment-variables</a> | Load `.env` |
| <a href="https://github.com/BHGitOps/action-discover-bots">action-discover-bots</a> | Discover bots |
| <a href="https://github.com/BHGitOps/action-rollback-alias">action-rollback-alias</a> | Roll back alias |
| <a href="https://github.com/BHGitOps/action-clean-runner-artifacts">action-clean-runner-artifacts</a> | Cleanup |

---

## Changelog 📝

| Version | Date | Tags | Changes |
|:------:|:------:|--------|---------|
| **v1** | 2026‑03‑25 | Initial Release | - Added apply/promotion/rollback bot workflow <br> - Added locales + intents automation <br> - Added version creation + alias update <br> - Added smoke test support <br> - Added OIDC-based AWS authentication |

---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

<article>
  <strong>
    <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflow</a>
  </strong>
  <p>
    This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team.
  </p>
</article>

---

## Feedback / Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering team. We're here to help you succeed!
