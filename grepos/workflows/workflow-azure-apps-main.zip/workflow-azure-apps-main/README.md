<h1 align="center">
  <a href=".github/workflows/workflow.yml">workflow-azure-apps</a>
</h1>

## Overview
This repository contains a production-grade, reusable GitHub Actions workflow for deploying applications to Azure cloud resources. It provides a unified, composable CI/CD pipeline that supports building, packaging, and deploying applications to **Azure App Services**, **Azure Functions**, and **Static Web Apps**. The workflow includes optional steps for linting, JSON transformations, .NET test execution, deployment slot swaps, secret management via CyberArk Conjur, and comprehensive configuration flexibility.

---

## Repository Structure

```
workflow-azure-apps/
├── .github/
│   └── workflows/
│       └── workflow.yml                    # Reusable CI/CD workflow definition
├── docs/
│   └── upgrades/
│       └── v3/
│           └── v3-to-v4-upgrade-guide.md   # Migration documentation
├── README.md                               # Workflow overview and usage
└── .gitignore
```

---

## Getting Started

These documents will help you get up to speed with our engineering practices and tools.

---

## Workflow File Documentation: `.github/workflows/workflow.yml`

The core workflow file is a **reusable GitHub Actions workflow** (`workflow_call` trigger) that can be invoked from other repositories to standardize Azure deployments across the organization.

---

## Reusable Workflow Summary

The table below outlines the key details of the reusable Azure Application deployment workflow, including its name, current stable version, supported cloud environment, Azure services involved, compatible tech stacks, and authentication support.

| Workflow Name | workflow-azure-apps |
| ------| -------------|
| **Latest Stable Version** | [**v4**](https://github.com/BHGitOps/workflow-azure-apps/tree/v4) |
| **Current Version** | [**v4**](https://github.com/BHGitOps/workflow-azure-apps/tree/v4) |
| **Cloud Environment** | Azure |
| **Cloud Services** | Azure App Services, Azure Functions, and Static Web Apps |
| **TechStacks** | .NET, Angular, Static web apps |
| **Is Conjur integrated** | Yes*¹ |
| **High Availability Supported** | No |

*¹ - CyberArk Conjur is integrated into this workflow to securely manage sensitive information such as API keys, credentials, and environment variables. Secrets can be fetched dynamically during build and deployment steps, ensuring compliance and security.

---

## Reusable Workflow Upgrade Guide

It is considered a best practice to keep your caller/application workflows updated to reference the latest stable version of the reusable workflow. Doing so ensures you benefit from the newest features, security patches, enhancements, and bug fixes provided in the workflow-aws-eks reusable workflow.
For detailed upgrade paths, refer to the table below

[**workflow-aws-eks (v3 → v4)**](docs/upgrades/v3/v3-to-v4-upgrade-guide.md)

---

## Mock Caller Repositories

A mock workflow, shown below, provides a solid starting point for implementing this reusable workflow to support application deployments to Azure App Services, Azure Functions, and Static Web Apps (Angular, .NET) respectively. Refer to the table below for the list of available caller workflows.

| Mock Repository URL | Purpose | Technology Stack |
|------------------|-------------|----------|
| [**mock-api-dotnet-azure-app-service**](https://github.com/BHGitOps/mock-api-dotnet-azure-app-service) | Provides a reference implementation for deploying an .NET application to Azure App Services | .NET |
| [**mock-api-dotnet-function**](https://github.com/BHGitOps/mock-api-dotnet-function) | Provides a reference implementation for deploying a .NET application to Azure Functions | .NET |
| [**mock-azure-deploy-angular**](https://github.com/BHGitOps/mock-azure-deploy-angular) | Provides a reference implementation for deploying Angular application to Static Web Apps | Angular |
| [**mock-app-blazor-wasm**](https://github.com/BHGitOps/mock-app-blazor-wasm) | Provides a reference implementation for deploying Blazor HTML application to Static Web Apps | Blazor HTML |
| [**mock-dotnet-azure-app-service-submodule**](https://github.com/BHGitOps/mock-dotnet-azure-app-service-submodule) | Provides a reference implementation for submodules | submodules |

---
## Key Features & Capabilities
* Build, test, and deploy .NET, Angular, or HTML applications to Azure resources.
* Supports Azure Web Apps, Azure Functions, and container-based apps.
* Optional execution of .NET unit tests with TRX result generation for reporting and quality validation.
* Optional Conjur-based secret retrieval and Azure App Settings updates.
* Supports GitHub Secrets → Azure App Settings mapping.
* NuGet restore via GitHub or Azure DevOps feeds.
* Optional Super Linter for code quality.
* Deployment slot swapping (staging ↔ production).
* Multi-project .NET publishing modes.
* Supports GitHub App authentication for submodules.

> [!NOTE]
> Conjur is the primary source of truth for secrets. As we transition from GitHub Secrets to Conjur Secrets, our reusable workflows have been intelligently designed to support both secret sources. Application teams are strongly encouraged to use Conjur as their secret provider moving forward.
> Use the parameter conjur-variable-json to fetch secrets from Conjur, and use the parameter secrets-json to retrieve secrets from GitHub environment secrets. Please refer to our mock example, which clearly demonstrates both scenarios.

---

## Prerequisites
- Azure AD application (Client ID, Tenant ID, Subscription ID)
- GitHub → Azure OIDC is configured
- Azure App/Function Apps resources provisioned
- Conjur setup (URL, account, workload ID, API key) when applicable
- Resource group details
- Azure Artifacts feed information (optional)

> [!IMPORTANT]
> Before using this reusable workflow, ensure the following prerequisites are completed for the target Azure subscription and environment.
> Please coordinate with the IAC/Platform team to obtain all required Azure infrastructure details, as the foundational setup must always be completed before consuming this workflow.

---

## Usage Example
#### Example: Deploy .NET API to Azure App Service
```yaml
uses: BHGitOps/workflow-azure-apps/.github/workflows/workflow.yml@v3
with:
  framework-type: "dotnet"
  framework-version: "8.x"
  dependency-version: '6.x'
  configuration: ${{ fromJSON(needs.prepare-vars-for-environment.outputs.dev-vars-json).CONFIGURATION }}               
  working-directory: "./src/MyApi"
  file-name-to-restore: 'MyApi.csproj'
  file-name-to-build: "MyApi.sln"
  file-name-to-publish: "MyApi.csproj"
  artifact-name: "artifacts"    
  cloud-app-name: "my-dotnet-api"
  deployment-resource-type: "azure-web-app"
  deploy-environment: "dev"
  deploy-runner-type: "ubuntu-latest"  
  ## The test step runs only when framework-type=dotnet and execute-tests=true
  framework-type: "dotnet"
  execute-tests: "true"
  file-name-to-test: "./src/DotNetWebApi/DotNetWebApi.sln"
  test-results-path: "output/"

secrets:
  client-id: ${{ secrets.CLIENT_ID }}
  tenant-id: ${{ secrets.TENANT_ID }}
  subscription-id: ${{ secrets.SUBSCRIPTION_ID }}
```

---

### Workflow Inputs & Parameters

#### Build & Framework Configuration
| Input | Type | Required | Default | Description |
|---|---|---|---|---|
| `framework-type` | string | ❌ | — | Type of framework used to build and deploy code (e.g., `dotnet`, `angular`, `node`) |
| `framework-version` | string | ❌ | — | Version of the framework to install (e.g., `8.x`, `16.x`) |
| `dependency-version` | string | ❌ | — | Version of the dependency package to install (e.g., `6.x`) |
| `working-directory` | string | ❌ | — | Path to the working directory containing the application |
| `file-name-to-build` | string | ❌ | — | Solution or project file to build (e.g., `MyApp.sln`, `package.json`) |
| `file-name-to-restore` | string | ❌ | — | Solution or project file to restore (e.g., `MyProject.csproj`) |
| `file-name-to-publish` | string | ❌ | — | Path to the project file (.csproj) to publish |
| `configuration` | string | ❌ | — | Build configuration (Debug/Release) |
| `build-artifacts` | string | ❌ | `output/` | Directory for build artifacts |
| `artifact-name` | string | ❌ | — | Name of the artifact to upload/download |
| `artifact-path` | string | ❌ | `output.tar` | Path to the downloaded artifact file |
| `artifact-download-path` | string | ❌ | `.` | Path to download the artifact file |
| `app-location` | string | ❌ | — | Source code location (used for Static Web Apps) |
| `output-location` | string | ❌ | — | Output location for build artifacts (used for Static Web Apps) |
| `target-file` | string | ❌ | — | Target file to overwrite with environment secrets (JSON transform) |
| `multi-project-mode` | string | ❌ | `flat` | For multiple .csproj: `flat` puts all DLLs into `output/`, `folder` creates subfolders |
| `build-runner` | string | ✅ | — | Runner where the build job executes (e.g., `ubuntu-latest`, self-hosted group) |
| `use-legacy-peer-deps` | boolean | ❌ | `false` | Use `--legacy-peer-deps` with npm install to avoid peer dependency conflicts |
| `oryx-build` | boolean | ❌ | `false` | Use Oryx for building (platform-managed builds; `false` assumes app is pre-built) |
| `file-name-to-test` | string | ❌ | — | Path to solution/project file to test |
| `test-logger` | string | ❌ | trx;LogFileName=test_results.trx | Logger format (e.g., TRX) |
| `test-results-path` | string | ❌ | `./TestResults` | Directory to store test results |

#### Deployment Configuration
| Input | Type | Required | Default | Description |
|---|---|---|---|---|
| `deployment-resource-type` | string | ✅ | — | Target resource: `azure-web-app`, `azure-function`, `static-web-app` |
| `cloud-app-name` | string | ❌ | — | Azure resource name |
| `deploy-environment` | string | ✅ | — | Environment: `dev`, `test`, `prod` |
| `deployment-slot-name` | string | ❌ | `production` | Name of the slot to deploy to |
| `source-slot` | string | ❌ | — | Source slot to swap from (e.g., `staging`) |
| `target-slot` | string | ❌ | — | Target slot to swap to (e.g., `production`) |
| `deployment-slot-swap` | boolean | ❌ | `false` | Enable slot swap (staging → production) |
| `azure-resource-group` | string | ❌ | — | Azure resource group name |
| `deploy-runner-type` | string | ✅ | `azure` | Runner type for deployment (e.g., `ubuntu-latest`, `self-hosted`, `azure`) |
| `app-settings-path` | string | ❌ | — | Path to the application settings file for Azure resources |

#### Job Control Parameter
| Input | Type | Required | Default | Description |
|---|---|---|---|---|
| `skip-app-build` | boolean | ❌ | — | Set to `true` to skip the application build process |
| `skip-deploy-job` | boolean | ❌ | `false` | Skip the deployment job entirely |
| `skip-clean` | boolean | ❌ | `false` | Skip clean build before deployment |

#### Optional Features
| Input | Type | Required | Default | Description |
|---|---|---|---|---|
| `submodules` | boolean | ❌ | `false` | Enable Git submodule support |
| `repositories-owner` | string | ❌ | `BHGitOps` | GitHub organization or user that owns the submodule repositories |
| `repositories` | string | ❌ | — | Comma-separated list of repositories requiring GitHub App token access |

#### Linting Configuration
| Input | Type | Required | Default | Description |
|---|---|---|---|---|
| `include-super-linter` | boolean | ❌ | `false` | Enable code linting |
| `linter-filter-regex-include` | string | ❌ | — | Files/folders to include in linting |
| `linter-filter-regex-exclude` | string | ❌ | — | Files/folders to exclude from linting |
| `linter-rules-config-path` | string | ❌ | — | Custom linter rules path |

#### Package Management
| Input | Type | Required | Default | Description |
|---|---|---|---|---|
| `package-source` | string | ❌ | `azure-artifacts` | Package source: `github` or `azure-artifacts` |
| `package-source-name` | string | ❌ | `Azure` | Custom alias to assign to the NuGet source |
| `package-source-org` | string | ❌ | `BHGitOps` | GitHub organization where the NuGet package is hosted |
| `azure-org` | string | ❌ | `Bannerhealth` | Azure DevOps organization name |
| `azure-feed` | string | ❌ | — | Name of the Azure Artifacts feed |
| `azure-user-name` | string | ❌ | `AzureDevOps` | Username for Azure DevOps authentication |
| `nuget-config-path` | string | ❌ | — | Path to the NuGet config file |

#### Secret & Config Management
| Input | Type | Required | Default | Description |
|---|---|---|---|---|
| `conjur-variable-json` | string | ❌ | — | JSON mapping of Conjur vaults and secrets to fetch |
| `conjur-secret-to-azure-appsettings` | boolean | ❌ | `false` | Update Azure App Settings using Conjur secrets |
| `github-secret-to-azure-appsettings` | boolean | ❌ | `false` | Update Azure App Settings using GitHub secrets |
| `vars-json` | string | ❌ | — | JSON string containing environment variables to map into the variables file |


> [!NOTE]
> *² nuget-config-path - In Banner, Azure DevOps Artifacts serves as our organization’s internal package manager, enabling teams to store, manage, and share common packages used across applications. We maintain two Azure Artifacts feeds **bh-dbt-azure-greenfield-feed** and **bh-dbt-azure-feed** where most shared application packages are published.
> Our reusable pipelines support restoring dependencies directly from these feeds, with the configuration defined in the NuGet.config file, which specifies the sources to pull packages from. For implementation guidance, refer to the examples provided in our mock repository.

---

### Workflow Secrets
| Secret | Required | Description | Default |
|---|---|---|---------|
| `client-id` | ❌*¹ | Azure Service Principal Client ID | - |
| `tenant-id` | ❌*¹ | Azure AD Tenant ID | - |
| `subscription-id` | ❌*¹ | Azure Subscription ID | - |
| `conjur-appliance-url` | ❌*² | Conjur server URL | vars.CONJUR_APPLIANCE_URL |
| `conjur-account` | ❌*² | Conjur account name | vars.CONJUR_ACCOUNT |
| `conjur-workload-id` | ❌*² | Conjur host workload ID | - |
| `conjur-api-key` | ❌*² | Conjur API key | - |
| `gh-app-id` | ❌*³ | GitHub App ID (for submodules) | - |
| `gh-app-private-key` | ❌*³ | GitHub App private key (for submodules) | - |
| `secrets-json` | ❌ | Custom JSON object for additional secrets | - |

*¹ - These authentication parameters (client-id, tenant-id, and subscription-id) are used to log into Azure through a Service Principal. This ensures that all interactions with Azure resources follow role‑based access controls and comply with your subscription’s security policies. 

*² - The Conjur secrets are required to retrieve application secrets from Conjur. If this applies to your application, the Conjur workload ID and Conjur API key—specific to your application’s safe—must be provided by your application team. These credentials can be obtained by contacting the Conjur team.
Refer to the reference documentation section listed below for more details.

*³ - These inputs are required only when Git submodules are used and can be ignored if your workflow does not utilize submodules.

> [!CAUTION]
> It is the responsibility of the application team to securely manage all secrets, whether stored in Conjur or GitHub Secrets. Secrets must never be logged, exposed, or configured in a way that could cause them to appear in application logs.
If a secret is suspected to be leaked or compromised in any way, it must be reported immediately and rotated without delay.

---

## Jobs & Steps
Build ➡️→ Publish / Package App ➡️→ Upload Artifacts ➡️→ Download Artifacts ➡️→ Deploy to Azure ➡️→ Update App Settings (Optional) ➡️→ Deployment Slot Swap (Optional) ➡️→ Cleanup

### 1. Build 🛠️
The Build job compiles the application, restores dependencies, authenticates package sources, fetches secrets, transforms configs, and prepares publish-ready artifacts.

| Action Name | Purpose |
|-------------|---------|
| [**action-generate-github-app-token**](https://github.com/BHGitOps/action-generate-github-app-token) | Generates GitHub App token for submodules, this step is required only when Git submodules are used and can be ignored if your workflow does not utilize submodules |
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checks out the repository |
| [**action-docker-setup**](https://github.com/BHGitOps/action-docker-setup) | Prepares Docker for linting workflows |
| [**action-super-linter**](https://github.com/BHGitOps/action-super-linter) | Executes linting using configured rules if enabled |
| [**action-setup-framework**](https://github.com/BHGitOps/action-setup-framework) | Installs and configures the required development framework and dependency manager |
| [**action-setup-dependency**](https://github.com/BHGitOps/action-setup-dependency) | Installs project‑specific dependencies needed for the build |
| [**action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Logs into Azure and optionally authorizes NuGet when using Azure Artifacts |
| [**action-azure-devops-access-token**](https://github.com/BHGitOps/action-azure-devops-access-token) | Generates an Azure DevOps access token for secure operations |
| [**action-conjur-fetch-secrets**](https://github.com/BHGitOps/action-conjur-fetch-secrets) | Retrieves secrets from CyberArk Conjur for secure build-time use |
| [**action-authorize-nuget-restore**](https://github.com/BHGitOps/action-authorize-nuget-restore) | Authorizes NuGet restore, typically for private or authenticated azure devops feeds |
| [**action-restore-dependencies**](https://github.com/BHGitOps/action-restore-dependencies) | Restores dependencies required for the application build |
| [**action-clean**](https://github.com/BHGitOps/action-clean) | Cleans the project output or environment before building |
| [**action-json-transform**](https://github.com/BHGitOps/action-json-transform) | Performs JSON transformations (optional step for dynamic config) |
| [**action-conjur-azure-app-settings**](https://github.com/BHGitOps/action-conjur-azure-app-settings) | Pushes Conjur secrets to Azure app settings if enabled |
| [**action-gh-azure-app-settings**](https://www.github.com/BHGitOps/action-gh-azure-app-settings) | Pushes GitHub secrets to Azure app settings if enabled |
| [**action-build**](https://github.com/BHGitOps/action-build) | Builds the application based on its framework type |
| [**action-dotnet-test**](https://github.com/BHGitOps/action-dotnet-test) | Executes .NET unit tests and generates test results (TRX format) when enabled |
| [**action-publish**](https://github.com/BHGitOps/action-publish) | Publishes build output based on the framework type |
| [**action-upload-artifacts**](https://github.com/BHGitOps/action-upload-artifacts) | Uploads build artifacts for later workflow stages |


### 2. Deploy ☁️
Deploys the package/artifacts to Azure Web Apps or Function Apps.

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checks out the repository |
| [**action-download-artifact**](https://github.com/BHGitOps/action-download-artifact) | Downloads previously generated build artifacts needed for deployment |
| [**action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Logs into Azure |
| [**action-azure-app-settings**](https://github.com/BHGitOps/action-azure-app-settings) | Updates Azure App Settings if path provided |
| [**action-deploy**](https://www.github.com/BHGitOps/action-deploy) | Deploys to Azure resource type (webapp/function) |
| [**action-azure-swap-deployment-slot**](https://www.github.com/BHGitOps/action-azure-swap-deployment-slot) | Performs slot swap operation if enabled |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Cleans remaining artifacts from the runner at the end of the job. |

---

## Changelog 📝
| Version | Date       | Tags                                                                 | Changes |
|---------|------------|----------------------------------------------------------------------|---------|
| **v3**  | 2026-01-26 | CyberArk Conjur integration, Azure App Settings | - **Added:** Update Azure App Settings from Conjur and GitHub Secrets steps in build job<br>- **Added:** Conjur secret retrieval in Build job |
| **v2**  | 2025-10-31 | Enhanced multi-project support and added slot swap functionality | - **Added:** slot swap functionality |
| **v1**  | 2025-06-10 | Initial Release | - **Added:** Basic build and deploy functionality for Azure App Services and Functions |

---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflow</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>
  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1761476609/workflow-azure-apps+v2+Reusable+CI+CD+Workflow+for+Azure+Application+Deployment">Workflow-azure-apps</a>
    </strong>
    <p>
      Workflow-azure-apps - Reusable GitHub workflow building and deploying applications to Azure apps.
    </p>
  </article>  

---

## Feedback/Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!

---
