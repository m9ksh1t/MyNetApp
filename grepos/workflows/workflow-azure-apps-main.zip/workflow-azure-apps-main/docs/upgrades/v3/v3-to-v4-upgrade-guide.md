# Upgrade Guide: workflow-azure-apps (v3 → v4)

This document provides step-by-step instructions to migrate your GitHub workflows from **v3** to the **v4** of the [**workflow-azure-apps**](https://github.com/BHGitOps/workflow-azure-apps/blob/v4/.github/workflows/workflow.yml) reusable workflow.

> [!NOTE]
> This upgrade includes **breaking changes**, and all application teams must migrate to the updated reusable workflow version to ensure compatibility with new enhancements and standardized build and deployment behavior across Azure workloads.
>
> Any caller workflow referencing workflow versions **≤v3** must follow this upgrade path, as older versions are not compatible with the changes introduced in v4 and must be updated to ensure continued functionality and support.

> [!CAUTION]
> Migration deadline is April 9, 2026.

---

## 🔄 Overview of Changes
The v4 upgrade requires updates across all application caller workflows that reference the [**workflow-azure-apps**](https://github.com/BHGitOps/workflow-azure-apps/blob/v4/.github/workflows/workflow.yml) reusable workflow, specifically:
- Updating the reusable workflow version reference to v4
- Introducing a new build control mechanism using **oryx-build**
- Removing the legacy **skip-app-build** input used in v3

Follow the instructions below to complete the migration safely.

---

## Mock Caller Repositories

A mock workflow, shown below, provides a solid starting point for implementing this version upgrade. Refer to the mock example below.

| Mock Repository URL | Purpose |
|------------------|-------------|
| [**mock-azure-deploy-angular**](https://github.com/BHGitOps/mock-azure-deploy-angular) | Provides a reference implementation for deploying an Angular application using this reusable workflow |

> **Tip:** The mock repository demonstrates how to consume v4 inputs and validate build and deployment behavior against Azure resources.

---

## 📝 Step 1: Update the workflow-azure-apps version reference

Change your reusable workflow reference from **v3** to the **v4** release.

**Before:**
```yaml
uses: BHGitOps/workflow-azure-apps/.github/workflows/workflow.yml@v3
```

**After:**
```yaml
uses: BHGitOps/workflow-azure-apps/.github/workflows/workflow.yml@v4
```

---

## 📝 Step 2: Review build behavior changes

The v4 workflow introduces a refined approach to managing application build behavior.

Key changes include:
- Introduction of **oryx-build** to enable platform-managed builds or deployment of pre-built artifacts
- Removal of the legacy **skip-app-build** input that was supported in v3

Application teams must evaluate their existing workflows and update them to align with the new build control mechanism provided by **oryx-build**.

---

## 🧪 Step 3: Deprecated or Added Parameters

- The following parameters have either been deprecated or introduced as part of the v4 upgrade:

    - If a parameter is deprecated, it can be safely removed from your workflow.
    - If a parameter has been added, review whether your workflow needs it and configure it as described below.

### Parameter/Input Changes

| Status      | Old Input Name     | New Input Name | Notes                                                                 |
|-------------|--------------------|----------------|-----------------------------------------------------------------------|
| Deprecated  | `skip-app-build`   | —              | Removed in v4. Use `oryx-build` to control build behavior instead.     |
| Added       | —                  | `oryx-build`   | Enables platform-managed builds or deployment of pre-built artifacts. |

---

## 🧪 Step 4 (Optional): Validate the workflow

After updating:
1. Commit the changes  
2. Push to your branch  
3. Trigger the workflow manually or wait for the next run  
4. Confirm the job completes successfully without version issues  

---

## ✅ Migration Complete

Your project is now upgraded to the **v4** reusable workflow.  

---

## 📚 Resources

If you'd like a full updated workflow example or additional enhancements, please refer to the resources below.

| Mock Repository URL | Purpose | Technology Stack |
|------------------|-------------|----------|
| [**mock-azure-deploy-angular**](https://github.com/BHGitOps/mock-azure-deploy-angular) | Reference Angular deployment using workflow-azure-apps v4 | Angular |

---

## 📬 Feedback/Need Help?

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
