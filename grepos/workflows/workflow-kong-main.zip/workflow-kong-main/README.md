# Kong Konnect API Workflow - workflow-kong

GitHub Reusable workflow to update Kong Gateway Services, Routes, Plugins, and API Products using an Open API Spec converted to Terraform

Turn OpenAPI specs into **Kong Konnect** gateway, service, route, and plugin configurations, then executes **Terraform Plan/Apply** in **Terraform Cloud**.

This workflow:

- Pulls an OpenAPI specification from Azure Functions, AWS API Gateway, or a local file
- Merges the spec into a Kong-ready Terraform `*.auto.tfvars` file (gateway, services, routes)
- Gathers and/or generates plugin configuration
- Produces an artifact consumed by Terraform
- Runs **Plan** and conditionally **Apply** (skips apply when plan shows no changes)

## Table of Contents

- [How to Call This Workflow](#how-to-call-this-workflow)
- [Required Permissions](#required-permissions)
- [Inputs](#inputs)
- [Secrets](#secrets)
- [Job Flow](#job-flow)
- [Artifacts: Produced & Consumed](#artifacts-produced--consumed)
- [Usage Examples](#usage-examples)
- [Best Practices](#best-practices)
- [Troubleshooting](#troubleshooting)
- [Compatibility & Notes](#compatibility--notes)

---

## How to Call This Workflow

Create a caller workflow in your repository and point it at this reusable workflow.  
Example caller:

```yaml
name: Dev - API to Kong Gateway

on:
  push: 
    branches:
      - 'main'

  workflow_dispatch:
    inputs:
      destroy:
        description: 'Set to true to destroy resources'
        required: false
        type: boolean
        default: false

permissions:
  id-token: write
  contents: read

jobs:
  kong-terraform-workflow:
    secrets: inherit
    name: Kong & Terraform Workflow
    uses: BHGitOps/workflow-kong/.github/workflows/workflow.yml@v1.1.3
    with:
      # Kong-specific inputs
      deploy-runner-type: 'ubuntu-latest'
      deploy-environment: 'dev'      
      open-api-source: 'local'
      local-path: './Api/wwwroot/swagger/v1/swagger.json'
      kong-tf-path: 'kong.auto.tfvars'
      plugins-tf-path: 'plugins.auto.tfvars'
      artifact-name: 'artifact'
      artifact-path: './'
      server-url: 'https://dev.example.bannerhealth.com'

      # Terraform-specific inputs
      destroy: ${{ github.event.inputs.destroy || 'false' }}
      terraform-var-path: 'Terraform/dev'
      tfc-workspace-name: 'dev_internal_example-system-api'
      plugins-json-path: '.config/plugins/plugins-config-dev.json' 

      #Build-specific inputs
      skip-build-job: false
      framework-type: 'dotnet'
      framework-version: '8.0.x'
      dependency-version: 'latest'
      working-directory: "."
      file-name-to-restore: "./Api/BH.Example.System.Api.csproj"
      file-name-to-build: "./Api/BH.Example.Providers.System.Api.csproj"
      file-name-to-publish: "./Api/BH.Example.Providers.System.Api.csproj"
      configuration: 'Release'
      build-artifacts: "./Api/"
      build-artifact-name: 'build-artifacts'
      generate-openapi: true
      swashbuckle-version: '6.6.2'
```

---

## Required Permissions

- The caller workflow must have **`contents: read`** on the current repo.
- For the shared Terraform files checkout, provide a valid PAT via `KONG_TERRAFORM_SHARED_REPO_PAT_TOKEN` with access to `${{ inputs.terraform-files-repo }}`.

---

## Inputs

### Core/General  
| Name                   | Type                | Required | Default             | Description                                                         |
|------------------------|---------------------|----------|---------------------|---------------------------------------------------------------------|
| deploy-runner-type     | string              | ✅       | ubuntu-latest       | Runner label (`self-hosted`/`ubuntu-latest`)                        |
| deploy-environment     | string              | ✅       | —                   | GitHub environment (e.g. dev, prod)                                 |

### Kong/OpenAPI Source  
| Name               | Type     | Required | Default           | Description                                                           |
|--------------------|----------|----------|-------------------|-----------------------------------------------------------------------|
| open-api-source    | string   | ✅       | —                 | One of: `azure-function-app`, `aws-lambda`, `local`                   |
| open-api-spec-url  | string   | ❌       | —                 | URL for OpenAPI (Azure)                                               |
| local-path         | string   | ❌       | —                 | Local repo path to OpenAPI spec file                                  |
| aws-api-id         | string   | ❌       | —                 | AWS API Gateway ID (Lambda)                                           |
| aws-stage          | string   | ❌       | —                 | AWS APIGW stage name (Lambda)                                         |
| open-api-json      | string   | ❌       | —                 | For advanced use (raw OpenAPI JSON)                                   |
| artifact-name      | string   | ❌       | artifacts         | Artifact name for upload/download (Kong outputs/plugins)              |
| artifact-path      | string   | ❌       | ./                | Path where artifact lands (usually inside your TF working dir)        |
| plugins-tf-path    | string   | ❌       | ''                | Comma-separated extra plugin tfvars for artifact                      |
| kong-tf-path       | string   | ❌       | kong.auto.tfvars  | Output .tfvars for gateway, services, routes                          |
| server-url         | string   | ❌       | ''                | Server URL for dynamic update in OpenAPI spec                         |

### Terraform & Conversion  
| Name                       | Type   | Required | Default                       | Description                                              |
|----------------------------|--------|----------|-------------------------------|----------------------------------------------------------|
| tfc-workspace-name         | string | ✅       | —                             | Workspace name in Terraform Cloud                        |
| plugins-json-path          | string | ❌       | ''                            | Path to plugins JSON in repo                             |
| databricks-account-id      | string | ❌       | —                             | For Databricks integration                               |
| destroy                    | string | ❌       | false                         | `"true"` runs `terraform destroy`                        |
| terraform-var-path         | string | ❌       | —                             | Path for additional .tfvars                              |
| terraform-working-dir      | string | ❌       | Terraform                     | Primary working dir for plan/app                         |
| terraform-files-repo       | string | ❌       | BHGitOps/kong-terraform-files | Shared repo for generic TF files                         |
| terraform-files-ref        | string | ❌       | v1.0.0                        | Ref/tag/branch for pinned infra TF files                 |
| terraform-files-source-path| string | ❌       | terraform-files                | Subdir in shared repo for TF files                       |
| plugins-tfvars-filename    | string | ❌       | plugins.auto.tfvars           | Output tfvars from JSON conversion                       |
| conversion-script-path     | string | ❌       | scripts/json_to_tfvars.py     | Conversion script path                                   |
| python-version             | string | ❌       | 3.11                          | Python version for JSON conversion                       |
| convert-json-to-terraform  | string | ❌       | true                          | `"true"` enables plugin JSON→tfvars conversion           |

### Build Inputs

| Name                   | Type      | Required | Default           | Description                                                   |
|------------------------|-----------|----------|-------------------|---------------------------------------------------------------|
| framework-type         | string    | ❌       | dotnet            | Build framework (dotnet/...)                                  |
| framework-version      | string    | ❌       | 8.0.x             | Framework version                                             |
| dependency-version     | string    | ❌       | latest            | Dependency package version                                    |
| working-directory      | string    | ❌       | .                 | App working directory                                         |
| file-name-to-restore   | string    | ❌       | —                 | .sln/.csproj for dependency restore (advanced)                |
| nuget-config-path      | string    | ❌       | —                 | NuGet config file (optional)                                  |
| file-name-to-build     | string    | ❌       | —                 | .sln or .csproj file to build (required to trigger build job) |
| configuration          | string    | ❌       | Release           | Build configuration                                           |
| build-artifacts        | string    | ❌       | output/           | Directory where artifacts are saved after build               |
| build-artifact-name    | string    | ❌       | build-artifacts   | Name of the build artifact file for upload                    |
| artifact-download-path | string    | ❌       | .                 | Location to download artifact in `kong-konnect` job           |
| file-name-to-publish   | string    | ❌       | —                 | Project file to publish                                       |
| generate-openapi       | boolean   | ❌       | true              | Enable OpenAPI spec generation in build                       |
| skip-build-job         | boolean   | ❌       | false             | Bypass most build steps (for static deploys, etc.)            |
| package-source-org     | string    | ❌       | BHGitOps          | Org for NuGet/Azure Artifacts                                 |
| package-source         | string    | ❌       | azure-artifacts   | Source for package manager                                    |
| azure-org              | string    | ❌       | Bannerhealth      | Azure Org name                                                |
| azure-feed             | string    | ❌       | —                 | Name of Azure Artifacts feed                                  |
| package-source-name    | string    | ❌       | Azure             | NuGet source alias                                            |
| azure-user-name        | string    | ❌       | AzureDevOps       | Username for Azure artifacts                                  |
| swashbuckle-version    | string    | ❌       | 6.6.2             | Swashbuckle CLI version for OpenAPI gen                       |

---

## Secrets

| Secret                                   | Required | Usage                                     |
|-------------------------------------------|----------|-------------------------------------------|
| KONNECT_CONTROL_PLANE_ID                  | ✅       | Used for merging Kong service/routes      |
| TF_TOKEN                                  | ✅       | Needed for Terraform plan/apply (Cloud)   |
| KONG_TERRAFORM_SHARED_REPO_PAT_TOKEN      | ✅       | Needed to fetch shared Terraform files    |
| AWSAMPLIFY_PAT_TOKEN                      | ❌       | Optional (passed to actions if present)   |
| NONAME_SECRET                             | ❌       | Optional (passed to actions if present)   |
| PAT_TOKEN                                 | ❌       | Optional (passed to actions if present)   |
| AZURE_CLIENT_ID, AZURE_SUBSCRIPTION_ID, AZURE_TENANT_ID | ❌ | For Azure/NuGet restoration (optional)    |

**Variable:**  
- `TF_CLOUD_ORG` (Terraform Cloud organization name) must be defined as a repository/environment variable.

---

## Job Flow

### Diagram

```mermaid
flowchart LR
  subgraph Build
  A1["build (conditional)"] -- output --> B1["kong-konnect"]
  end
  B1["kong-konnect"] -- artifact --> D1["plan"]
  D1["plan"] -- conditional --> E1["apply"]
  D1 -.->|noChanges=true| Done1["done"]
```
- `build`: Only runs if `skip-build-job` is false and a build file is specified.
- `kong-konnect`:
  - Downloads artifact (if applicable)
  - Fetches OpenAPI spec
  - Updates server URL (if given)
  - Merges gateway/services/routes into auto.tfvars
  - Detects plugins, bundles artifact
- `plan`:
  - Checks out code and shared TF files
  - Optionally runs JSON→tfvars
  - Downloads artifact into TF working dir
  - Runs Terraform Plan
- `apply`:
  - Mirrors `plan` tasks
  - Runs Terraform Apply
  - Skipped if `plan` output indicates no changes

---

## Artifacts: Produced & Consumed

**Produced by `kong-konnect`:**
```
<artifact-name>/
 ├── kong.auto.tfvars           # or your custom name from `kong-tf-path`
 ├── plugins.auto.tfvars        # optional/generate if enabled
 └── additional *.tfvars        # any extra `.tfvars` from plugins
```
**Consumed by `plan`/`apply`:** Downloaded into `${{ inputs.artifact-path }}`. This should be under your `${{ inputs.terraform-working-dir }}` so Terraform loads all variables.

---

## Usage Examples

### Local OpenAPI, with JSON→tfvars
```yaml
with:
  deploy-runner-type: ubuntu-latest
  deploy-environment: dev
  open-api-source: local
  local-path: ./openapi.json
  artifact-name: artifacts
  artifact-path: ./Terraform
  tfc-workspace-name: dev-workspace
  plugins-json-path: ./plugins.json
  terraform-working-dir: Terraform
```

### AWS API Gateway source, pin Terraform file repo/ref
```yaml
with:
  deploy-runner-type: ubuntu-latest
  deploy-environment: prod
  open-api-source: aws-lambda
  aws-api-id: a1b2c3d4
  aws-stage: prod
  artifact-name: artifacts
  artifact-path: ./Terraform
  tfc-workspace-name: prod-workspace
  plugins-json-path: ./plugins.json
  terraform-files-repo: BHGitOps/kong-terraform-files
  terraform-files-ref: v1.0.0
  terraform-files-source-path: terraform-files
```

### Azure Function App, disable JSON→tfvars
```yaml
with:
  deploy-runner-type: ubuntu-latest
  deploy-environment: stage
  open-api-source: azure-function-app
  open-api-spec-url: https://app.azurewebsites.net/api/openapi.json
  tfc-workspace-name: stage-workspace
  plugins-json-path: ./plugins.json
  convert-json-to-terraform: 'false'
```

### Planned destroy
```yaml
with:
  deploy-runner-type: ubuntu-latest
  deploy-environment: sandbox
  open-api-source: local
  local-path: ./openapi.json
  tfc-workspace-name: sbx-workspace
  plugins-json-path: ./plugins.json
  destroy: 'true'
```

---

## Best Practices

- **Pin action versions** to prevent supply-chain drift.
- **Version OpenAPI specs** alongside your app's code, and validate pre-merge.
- **Modularize plugin config**: keep `.tfvars` per plugin; use JSON→tfvars for standard codification.
- **Isolate state per environment** using a separate Terraform Cloud workspace per environment.
- **Secrets hygiene**: use GitHub Secrets, never commit plaintexts.
- **Make sure artifact-path** is under `${{ inputs.terraform-working-dir }}` so Terraform can auto-load all `.auto.tfvars`.

---

## Troubleshooting

- **Spec retrieval fails** → check source inputs (Azure: `open-api-spec-url`; AWS: `aws-api-id`, `aws-stage`; Local: `local-path`)
- **Base64 decode fails** at Merge → check logs for `merge-service-routes`/`get-open-api-spec`
- **Plugins not found** → see plugin paths, use JSON→tfvars, check generated/expected files
- **Artifact missing in plan/apply** → confirm `artifact-name` and `artifact-path` match; artifact-directory exists before plan/apply
- **Apply skipped** → `"noChanges"` output by plan job skips apply (expected behavior)

---

## Compatibility & Notes

- `open-api-json` exists but is not consumed directly by the merge; it is for future extensibility.
- `convert-json-to-terraform` in string form (`'true'`) for full compatibility with workflow conditions.
- Build job is **only executed if** `skip-build-job` is false AND a build file is specified.
- Plan/apply steps mirror one another for code consistency.
- Python is only required if plugin JSON→tfvars is enabled.

---

*Questions or want enhancements? Open an issue or ping the platform team.*
