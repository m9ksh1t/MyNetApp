# Azure API Management CRUD Operations Reusable Workflow

This repository contains a **reusable GitHub Actions workflow** for performing CRUD operations on **Azure API Management (APIM)** resources. It supports creating, updating, deleting APIs, products, named values, subscriptions, and applying policies at various scopes.

---

## Workflow Name
`Azure API Management CRUD Operations Reusable Workflow`

---

## Features
- Create APIs, version sets, products, named values, subscriptions
- Apply policies at global, workspace, product, API, and operation levels
- Delete resources individually or cascade delete dependencies
- Export and import APIM configurations for global operations
- Clean up runner workspace after execution

---

## Usage

**Current Version:** `v2`

To use this workflow in your repository:


```yaml
jobs:
manage-apim:
uses: BHGitOps/workflow-azure-apim-crud/.github/workflows/workflow.yml@v2
with:
deploy-environment: "dev"
deploy-runner-type: "azure"
apim-resource-group: "my-resource-group"
apim-service-name: "my-apim-service"
apim-scope: "create-api" # or delete-api, apply-policy, etc.
apim-api-id: "my-api-id"
apim-specs-file-path: "./specs/openapi.json"
apim-named-values-file-path : 'path of the .json'
vars-json: ${{ toJson(vars) }}

secrets:
client-id: ${{ secrets.CLIENT_ID }}
tenant-id: ${{ secrets.TENANT_ID }}
apim-subscription-id: ${{ secrets.SUBSCRIPTION_ID }}
secrets-json: |                                                                                               # GitHub secrets (injected via inline JSON)
        {
          "KEYVAULT_IDENTIFIER": "${{ secrets.KEYVAULT_IDENTIFIER }}",
          "DB_PASS": "${{ secrets.DB_PASS }}", 
          "DB_USER": "${{ secrets.DB_USER }}" 
        }
```

---

## Inputs
| Name | Description | Required | Type |
|------|-------------|----------|------|
| `deploy-environment` | Target deployment environment (`dev`, `qa`, `prod`) | ✅ | `string` |
| `deploy-runner-type` | GitHub Actions runner type | ✅ | `string` |
| `apim-resource-group` | Resource group containing APIM service | ❌ | `string` |
| `apim-service-name` | APIM service instance name | ❌ | `string` |
| `apim-scope` | Operation scope (`create-api`, `delete-api`, `apply-policy`, etc.) | ✅ | `string` |
| `apim-api-id` | Unique identifier for the API | ❌ | `string` |
| `apim-specs-file-path` | Path to OpenAPI specs file | ❌ | `string` |
| `apim-policy-source-file` | Path to policy XML file | ❌ | `string` |
| `apim-named-values-file-path` | Path to named values JSON file | ❌ | `string` |
| `failOnUpsertErrorForNamedValues` | Fail pipeline on named value upsert errors | ❌ | `boolean` |

---

## Secrets
| Name | Description |
|------|-------------|
| `client-id` | Azure Service Principal Client ID |
| `tenant-id` | Azure Tenant ID |
| `apim-subscription-id` | Azure Subscription ID |
| `secrets-json` | JSON string containing environment-specific secrets |

---

## Jobs & Steps
- **Checkout Code**
- **Login to Azure**
- **Install Az Module**
- **Create Resources (API, Product, Named Values, Subscription)**
- **Apply Policies (Global, Workspace, Product, API, Operation)**
- **Delete Resources (Cascade or Individual)**
- **Export/Import Global Configurations**
- **Clean Up Runner Workspace**

---

## Example Scenarios
- Create a new API and attach to a product
- Apply custom policies at API and operation level
- Delete API and related resources using cascade delete
- Export APIM configuration for backup

---

## Best Practices
- Store sensitive values in **GitHub Secrets**
- Validate API specs and policy files before deployment
- Use environment-specific variables via `vars-json` and `secrets-json`
- Enable versioning for backward compatibility

---

## 📜 Changelog
### [v2] - 2025-12-08 
**Tags:** Breaking Changes, Major Update
- **Changed:** Upsert options for Named Values
- **Added:** `failOnUpsertErrorForNamedValues` input to control pipeline behavior on named value upsert errors

### [v1] - 2025-07-10
- Initial release of CRUD workflow

---
## Mock Caller Workflows
Below are examples of workflows that call this reusable workflow:

- [Mock Caller for workflow-azure-apim-crud](https://github.com/BHGitOps/mock-azure-apim-crud/tree/main/.github/workflows)

These mock workflows illustrate how to invoke the reusable workflow with different environments and configurations.

## Documentation
Refer the documentation below for more detailed explanation:

- [Documentation: workflow-azure-apim-crud v1: APIM CRUD workflow](https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1726906421/workflow-azure-apim-crud+v1+Manage+Azure+APIM)
