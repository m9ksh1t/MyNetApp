# README

This documentation is referenced here:

👉 Please visit the main prepare-vars-for-environment.md:  
[**prepare-vars-for-environment.md**](https://github.com/BHGitOps/workflow-aws-eks/blob/main/docs/common/prepare-vars-for-environment.md)
