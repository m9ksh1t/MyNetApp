
# Upgrade Guide: workflow-aws-lambda (v2 → v3)

This document provides step-by-step instructions to migrate your GitHub workflows from **v2** to the **major v3 release** of the [**workflow-aws-lambda**](../../../.github/workflows/workflow.yml) reusable workflow.

> [!NOTE]
> This upgrade includes **breaking changes**, and all application teams must migrate to the updated reusable workflow version to ensure compatibility with new enhancements, including **Matrix(Multiple lambda deployments)** support.
> 
> Any caller workflow referencing workflow versions **≤v2** must follow this upgrade path, as older versions are not compatible with the changes introduced in v3 and must be updated to ensure continued functionality and support.


> [!CAUTION]
> Migration deadline is April 7, 2026.

---

## 🔄 Overview of Changes
The v3 upgrade requires updates across all application caller workflows that reference the [**workflow-aws-lambda**](../../../.github/workflows/workflow.yml) reusable workflow, specifically:
- Updating the reusable workflow version reference to **v3**
- Updating he workflow name from **workflow-aws-lambda.yml** to **workflow.yml**
- Updating parameters for Deploy Matrix strategy

Follow the instructions below to complete the migration safely.

---

## Mock Caller Repositories

A mock workflow, shown below, provides a solid starting point for implementing this version upgrade. Refer to the below mock example.

| Mock Repository URL | Purpose |
|------------------|-------------|
| [**mock-api-dotnet-lambda**](https://github.com/BHGitOps/mock-api-dotnet-lambda/blob/main/.github/workflows/caller-deploy-image-lambda-v3.yml) | Provides a reference implementation for deploying a .NET application using this reusable workflow including Wiz upgrade and Matrix|

> **Tip:** In the mock repository, an additional job—prepare-vars-for-environment—is included to source environment‑level variables. The subsequent job typically consumes these variables from the job outputs (e.g., dev-vars-json or qa-vars-json) and injects them into each matrix item using ${{ fromJSON(...) }}.

> Refer to the [**prepare-vars-for-environment**](../../common/prepare-vars-for-environment.md) guide for detailed instructions on retrieving environment‑level variables.
> This job is optional, the values can be hardcoded, but using it is recommended.

---

## 📝 Step 1: Update the workflow-aws-lambda version reference

Change your reusable workflow reference from **v2** to the **v3** release.

**Before:**
```yaml
uses: BHGitOps/workflow-aws-lambda/.github/workflows/workflow-aws-lambda@v2
```

**After:**
```yaml
uses: BHGitOps/workflow-aws-lambda/.github/workflows/workflow.yml@v3
```

---

## 📝 Step 2: Update parameters for Matrix Strategy
These steps explain all subsequent changes that are related to Matrix. 
This ensures that the pipeline can support multiple Lambda deployments

### Parameter Mapping: v2 → v3 (Single-Target → Matrix Configuration)

This table summarizes how **v2 single-target parameters** map to the new **v3 matrix-based configuration** (`deploy-matrix-config`). Use it as a quick reference when migrating your workflow inputs.

> [!NOTE]
> Refer **Mapping Table** below. Rename the v2 (Old Parameters) to v3 (New Parameters) and place them under the appropriate matrix location. This highlights that, instead of single Lambda deployments, the workflow now supports using a matrix strategy for multiple Lambda deployments.

---

## 🔁 Mapping Table

| v2 (Old Parameter) | v3 (New Parameter) | Location | Notes |
|---|---|---|---|
| `cloud-app-name` | `cloud-app-name` | **deploy-matrix-config** | cloud-app-name moved inside the deploy-matrix-config.*¹ |

*¹ - The parameter names remain the same—however, these values are now placed inside the deploy-matrix-config, where each array item can define its own deployment‑specific values, enabling support for multiple deployments across different Lambdas.


---

## 📋 Example Snippets (for Dev)

**Deploy Matrix (v3):**
```yaml
deploy-matrix-config: |
  [
    {
      "cloud-app-name": "dso-lambda-func3"
    }
  ]
```

> [!WARNING]
> All parameter names and their value assignments inside the `deploy-matrix-config` inputs must be wrapped in **double quotes** to prevent exceptions or value errors.

---

## 🧪 Step 3 : Deprecated or Renamed Parameters

- The following parameters have either been deprecated or renamed:

    - If a parameter is deprecated, it can be safely removed from your workflow.
    - If a parameter has been renamed, update your workflow to use the new parameter name in place of the old one.

### Parameter/Input Changes

| Status      | Old Input Name       | New Input Name       | Notes                                    |
|-------------|----------------------|----------------------|-------------------------------------------|
| Deprecated  | `artifact-path`      | —                        | Remove this parameter from your workflow. |
| Renamed     | `wiz_client_id`      | `wiz-client-id`      | Updated to hyphen-based naming.           |
| Renamed     | `wiz_client_secret`  | `wiz-client-secret`  | Updated to hyphen-based naming.           |


---

## 🧪 Step 4 (Optional): Validate the workflow

After updating:
1. Commit the changes  
2. Push to your branch  
3. Trigger the workflow manually or wait for the next run  
4. Confirm the job completes successfully without authentication or version issues  

---

## ✅ Migration Complete

Your project is now upgraded to the **v3** reusable workflow.  

---

## 📚 Resources

If you'd like a full updated workflow example or additional enhancements, please refer below!

| Mock Repository URL | Purpose | Technology Stack |
|------------------|-------------|----------|
| [**mock-api-dotnet-lambda**](https://github.com/BHGitOps/mock-api-dotnet-lambda) | Provides a reference implementation for deploying a .NET application using this reusable workflow | .NET |
| [**mock-app-python-lambda**](https://github.com/BHGitOps/mock-app-python-lambda) | Provides a reference implementation for deploying a Python application using this reusable workflow | Python |

---

## 📬 Feedback/Need Help?

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
