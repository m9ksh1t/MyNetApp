
# Upgrade Guide: workflow-aws-lambda (v2 → v3)

This document provides step-by-step instructions to migrate your GitHub workflows from **v2** to the **v3** of the [**workflow-aws-lambda**](../../../.github/workflows/workflow.yml) reusable workflow.

> [!NOTE]
> This upgrade includes **breaking changes**, and all application teams must migrate to the updated reusable workflow version to ensure compatibility with new enhancements, including **WIZ Upgrade to 1.x** support.
>
> > Any caller workflow referencing workflow versions **≤v2** must follow this upgrade path, as older versions are not compatible with the changes introduced in v3 and must be updated to ensure continued functionality and support.

> [!CAUTION]
> Migration deadline is April 7, 2026.

---

## 🔄 Overview of Changes
The v3 upgrade requires updates across all application caller workflows that reference the [**workflow-aws-lambda**](../../../.github/workflows/workflow.yml) reusable workflow, specifically:
- Updating the reusable workflow version reference to v3
- Updating the Wiz credential secret names

Follow the instructions below to complete the migration safely.

---

## Mock Caller Repositories

A mock workflow, shown below, provides a solid starting point for implementing this version upgrade. Refer to the below mock example.

| Mock Repository URL | Purpose |
|------------------|-------------|
| [**mock-api-dotnet-lambda**](https://github.com/BHGitOps/mock-api-dotnet-lambda/blob/main/.github/workflows/caller-deploy-image-lambda-v3.yml) | Provides a reference implementation for deploying a .NET application using this reusable workflow including HA and Wiz upgrade |

> **Tip:** In the mock repository, an additional job—prepare-vars-for-environment—is included to source environment‑level variables. The subsequent job typically consumes these variables from the job outputs (e.g., dev-vars-json or qa-vars-json) and injects them into each matrix item using ${{ fromJSON(...) }}.

> Refer to the [**prepare-vars-for-environment**](../../common/prepare-vars-for-environment.md) guide for detailed instructions on retrieving environment‑level variables.
> This job is ***optional***, the values can be hardcoded, but using it is recommended.

---

## 📝 Step 1: Update the workflow-aws-lambda version reference

Change your reusable workflow reference from **v2** to the **v3** release.

**Before:**
```yaml
uses: BHGitOps/workflow-aws-lambda/.github/workflows/workflow-aws-lambda@v2
```

**After:**
```yaml
uses: BHGitOps/workflow-aws-lambda/.github/workflows/workflow.yml@v3
```

---

## 📝 Step 2: Update Wiz credentials

The v3 workflow uses updated Wiz secret variables. Replace the legacy secrets with the new **WIZ_CLIENT_{ID/SECRET}_V1** versions.

**Before:**
```yaml
wiz-client-id: ${{ secrets.WIZ_CLIENT_ID }}
wiz-client-secret: ${{ secrets.WIZ_CLIENT_SECRET }}
```

**After:**
```yaml
wiz-client-id: ${{ secrets.WIZ_CLIENT_ID_V1 }}
wiz-client-secret: ${{ secrets.WIZ_CLIENT_SECRET_V1 }}
```


> [!NOTE]
> The variable names on the left have changed from using an **underscore (_)** to using a **hyphen (-)**.

---

## 🧪 Step 3 : Deprecated or Renamed Parameters

- The following parameters have either been deprecated or renamed:

    - If a parameter is deprecated, it can be safely removed from your workflow.
    - If a parameter has been renamed, update your workflow to use the new parameter name in place of the old one.

### Parameter/Input Changes

| Status      | Old Input Name       | New Input Name       | Notes                                     |
|-------------|----------------------|----------------------|-------------------------------------------|
| Renamed     | `wiz_client_id`      | `wiz-client-id`      | Updated to hyphen-based naming.           |
| Renamed     | `wiz_client_secret`  | `wiz-client-secret`  | Updated to hyphen-based naming.           |

---

## 🧪 Step 4 (Optional): Validate the workflow

After updating:
1. Commit the changes  
2. Push to your branch  
3. Trigger the workflow manually or wait for the next run  
4. Confirm the job completes successfully without version issues  

---

## ✅ Migration Complete

Your project is now upgraded to the **v3** reusable workflow. Please also apply any additional upgrade documentation if available.

---

## 📚 Resources

If you'd like a full updated workflow example or additional enhancements, please refer below!

| Mock Repository URL | Purpose | Technology Stack |
|------------------|-------------|----------|
| [**mock-api-dotnet-lambda**](https://github.com/BHGitOps/mock-api-dotnet-lambda) | Provides a reference implementation for deploying a .NET application using this reusable workflow | .NET |

---

## 📬 Feedback/Need Help?

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
