<h1 align="center">
  <a href=".github/workflows/workflow.yml">workflow-aws-lambda</a>
</h1>

## Overview
This GitHub Actions workflow provides a reusable solution for building, packaging, and deploying AWS Lambda functions using either source code or container images. It supports integration with Azure DevOps to restore organizational NuGet packages and perform Wiz security scans on container images. 

The workflow can publish the application directly from the source code, or alternatively build a Docker image, push it to Amazon ECR, and deploy the Lambda function using that container image. These capabilities enable seamless deployment of .NET applications to AWS Lambda.

This workflow also supports **dynamic OpenAPI (Swagger) specification generation during the build process** .

---

## Getting Started

These documents will help you get up to speed with our engineering practices and tools.

## Reusable Workflow Summary

The table outlines the essential details of the reusable AWS deployment workflow, including its name, current stable version, supported cloud environment and services, compatible tech stacks, and confirmation of Conjur integration

| Workflow Name | [**workflow-aws-lambda**](.github/workflows/workflow.yml) |
| :------| :-------------|
| **Latest Stable Version** | v3 |
| **Current Version** | v3 |
| **Cloud Environment** | AWS |
| **Cloud Services** | AWS Lambda |
| **TechStacks** | .NET, Angular, node/yarn, **Python** |
| **Is Conjur integrated** | Yes*¹ (optional) |
| **High Availability Supported** | Yes |

*¹ - CyberArk Conjur is integrated into this workflow to securely manage sensitive information such as API keys, credentials, and environment variables. Secrets can be fetched dynamically during build and deployment steps, ensuring compliance and security. **Using Conjur is optional**—you may supply the same values via GitHub environment secrets instead.

---

## Reusable Workflow Upgrade Guide

It is considered a best practice to keep your caller/application workflows updated to reference the latest stable version of the reusable workflow. Doing so ensures you benefit from the newest features, security patches, enhancements, and bug fixes provided in this reusable workflow.
For detailed upgrade paths, refer to the table below.

[**workflow-aws-lambda (v2 → v3)**](docs/upgrades/v2/01-wiz-upgrade-guide.md)

[**workflow-aws-lambda (v2 → v3)**](docs/upgrades/v2/02-matrix-upgrade-guide.md)

---

## Mock Caller Repositories

A mock workflow, shown below, provides a solid starting point for implementing this reusable workflow to support application deployments. Refer to the table below for the list of available caller workflows.

| Mock Repository URL | Purpose | Technology Stack |
|------------------|-------------|----------|
| [**mock-api-dotnet-lambda**](https://github.com/BHGitOps/mock-api-dotnet-lambda) | Provides a reference implementation for deploying a .NET application using this reusable workflow | .NET |
| [**mock-app-python-lambda**](https://github.com/BHGitOps/mock-app-python-lambda) | Provides a reference implementation for deploying a python application using this reusable workflow | Python |

> **Tip:** In the mock repository, an additional job—prepare-vars-for-environment—is included to source environment‑level variables. The subsequent job typically consumes these variables from the job outputs (e.g., dev-vars-json or qa-vars-json) and injects them into each matrix item using ${{ fromJSON(...) }}.

> Refer to the [**prepare-vars-for-environment**](docs/common/prepare-vars-for-environment.md) guide for detailed instructions on retrieving environment‑level variables.
> This job is optional, the values can be hardcoded, but using it is recommended.

---

## Features
- Multi-framework support (.NET, Node.js, python, etc.)
- Dual deployment methods (source code and container image)
- Integrated Wiz CLI security scanning for containers
- Optional Super Linter for code quality checks
- Automated artifact management and cleanup
- Flexible authentication (OIDC, Azure Service Principal, GitHub App)
- GitHub submodule support with App token generation
- NuGet/npm package restoration from GitHub Packages or Azure Artifacts
- Python Lambda packaging support (automatic ZIP creation using requirements.txt)
- Dynamic OpenAPI (Swagger) specification generation during build (optional via `generate-openapi`)


## Usage

**Current Version:** `v3`

To use this workflow in your repository:

```yaml
jobs:
  jobs:
  deploy-lambda:
    uses: BHGitOps/workflow-aws-lambda/.github/workflows/workflow.yml@v3
    with:
      framework-type: "dotnet"
      framework-version: "6.0.x"
      working-directory: "./src"
      dependency-version: "latest"
      file-name-to-restore: "MyApp.sln"
      configuration: "Release"
      file-name-to-build: "MyApp.sln"
      file-name-to-publish: "MyApp/MyApp.csproj"
      deploy-matrix-config: |
        [
          {
            "cloud-app-name": "dso-lambda-func3"
          }
        ]
      lambda-deploy-type: "source-code"
      deploy-environment: "dev"
      aws-region: "us-west-2"
      role-session-name: "name for the assumed role"
      oidc-assume-role: "IAM role to assume using OIDC"
    secrets:
      client-id: ${{ secrets.AZURE_CLIENT_ID }}
      tenant-id: ${{ secrets.AZURE_TENANT_ID }}
      subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}

```

---

## Inputs

| Name | Description | Required | Default |
|------|-------------|----------|---------|
| `role-session-name` | Unique identifier for the role session used when assuming an IAM role, which helps in tracing the origin of requests and uniquely identifying sessions | <span style='color:red'>❌</span> | - |
| `oidc-assume-role` | ARN of the IAM role to assume using OIDC, granting the workflow temporary access to its permissions associated with that IAM role | <span style='color:red'>❌</span> | - |
| `aws-account-id` | AWS Account ID where resources will be accessed or deployed | <span style='color:red'>❌</span> | - |
| `framework-type` | Type of framework used to build and deploy code (e.g., dotnet) | <span style='color:green'>✔️</span> | - |
| `framework-version` | Version of the framework to install (e.g., 6.0.x, 16.x) | <span style='color:green'>✔️</span> | - |
| `cloud-app-name` | The name of the cloud app resource name (e.g., aws-lambda-function-name) | <span style='color:red'>❌</span> | - |
| `working-directory` | Path to the working directory containing the application | <span style='color:green'>✔️</span> | - |
| `dependency-version` | Version of the dependency package to install | <span style='color:green'>✔️</span> | - |
| `file-name-to-restore` | Specify a specific filename, such as .sln or .csproj files, to restore. Useful when multiple files exist in a single directory | <span style='color:green'>✔️</span> | - |
| `nuget-config-path` | Path to the nuget config file | <span style='color:red'>❌</span> | - |
| `app-location` | Provide the source code location | <span style='color:red'>❌</span> | - |
| `configuration` | Specify the build configuration (e.g., Debug, Release) | <span style='color:green'>✔️</span> | - |
| `file-name-to-build` | Solution or project file to build (e.g., MyApp.sln, MyProject.csproj) | <span style='color:green'>✔️</span> | - |
| `file-name-to-publish` | Specify the path to the project file (.csproj) to publish | <span style='color:red'>❌</span> | - |
| `build-artifacts` | Directory where build artifacts will be stored | <span style='color:red'>❌</span> | output/ |
| `artifact-name` | Artifact name | <span style='color:red'>❌</span> | - |
| `image-tag` | The Docker tag name to use for the docker image (e.g., latest) | <span style='color:red'>❌</span> | latest |
| `policy-name` | Name of the policy to scan the image | <span style='color:red'>❌</span> | - |
| `project-id` | Project ID used for image scanning or reporting | <span style='color:red'>❌</span> | - |
| `deploy-runner-type` | GitHub Actions runner type (e.g., self-hosted, ubuntu-latest) | <span style='color:green'>✔️</span> | ubuntu-latest |
| `skip-deploy-job` | Set to true to skip the deployment job | <span style='color:red'>❌</span> | false |
| `package-source-org` | GitHub organization or Azure DevOps org for publishing the package | <span style='color:red'>❌</span> | BHGitOps |
| `target-file` | Target file to overwrite with corresponding environment secrets | <span style='color:red'>❌</span> | - |
| `aws-region` | AWS region where the Lambda is hosted | <span style='color:red'>❌</span> | us-west-2 |
| `container-repository` | The name of the container repository required to log into ECR | <span style='color:red'>❌</span> | - |
| `lambda-deploy-type` | The source for the aws function deployment (container-image: use this when you want to deploy container-image, source-code: use this when you want to deploy source-code) | <span style='color:red'>❌</span> | - |
| `output-location` | Provide the output location | <span style='color:red'>❌</span> | - |
| `source-code-zip` | Provide the file location of zipped source code for deployment to AWS Lambda | <span style='color:red'>❌</span> | - |
| `deploy-environment` | Deployment environment (e.g., dev, test, prod) | <span style='color:green'>✔️</span> | - |
| `include-super-linter` | Boolean variable to enable/disable linting | <span style='color:red'>❌</span> | false |
| `linter-filter-regex-include` | Specifies the files and folders to be included in the linting | <span style='color:red'>❌</span> | - |
| `linter-filter-regex-exclude` | Specifies the files and folders to be excluded from linting | <span style='color:red'>❌</span> | - |
| `linter-rules-config-path` | Config files path for various linters | <span style='color:red'>❌</span> | - |
| `docker-file-path` | Specify the path to dockerfile | <span style='color:red'>❌</span> | - |
| `docker-build-context` | Specify the build context path for the Docker build | <span style='color:red'>❌</span> | - |
| `package-source` | NuGet source to use (e.g., github, azure-artifacts) | <span style='color:red'>❌</span> | azure-artifacts |
| `azure-org` | Azure DevOps organization name (required if using Azure Artifacts) | <span style='color:red'>❌</span> | Bannerhealth |
| `azure-feed` | Name of the Azure Artifacts feed | <span style='color:red'>❌</span> | - |
| `package-source-name` | Alias name to assign to the NuGet source | <span style='color:red'>❌</span> | Azure |
| `azure-user-name` | Username for authenticating to Azure Artifacts | <span style='color:red'>❌</span> | AzureDevOps |
| `artifact-path` | Path to the downloaded artifact file to be deleted after use | <span style='color:red'>❌</span> | output.tar |
| `artifact-download-path` | Path to download the artifact file | <span style='color:red'>❌</span> | . |
| `submodules` | Flag to indicate whether submodules should be included. Set to "true" to enable token generation | <span style='color:red'>❌</span> | false |
| `repositories-owner` | The GitHub organization or user that owns the GitHub Repositories | <span style='color:red'>❌</span> | BHGitOps |
| `repositories` | List of repositories requiring access to the GitHub App token, formatted as a comma-separated string without spaces (e.g., repo1,repo2,repo3) | <span style='color:red'>❌</span> | - |
| `conjur-variable-json` | Json file that maps vaults and secrets to fetch the secrets from conjur | ✅ | string | - |
| `build-runner` | Specifies the GitHub Actions runner or runner group where the build job should execute. This allows targeting a specific self-hosted runner group or the default GitHub-hosted runners for the build process | <span style='color:red'>❌</span> | ubuntu-latest |
| `requirements-file` | Path to the Python requirements file used when building Python Lambda ZIP packages | <span style='color:red'>❌</span> | requirements.txt |
| `target-directory` | Directory where Python dependencies will be installed | <span style='color:red'>❌</span> | python |
| `layer-name` | Name of the AWS Lambda layer to check or create | <span style='color:red'>❌</span> | - |
| `deploy-matrix-config` | Configuration data for matrix-based deploy job execution | <span style='color:red'>❌</span> | - |
| `generate-openapi` | Enables OpenAPI (Swagger) specification generation during the build phase using Swashbuckle CLI. | ❌ | <span style='color:red'>❌</span> | false |
| `swashbuckle-version` | Version of Swashbuckle.AspNetCore.Cli used for OpenAPI generation. | <span style='color:red'>❌</span> | string | 6.6.2 |

---

## Secrets

| Name | Description | Required |
|------|-------------|----------|
| `github-token` | GitHub token used for authentication when accessing GitHub Packages |
| `client-id` | Azure Service Principal Client ID used for authentication with Azure resources |
| `subscription-id` | Azure Subscription ID where the resources are deployed |
| `tenant-id` | Azure Active Directory Tenant ID associated with the Service Principal for authentication |
| `secrets-json` | JSON object containing additional secret values required for deployment or configuration |
| `gh-app-id` | GitHub App ID used for authentication and token generation |
| `gh-app-private-key` | Private key for the GitHub App, used to authenticate and generate the token |
| `conjur-appliance-url` | CyberArk Conjur Appliance URL |
| `conjur-account` | CyberArk Conjur Account |
| `conjur-workload-id` | Conjur workload ID |
| `conjur-api-key` | API key for Conjur workload |

---

## Jobs & Steps

# Job 1: app-build
Builds the application and prepares artifacts for deployment.

# steps: 
- Generate GitHub App Installation Token (if submodules enabled)
- Checkout Repository
- Set up Docker (if Super Linter enabled)
- Run Super Linter (if enabled)
- Setup Framework
- Setup Dependency Manager (installs dependencies and optionally generates OpenAPI spec using Swashbuckle when enabled)
- Login to Azure (if NuGet config or Azure feed specified)
- Get Azure DevOps Access Token (if required)
- Set up NuGet for GitHub Packages or Azure Artifacts
- Restore Dependencies
- Clean the artifacts
- Fetch Secret from CyberArk Conjur
- Json transform (if target file specified)
- Build
- Publish (for .NET framework)
- Upload Artifacts

# Job 2: image-build
Creates, scans, and pushes Docker container images (runs only if lambda-deploy-type is container-image).

# steps: 
- Checkout Repository
- Download Artifact
- Set up AWS CLI
- Configure AWS Credentials using OIDC
- Login to Amazon ECR
- Set up Docker
- Build Docker Image
- Fetch Secret from CyberArk Conjur
- Set up Wiz CLI
- Set up WIZ scanning for images
- Save Docker Image to .tar
- Load and Tag Image
- Push Docker image to Amazon ECR
- Clean up Docker
- Clean Up Runner workspace

# Job 3: deploy-aws-lambda-layers
Creates new Lambda layers and new Lambda layer versions (if the layer does not exist).

# Steps: 
- Checkout Repository
- Download Artifact
- Set up AWS CLI
- Configure AWS Credentials using OIDC
- Create AWS Lambda layers
- Clean up runner workspace

# Job 4: deploy-aws-lambda
Deploys the Lambda function using either source code or container image.

# Steps:
- Checkout Repository
- Download Artifact (if source code deployment)
- Set up AWS CLI
- Configure AWS Credentials using OIDC
- Login to Amazon ECR (if container image deployment)
- Pull Docker image from Amazon ECR (if container image deployment)
- Deploy to AWS Lambda
- Clean up Docker
- Clean Up Runner workspace

---

## **Example Scenarios**
- Deploy Lambda using **container image** stored in Amazon ECR
- Deploy Lambda using **source code zip**
- Create Lambda **layers**
- Attach Lambda layers to lambda functions
- Integrate **Wiz scanning** for container security

---

## Best Practices
- Use OIDC Authentication: Avoid storing long-lived AWS credentials by using OpenID Connect for secure, keyless authentication
- Enable Security Scanning: Always scan container images with Wiz before deployment to identify vulnerabilities
- Version Your Images: Use semantic versioning for image-tag (e.g., v1.0.0, v1.2.3)
- Separate Environments: Use different workflows or input configurations for dev/test/prod environments
- Clean Up Resources: The workflow automatically cleans up artifacts and Docker images after execution
- Use Self-Hosted Runners: For sensitive workloads, specify deploy-runner-type: 'self-hosted'
- Enable Linting: Set include-super-linter: true for automated code quality checks
- Store Secrets Securely: Use GitHub Secrets for all sensitive values (credentials, tokens, keys)
- Validate Specifications: Test your build and deployment configurations in non-production   environments first
- Monitor Deployments: Review GitHub Actions logs and AWS CloudWatch for deployment status and errors

---

## Changelog 📝

All notable changes to this project will be documented in this section.

| Version | Date       | Tags                                      | Changes |
|:------:|:------------|-------------------------------------------|---------|
| **v3.6.0** | 2026‑05‑10 | Lambda, OpenAPI, Build Enhancement  | **Added:** Dynamic OpenAPI specification generation during build using Swashbuckle<br>**Improved:** Build step modularization with optional OpenAPI generation support |
| **v3.3** | 2026‑03‑26 | Lambda                                   | **Added:** Lambda layer creation and attachment |
| **v3.1** | 2026‑02‑15 | Lambda, Python                           | **Added:** Python Lambda ZIP packaging |
| **v3** | 2025‑12‑15 | CyberArk Conjur, Security                | **Added:** Conjur secret retrieval in Docker workflows |
| **v2** | 2025‑10‑10 | Major Update, Breaking Changes, Security | **Changed:** Credentials, Wiz secrets, deployment model, Azure auth<br>**Added:** GitHub App auth, new inputs/secrets, token automation<br>**Improved:** Security, cleanup, configurability, docs |
| **v1** | 2025‑01‑15 | Initial Release                          | **Added:** Initial reusable Lambda workflow with multi‑framework support, security scanning, and OIDC |

---
## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>
  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1555628033/workflow-aws-lambda+Reusable+CI+CD+Workflow+for+AWS+lambda+Deployment+In+Progress">Workflow-aws-lambdaᵈ²</a>
    </strong>
    <p>
      Workflow-aws-lambda - Reusable GitHub workflow building and deploying applications to AWS Lambda.
    </p>
  </article>  

---

## Feedback/Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
