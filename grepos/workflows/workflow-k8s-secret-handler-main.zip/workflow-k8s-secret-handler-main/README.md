<h1 align="center">
  <a href=".github/workflows/workflow.yml">workflow-k8s-secret-handler</a>
</h1>

## Overview
This GitHub Actions workflow provides a reusable solution for managing **Kubernetes secrets** in Amazon **EKS** clusters. It supports multiple secret operations, including creating **generic secrets, TLS secrets, and AWS Secrets Manager-backed secrets,** as well as deleting existing secrets.

The workflow integrates with CyberArk Conjur for dynamic secret retrieval, enabling secrets to be sourced from Conjur, **GitHub environment secrets**, or AWS Secrets Manager before being applied to the target Kubernetes namespace.

---

## Getting Started

These documents will help you get up to speed with our engineering practices and tools.

## Reusable Workflow Summary

The table outlines the essential details of the reusable Kubernetes secret management workflow, including its name, current stable version, supported cloud environment and services, compatible tech stacks, and confirmation of Conjur integration

| Workflow Name | [**workflow-k8s-secret-handler**](.github/workflows/workflow.yml) |
| :------| :-------------|
| **Latest Stable Version** | [**v4**](https://github.com/BHGitOps/workflow-k8s-secret-handler/blob/v4/README.md) |
| **Current Version** | [**v4**](https://github.com/BHGitOps/workflow-k8s-secret-handler/blob/v4/README.md) |
| **Cloud Environment** | AWS |
| **Cloud Services** | Amazon EKS, AWS Secrets Manager |
| **TechStacks** | Kubernetes |
| **Is Conjur integrated** | Yes*¹ (optional) |
| **High Availability Supported** | Yes |

*¹ - CyberArk Conjur is integrated into this workflow to securely manage sensitive information such as API keys, credentials, and TLS certificates. Secrets can be fetched dynamically during execution and applied directly to Kubernetes, ensuring compliance and security. **Using Conjur is optional**—you may supply the same values via GitHub environment secrets instead.

---

## Mock Caller Repositories

A mock workflow demonstrating the usage of this reusable workflow is provided below:

| Mock Repository URL | Purpose | Technology Stack |
|---------------------|----------|------------------|
| [**mock-k8s-secrets**](https://github.com/BHGitOps/mock-k8s-secrets) | Provides a reference implementation for managing Kubernetes secrets using this reusable workflow | Amazon EKS, AWS Secrets Manager |

---

## Reusable Workflow Upgrade Guide

It is considered a best practice to keep your caller/application workflows updated to reference the latest stable version of the reusable workflow. Doing so ensures you benefit from the newest features, security patches, enhancements, and bug fixes provided in this reusable workflow.

---

## Key Features & Capabilities
- Manages **TLS certificates** within Kubernetes.
- Creates and manages Kubernetes secrets backed by **AWS Secrets Manager**.
- Synchronizes secrets:
  - Conjur → Kubernetes (generic and TLS secrets)
  - Conjur → AWS Secrets Manager
- Create Kubernetes secrets from:
  - GitHub Secrets
  - CyberArk Conjur
  - AWS Secrets Manager (EKS)
- Secure deletion of Kubernetes secrets.
- Flexible and secure authentication using:
  - OIDC (AWS)
  - Conjur Workload Identity
- Fully supports **AWS EKS** clusters.
- Automatically cleans up runner workspaces after execution.
- Centralized secret management for multi-cloud Kubernetes deployments.
- Ensures secrets are never logged or exposed during workflow execution.
- Supports multiple secret operations: create, delete, and TLS secret management.

> [!TIP]  
> Start with a single secret operation (e.g., `create-generic-secret`). You can expand to multi-cloud or advanced secret flows later.

> [!NOTE]  
> Conjur is the recommended long-term source of truth for secrets. Use `conjur-variable-json` to fetch Conjur-based secrets for Kubernetes. The workflow supports GitHub Secrets and cloud secret managers for backward compatibility.

---

## Prerequisites

### AWS (EKS)
- EKS cluster configured
- IAM role with OIDC federation enabled
- AWS Secrets Manager available if used

### Common
- Conjur Workload ID & API Key (if using Conjur secrets)
- Namespace created in Kubernetes cluster

> [!IMPORTANT]  
> Please ensure all required infrastructure (AWS IAM roles, Conjur workload setup, namespaces, KeyVault/Secrets Manager entries) are created before invoking this workflow. Coordinate with Platform/IAC teams when needed.

---

## Usage

**Current Version:** `v1`

To use this workflow in your repository:

```yaml
jobs:
  manage-k8s-secret:
    uses: BHGitOps/workflow-k8s-secret-handler/.github/workflows/workflow.yml@v4
    with:
      cluster-type: "eks"
      cluster-name: "my-eks-cluster"
      aws-region: "us-west-2"
      deploy-environment: "dev"
      deploy-runner-type: "ubuntu-latest"
      secret-name: "my-app-secret"
      namespace: "my-namespace"
      secret-operation: "create-generic-secret"
      oidc-assume-role: "arn:aws:iam::123456789012:role/my-deploy-role"
      role-session-name: "my-deploy-session"
    secrets:
      secrets-json: ${{ secrets.SECRETS_JSON }}
```

---

## Inputs

| Name | Description | Required | Type | Default |
|------|-------------|:--------:|:-------:|:---------:|
| `cluster-type` | Kubernetes cluster type (eks/aks) | ✅ | string | - |
| `deploy-environment` | Environment name | ✅ | string | - |
| `deploy-runner-type` | GitHub runner type | ✅ | string | ubuntu-latest |
| `secret-name` | Name of the Kubernetes secret | ✅ | string | - |
| `namespace` | Kubernetes namespace | ✅ | string | - |
| `secret-operation` | Operation type (create/delete/etc.) | ✅ | string | - |
| `cluster-name` | Kubernetes cluster name | ✅ | string | - |
| `aws-region` | AWS region (for EKS) | ❌ | string | - |
| `role-session-name` | Role session name for AWS | ❌ | string | - |
| `oidc-assume-role` | Assume role ARN for AWS | ❌ | string | - |
| `aws-account-id` | AWS account ID | ❌ | string | - |
| `secrets-keys` | Comma-separated list of secret keys | ❌ | string | - |
| `conjur-variable-json` | JSON mapping for Conjur secret paths | ❌ | string | - |
| `secret-id` | AWS Secrets Manager secret ID | ❌ | string | - |

---

## Secrets

| Secret Name | Description | Required | Type |
|-------------|-------------|:--------:|:-------:|
| `conjur-appliance-url` | Conjur instance URL | ❌ | string |
| `conjur-account` | Conjur account | ❌ | string |
| `conjur-workload-id` | Conjur workload ID | ❌ | string |
| `conjur-api-key` | Conjur API key | ❌ | string |
| `secrets-json` | GitHub secrets in JSON | ❌ | string |
| `tls-cert` | TLS certificate | ❌ | string |
| `tls-key` | TLS private key | ❌ | string |

> [!CAUTION]  
> Application teams must ensure all secrets are stored securely. If any secret is suspected to be compromised, rotate it immediately and notify the security team.

---

## Jobs & Steps

# Job 1: eks-k8s-secrets
Manages Kubernetes secrets in an Amazon EKS cluster. Runs only when `cluster-type` is set to `eks`.

# Steps:
- Checkout Repository
- Fetch Secret from CyberArk Conjur (if `conjur-variable-json` is provided)
- Login to AWS
- Set up AWS CLI
- Download and Install kubectl
- Authenticate to AWS EKS
- Create Kubernetes Secret from GitHub Secrets (if `secret-operation` is `create-generic-secret`)
- Create Kubernetes Secrets from Conjur Secrets (if `secret-operation` is `conjur-to-generic-secret`)
- Create TLS Secrets from GitHub Secrets (if `secret-operation` is `create-tls-secret`)
- Create TLS Secrets from Conjur Secrets (if `secret-operation` is `conjur-to-tls-secret`)
- Create Kubernetes Secret from AWS Secrets Manager (if `secret-operation` is `create-secret-manager`)
- Create AWS Secrets from Conjur Secrets (if `secret-operation` is `conjur-to-secret-manager`)
- Delete Kubernetes Secret (if `secret-operation` is `delete-k8s-secret`)
- Clean Up Runner workspace (always)

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checkout repository |
| [**action-conjur-fetch-secrets**](https://github.com/BHGitOps/action-conjur-fetch-secrets) | Securely fetch secrets from CyberArk Conjur using API key authentication |
| [**action-configure-aws-credentials**](https://github.com/BHGitOps/action-configure-aws-credentials) | Configures AWS credentials via OIDC and assumes the specified role. |
| [**action-install-aws-cli**](https://github.com/BHGitOps/action-install-aws-cli) | Installs the AWS CLI for ECR and registry operations. |
| [**action-install-kubectl**](https://github.com/BHGitOps/action-install-kubectl) | Installs kubectl to interact with the Kubernetes cluster. |
| [**action-authenticate-eks**](https://github.com/BHGitOps/action-authenticate-eks) | Authenticates to the AWS EKS cluster. |
| [**action-gh-secrets-to-k8s**](https://github.com/BHGitOps/action-gh-secrets-to-k8s) | Creates Kubernetes secrets using GitHub‑stored JSON secrets. |
| [**action-conjur-k8s-secret**](https://github.com/BHGitOps/action-conjur-k8s-secret) | Creates Kubernetes generic secrets using values sourced from Conjur. |
| [**action-k8s-tls-cert**](https://github.com/BHGitOps/action-k8s-tls-cert) | Fetch secrets from GitHub and create TLS secrets in Kubernetes |
| [**action-conjur-k8s-tls-secret**](https://github.com/BHGitOps/action-conjur-k8s-tls-secret) | Create Kubernetes TLS Secret from Conjur-Fetched Environment Variables |
| [**action-aws-secrets-manager-to-k8s**](https://github.com/BHGitOps/action-aws-secrets-manager-to-k8s) | Fetch secrets from AWS Secrets Manager and create Kubernetes secrets |
| [**action-conjur-aws-secret-manager**](https://github.com/BHGitOps/action-conjur-aws-secret-manager) | Use secrets retrieved from Conjur and add them to AWS Secrets Manager |
| [**action-delete-k8s-secrets**](https://github.com/BHGitOps/action-delete-k8s-secrets) | Delete a Kubernetes secret or specific keys within a secret |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Performs final cleanup of runner artifacts and temporary files. |

---

## **Example Scenarios**
- Create a **generic Kubernetes secret** from GitHub environment secrets
- Create a **TLS secret** in Kubernetes from GitHub environment secrets
- Sync secrets from **CyberArk Conjur** to a Kubernetes generic secret
- Sync secrets from **CyberArk Conjur** to a Kubernetes TLS secret
- Create a **Kubernetes secret backed by AWS Secrets Manager**
- Sync secrets from **CyberArk Conjur** to AWS Secrets Manager
- **Delete** an existing Kubernetes secret from a namespace
  
---

## Changelog 📝

| Version | Date | Tags | Changes |
|--------|--------|------------------------|----------|
| **v3** | 2026-02-18 | Major Update | - **Added:** Full CyberArk Conjur integration including `conjur-variable-json` to fetch secrets for Kubernetes, TLS, and AWS Secrets Manager flows.<br>- **Added:** New operations: `conjur-to-generic-secret`, `conjur-to-tls-secret`, and `conjur-to-secret-manager` to support multi-source secret orchestration.<br>- **Added:** Conjur authentication step using `action-conjur-fetch-secrets@v2` for EKS workflows.<br>- **Improved:** Updated workflow name and description to reflect multi-cloud and multi-source secret capabilities.<br>- **Changed:** Replaced `secret-keys` → `secrets-keys` for consistency across Conjur and Kubernetes secret actions.<br>- **Added:** Extended secrets and inputs descriptions for clarity and improved onboarding.<br>- **Added:** Support for Conjur-based TLS secrets using `action-conjur-k8s-tls-secret@v1`. |
| **v2** | 2025-11-27 | Major Update | - **Changed:** Updated `action-gh-secrets-to-k8s` from `@v1` → `@v2` for improved JSON handling.<br>- **Changed:** Moved `oidc-assume-role` and `role-session-name` from secrets to inputs for better flexibility.<br>- **Added:** Clean Up Runner workspace step using `BHGitOps/action-clean-runner-artifacts@v1`.<br>- **Removed:** `secret-keys` from generic-secret creation step (now only used for delete operation). |
| **v1** | 2025-10-15 | Initial Release | - **Added:** Support for creating Kubernetes secrets from GitHub Secrets, TLS secrets, AWS Secrets Manager.<br>- **Added:** Delete Kubernetes secrets functionality.<br>- **Added:** Authentication for EKS (OIDC). |

---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>
  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1399652510/workflow-k8s-secret-handler">Workflow-k8s-secret-handlerᵈ²</a>
    </strong>
    <p>
      Workflow-k8s-secret-handler - Reusable GitHub workflow for configuring Kubernetes secrets in EKS or AKS.
    </p>
  </article>  

---

## Feedback/Need Help? 📬
If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!.
