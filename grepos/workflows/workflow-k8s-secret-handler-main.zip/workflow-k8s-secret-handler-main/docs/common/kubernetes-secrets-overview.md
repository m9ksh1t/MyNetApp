<h1 align="center">
  <a href="../../README.md">Kubernetes Secrets & GitHub-to-K8s Secret Workflow Guide</a>
</h1>

## Overview

**Kubernetes Secrets** are objects that let you store and manage sensitive information — such as passwords, API tokens, TLS certificates, and SSH keys — separately from application code and Pod specifications. By decoupling secrets from your workload definitions, Kubernetes reduces the risk of accidental exposure and allows secrets to be rotated independently of deployments.

The **`workflow-k8s-secret-handler`** reusable workflow bridges the gap between **GitHub Secrets** (your CI/CD secret store) and **Kubernetes Secrets** (your runtime secret store) by automating the secure transfer of secret values into a target namespace inside an Amazon EKS cluster.

---

## What Are Kubernetes Secrets?

A Kubernetes Secret is a first-class API object (`kind: Secret`) stored in the cluster's etcd datastore. Secrets can be consumed by Pods as:

- **Environment variables** injected at container startup
- **Mounted volumes** exposed as files on the container filesystem
- **Image pull secrets** used by the kubelet to authenticate against private container registries

### Secret Types

| Type | Description |
|------|-------------|
| `Opaque` | Default type; arbitrary user-defined key-value pairs (generic secrets) |
| `kubernetes.io/tls` | Stores a TLS certificate (`tls.crt`) and private key (`tls.key`) pair |

> [!NOTE]
> By default, Kubernetes Secrets are base64-encoded, **not encrypted**, in etcd. Always ensure your cluster has **encryption at rest** enabled and restrict access using Kubernetes RBAC policies.

### Why Use Kubernetes Secrets Instead of ConfigMaps?

| Feature | ConfigMap | Secret |
|---------|-----------|--------|
| Intended for sensitive data | ❌ | ✅ |
| Base64 encoded in etcd | ❌ | ✅ |
| Access restricted via RBAC | Possible | Recommended |
| Shown in logs/describe output | Yes | Redacted |

> [!IMPORTANT]
> Secrets should **never** be hardcoded in container images, source code, or Kubernetes manifest files committed to version control. Use this workflow to inject them at runtime.

---

## Recommendation

DSO pipelines support storing secrets across multiple platforms and services:

| Platform / Service | Supported Secret Types |
|--------------------|------------------------|
| **Azure Key Vault** | Secrets, Key-value pairs |
| **AWS Secrets Manager** | secrets, Key-value pairs |
| **Azure App Configuration** | Key-value pairs, feature flags |
| **APIM Named Values** | Plain values, secrets, Key Vault references |

While all of the above are valid integration points, the **recommended approach** for runtime secret delivery to containerized workloads is to store and consume secrets as **Kubernetes Secrets** using the [`workflow-k8s-secret-handler`](../../README.md) reusable workflow.

> [!TIP]
> Using `workflow-k8s-secret-handler` ensures secrets are consistently managed, namespace-scoped, and decoupled from application deployments — regardless of the upstream secret source (GitHub Secrets, Conjur, or AWS Secrets Manager).

---

## How the Workflow Pushes GitHub Secrets to Kubernetes

The `workflow-k8s-secret-handler` reusable workflow automates the following end-to-end flow:

```
GitHub Secrets (secrets-json)
        │
        ▼
GitHub Actions Runner (workflow-k8s-secret-handler)
        │  ├─ Authenticates to AWS via OIDC
        │  ├─ Configures kubectl against the target EKS cluster
        │  └─ Calls action-gh-secrets-to-k8s
        ▼
Kubernetes Secret  ──►  Target Namespace (e.g., my-namespace)
```

### Secret Operation: `create-generic-secret`

This is the primary operation for pushing **GitHub Secrets** into a Kubernetes generic (`Opaque`) secret. The caller workflow packages the required secret values into a JSON object stored as a GitHub Secret (`secrets-json`), then passes it to the reusable workflow, which creates or replaces the Kubernetes Secret in the specified namespace.

### Secret Operation: `create-tls-secret`

When TLS certificates are stored as GitHub Secrets (`tls-cert` and `tls-key`), this operation creates a `kubernetes.io/tls` typed secret in the target namespace — ready to be referenced by Ingress resources or workloads that require mutual TLS.

---

## Caller Workflow Setup

### Step 1 — Store Secrets in GitHub

Navigate to your repository's **Settings → Secrets and variables → Actions** and create the following secrets per environment:

| GitHub Secret Name | Value | Notes |
|--------------------|-------|-------|
| `DB_PASSWORD` | my-pass | GitHub Secret name is the key and GitHub secret value will be value that is pushed into Kubernetes |
| `TLS_CERT` | PEM-encoded certificate | Required only for `create-tls-secret` operation |
| `TLS_KEY` | PEM-encoded private key | Required only for `create-tls-secret` operation |

> [!TIP]
> Keys in `SECRETS_JSON` become the **data keys** inside the resulting Kubernetes Secret. Name them exactly as your application expects to consume them (e.g., as environment variable names or file names).

### Step 2 — Create the Caller Workflow

Create a workflow file (e.g., `.github/workflows/deploy-secrets.yml`) in your application repository:

#### Example: Push Generic Secrets to a Namespace

```yaml
name: Deploy Kubernetes Secrets

on:
  workflow_dispatch:
  push:
    branches:
      - main

jobs:
  deploy-k8s-secrets:
    uses: BHGitOps/workflow-k8s-secret-handler/.github/workflows/workflow.yml@[latest-stable-version]
    with:
      cluster-type: "eks"
      cluster-name: "my-eks-cluster"
      aws-region: "us-east-1"
      deploy-environment: "dev"
      deploy-runner-type: "ubuntu-latest"
      secret-name: "my-app-secret"
      namespace: "my-namespace"
      secret-operation: "create-generic-secret"
      oidc-assume-role: "arn:aws:iam::123456789012:role/my-deploy-role"
      role-session-name: "my-deploy-session"
    secrets:
        secrets-json: |
          {
            "DB_USER": "${{ secrets.DB_USER }}",
            "DB_PASS": "${{ secrets.DB_PASS }}"
          }
```

#### Example: Push TLS Secrets to a Namespace

```yaml
name: Deploy TLS Secrets

on:
  workflow_dispatch:

jobs:
  deploy-tls-secret:
    uses: BHGitOps/workflow-k8s-secret-handler/.github/workflows/workflow.yml@v4
    with:
      cluster-type: "eks"
      cluster-name: "my-eks-cluster"
      aws-region: "us-east-1"
      deploy-environment: "prod"
      deploy-runner-type: "ubuntu-latest"
      secret-name: "my-tls-secret"
      namespace: "my-namespace"
      secret-operation: "create-tls-secret"
      oidc-assume-role: "arn:aws:iam::123456789012:role/my-deploy-role"
      role-session-name: "my-deploy-session"
    secrets:
      tls-cert: ${{ secrets.TLS_CERT }}
      tls-key: ${{ secrets.TLS_KEY }}
```

> [!NOTE]
> The target **namespace must already exist** in the cluster before the workflow runs. Work with your Platform/IAC team to ensure namespaces are pre-provisioned.

---

## Key Inputs Reference

The table below lists the inputs most relevant to the GitHub Secrets → Kubernetes flow. For the full inputs reference, see the [README](../../README.md#inputs).

| Input | Description | Required | Example |
|-------|-------------|:--------:|---------|
| `cluster-type` | Kubernetes cluster type | ✅ | `eks` |
| `cluster-name` | Name of the EKS cluster | ✅ | `my-eks-cluster` |
| `aws-region` | AWS region of the cluster | ✅ | `us-east-1` |
| `deploy-environment` | GitHub environment name | ✅ | `dev` |
| `namespace` | Target Kubernetes namespace | ✅ | `my-namespace` |
| `secret-name` | Name of the resulting Kubernetes Secret | ✅ | `my-app-secret` |
| `secret-operation` | Operation to perform | ✅ | `create-generic-secret` |
| `aws-account-id` | AWS Account ID where resources will be accessed or deployed | ✅ | `123456789012` |
| `oidc-assume-role` | IAM role ARN for OIDC authentication | ✅ | `arn:aws:iam::123456789012:role/...` |
| `role-session-name` | AWS role session identifier | ❌ | `my-deploy-session` |

## Secrets Reference

| Secret | Description | Required For |
|--------|-------------|:------------:|
| `secrets-json` | GitHub secrets in json format of key-value pairs | `create-generic-secret` |
| `tls-cert` | PEM-encoded TLS certificate | `create-tls-secret` |
| `tls-key` | PEM-encoded TLS private key | `create-tls-secret` |

---

## Supported Secret Operations

| `secret-operation` Value | Source | Kubernetes Secret Type | Description |
|--------------------------|--------|------------------------|-------------|
| `create-generic-secret` | GitHub Secrets (`secrets-json`) | `Opaque` | Creates a generic secret from JSON key-value pairs |
| `create-tls-secret` | GitHub Secrets (`tls-cert`, `tls-key`) | `kubernetes.io/tls` | Creates a TLS secret from a certificate/key pair |
| `create-secret-manager` | AWS Secrets Manager | `Opaque` | Creates a Kubernetes secret from an AWS Secrets Manager entry |
| `conjur-to-secret-manager` | CyberArk Conjur | AWS Secrets Manager | Pushes Conjur secrets into AWS Secrets Manager |
| `delete-k8s-secret` | N/A | N/A | Deletes an existing Kubernetes secret from the namespace |

---

## Prerequisites

Before invoking the workflow, confirm the following are in place:

- [ ] Target **EKS cluster** is running and accessible
- [ ] Target **namespace** exists in the cluster
- [ ] An **IAM role** with OIDC federation is configured for GitHub Actions
- [ ] The IAM role has permissions to interact with the EKS cluster (`eks:DescribeCluster`)
- [ ] The Kubernetes RBAC is configured to allow the IAM role to create/update/delete secrets in the target namespace
- [ ] GitHub Secrets are stored in the appropriate **GitHub environment** matching `deploy-environment`

> [!CAUTION]
> Ensure the IAM role's trust policy is scoped to the specific repository and branch/environment to prevent unauthorized secret injection from other workflows.

---

## Resources 📚

| Resource | Description |
|----------|-------------|
| [Kubernetes Secrets Documentation](https://kubernetes.io/docs/concepts/configuration/secret/) | Official Kubernetes reference for Secrets |
| [workflow-k8s-secret-handler README](../../README.md) | Full inputs, secrets, and changelog for this reusable workflow |
| [mock-k8s-secrets](https://github.com/BHGitOps/mock-k8s-secrets) | Reference implementation showing caller workflow usage |
| [GitHub Reusable Workflowᵈ¹](https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow) | Central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. |

---

## Feedback/Need Help? 📬
If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
