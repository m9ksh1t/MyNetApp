<h1 align="center">
  <a href=".github/workflows/workflow.yml">workflow-aws-secrets-manager</a>
</h1>

## Overview

This GitHub Actions workflow provides a reusable solution for managing **AWS Secrets Manager operations**. It supports creating, uploading, updating with encryption (BYOK), and deleting secrets securely. The workflow enables **flexible secret management** with optional CyberArk Conjur integration for fetching secrets dynamically during **workflow execution**.

Key capabilities include authentication via OIDC (no long-lived credentials required), support for both GitHub Secrets and Conjur as secret sources, and optional KMS encryption for enhanced security.

---

## Getting Started

These documents will help you get up to speed with our engineering practices and tools.

## Reusable Workflow Summary

The table outlines the essential details of the reusable AWS Secrets Manager workflow, including its name, current stable version, supported cloud environment and services, and confirmation of Conjur integration

| Property | Value |
| :------ | :------------- |
| **Workflow Name** | [**workflow-aws-secrets-manager**](.github/workflows/workflow.yml) |
| **Latest Stable Version** | [**v3**](https://github.com/BHGitOps/workflow-aws-secrets-manager/blob/v3/README.md) |
| **Current Version** | [**v3**](https://github.com/BHGitOps/workflow-aws-secrets-manager/blob/v3/README.md) |
| **Cloud Environment** | AWS |
| **Cloud Services** | AWS Secrets Manager |
| **Is Conjur integrated** | Yes*¹ (optional) |
| **High Availability Supported** | No |

*¹ - CyberArk Conjur is integrated into this workflow to securely manage sensitive information such as API keys, credentials, and environment variables. Secrets can be fetched dynamically during workflow execution, ensuring compliance and security. **Using Conjur is optional**—you may supply the same values via GitHub environment secrets instead.

---

## Reusable Workflow Upgrade Guide

It is considered a best practice to keep your caller/application workflows updated to reference the latest stable version of the reusable workflow. Doing so ensures you benefit from the newest features, security patches, enhancements, and bug fixes provided in this reusable workflow.
For detailed upgrade paths, refer to the table below.

N/A

---

## Mock Caller Repositories

A mock workflow, shown below, provides a solid starting point for implementing this reusable workflow to support secret configuration in AWS Secret Manager. Refer to the table below for the list of available caller workflows.

| Mock Repository URL | Purpose | Technology Stack |
|------------------|-------------|----------|
| [**mock-aws-secrets**](https://github.com/BHGitOps/mock-aws-secrets) | Provides a reference implementation for configuring secrets in AWS Secret Manager using this reusable workflow | AWS Secret Manager |

---

## Key Features & Capabilities

- **Upload GitHub Secrets to AWS Secrets Manager** – Sync secrets from GitHub environment to AWS Secrets Manager
- **Fetch and Upload Conjur Secrets** – Retrieve secrets from CyberArk Conjur and store them in AWS Secrets Manager
- **Create or Update with KMS Encryption** – Create or update secrets with optional Bring Your Own Key (BYOK) encryption
- **Delete Secrets with Recovery Window** – Delete secrets with configurable recovery window for reversibility
- **Secure OIDC Authentication** – Use OIDC for secure authentication without long-lived credentials
- **Flexible Runner Support** – Deploy on GitHub-hosted or self-hosted runners
- **Automatic Workspace Cleanup** – Clean up runner workspace after execution

> [!TIP]
> It's recommended to begin with GitHub Secrets for an easy understanding of the inputs.

> [!NOTE]
> Conjur is the primary source of truth for secrets. As we transition from GitHub Secrets to Conjur Secrets, our reusable workflows have been intelligently designed to support both secret sources. Application teams are strongly encouraged to use Conjur as their secret provider moving forward.
Use the parameter conjur-variable-json to fetch secrets from Conjur, and use the parameter secrets-json to retrieve secrets from GitHub environment secrets. Please refer to our mock example, which clearly demonstrates both scenarios.

---

## Prerequisites

> [!IMPORTANT]
> Before using this reusable workflow to configure the secrets in AWS Secret Manager, ensure the following prerequisites are met for the AWS account.
> Please coordinate with the IAC team to obtain all required infrastructure details before attempting to use our reusable workflow, as the infrastructure setup must always be completed first.

- An active AWS account and region
- Required secrets configured in GitHub environment variables or CyberArk Conjur
- OIDC trust relationship configured between GitHub and AWS (GitHub → AWS IAM OIDC provider)
- IAM role with permissions to manage AWS Secrets Manager secrets
- Account ID, OIDC assume role ARN, and role session name
- (Optional) Conjur workload ID and API key if using Conjur as the secret source

---
 
## Usage
#### Example: Upload GitHub Secrets to AWS Secrets Manager

```yaml
jobs:
  configure-secrets:
    uses: BHGitOps/workflow-aws-secrets-manager/.github/workflows/workflow.yml@v3
    with:
      aws-region: 'us-west-2'
      deploy-environment: 'dev'
      deploy-runner-type: 'ubuntu-latest'
      secret-name: 'my-app-secrets'
      secret-operation: 'gh-to-secret-manager'
      oidc-assume-role: 'arn:aws:iam::123456789012:role/GitHubActionsRole'
      role-session-name: 'github-actions'
    secrets:
      secrets-json: |
        {
          "DB_USER": "${{ secrets.DB_USER }}",
          "DB_PASSWORD": "${{ secrets.DB_PASSWORD }}"
        }
```

#### Example: Fetch Conjur Secrets and Upload to AWS Secrets Manager

```yaml
jobs:
  configure-secrets:
    uses: BHGitOps/workflow-aws-secrets-manager/.github/workflows/workflow.yml@v3
    with:
      aws-region: 'us-west-2'
      deploy-environment: 'dev'
      deploy-runner-type: 'ubuntu-latest'
      secret-name: 'my-app-secrets'
      secret-operation: 'conjur-to-secret-manager'
      conjur-variable-json: |
        {
          "CApp_DSO_Dev": {
            "my-app-secrets": "my-app-secrets"
          }
        }
      oidc-assume-role: 'arn:aws:iam::123456789012:role/GitHubActionsRole'
      role-session-name: 'github-actions'
    secrets:
      conjur-appliance-url: ${{ secrets.CONJUR_APPLIANCE_URL }}
      conjur-account: ${{ secrets.CONJUR_ACCOUNT }}
      conjur-workload-id: ${{ secrets.CONJUR_WORKLOAD_ID }}
      conjur-api-key: ${{ secrets.CONJUR_API_KEY }}
```

#### Example: Create Secret with KMS Encryption

```yaml
jobs:
  configure-secrets:
    uses: BHGitOps/workflow-aws-secrets-manager/.github/workflows/workflow.yml@v3
    with:
      aws-region: 'us-west-2'
      deploy-environment: 'prod'
      deploy-runner-type: 'ubuntu-latest'
      secret-name: 'my-encrypted-secrets'
      secret-operation: 'secret-with-kms'
      kms-key-id: 'arn:aws:kms:us-west-2:123456789012:key/12345678-1234-1234-1234-123456789012'
      oidc-assume-role: 'arn:aws:iam::123456789012:role/GitHubActionsRole'
      role-session-name: 'github-actions'
    secrets:
      secrets-json: |
        {
          "API_KEY": "${{ secrets.API_KEY }}"
        }
```

#### Example: Delete Secret with Recovery Window

```yaml
jobs:
  delete-secret:
    uses: BHGitOps/workflow-aws-secrets-manager/.github/workflows/workflow.yml@v3
    with:
      aws-region: 'us-west-2'
      deploy-environment: 'dev'
      deploy-runner-type: 'ubuntu-latest'
      secret-name: 'my-app-secrets'
      secret-operation: 'delete'
      secret-recovery-window: '7'
      oidc-assume-role: 'arn:aws:iam::123456789012:role/GitHubActionsRole'
      role-session-name: 'github-actions'
```
 
---
 
## Inputs
| Name | Description | Required | Type | Default |
|------------|-------------| :----------: |------|---------|
| `aws-region` | AWS region where the secret is managed | ✅ | `string` | - |
| `deploy-environment` | Deployment environment (`dev`, `qa`, `prod`) | ✅ | `string` | - |
| `deploy-runner-type` | GitHub Actions runner type | ✅ | `string` | - |
| `secret-name` | Unique name for the secret in AWS Secrets Manager | ✅ | `string` | - |
| `kms-key-id` | ARN or alias of KMS key for encryption | ❌ | `string` | - |
| `secret-operation` | Action to perform (`gh-to-secret-manager`, `conjur-to-secret-manager`, `secret-with-kms`, `delete`) | ✅ | `string` | - |
| `secret-recovery-window` | Recovery window (in days) for deletion | ❌ | `string` | - |
| `role-session-name` | Unique identifier for IAM role session | ❌ | `string` | - |
| `oidc-assume-role` | ARN of IAM role to assume using OIDC | ❌ | `string` | - |
| `conjur-variable-json` | Specify the secret in JSON format, mapping vaults/safe and secrets name to fetch the secrets from Conjur (required when `secret-operation` is `conjur-to-secret-manager`) | ❌ | string | - |

### Secret Operation Modes

The `secret-operation` input determines which action the workflow will perform:

- **`gh-to-secret-manager`** – Sync secrets from GitHub environment variables (via `secrets-json`) to AWS Secrets Manager. Use this when secrets are stored in GitHub environment secrets.

- **`conjur-to-secret-manager`** – Fetch secrets from CyberArk Conjur (using `conjur-variable-json`) and store them in AWS Secrets Manager. Requires Conjur credentials.

- **`secret-with-kms`** – Create or update a secret in AWS Secrets Manager with optional Bring Your Own Key (BYOK) encryption. Use the `kms-key-id` input to specify the KMS key for encryption.

- **`delete`** – Delete the specified secret from AWS Secrets Manager. Use `secret-recovery-window` to specify a recovery period (in days) before permanent deletion.

#### Example: Conjur Variable JSON Structure

```json
{
  "CApp_DSO_Dev": {
    "dso-aws-secrets-manager-conjur": "dso-aws-secrets-manager-conjur"
  }
}
```

The structure maps Conjur safe names (e.g., `CApp_DSO_Dev`) to secret names within those safes. The key-value pairs represent Conjur variable paths.

---
 
## Secrets
| Name | Description | Required | Type | Default |
|------|-------------| :----------: |------|---------|
| `conjur-appliance-url` | CyberArk Conjur Appliance URL. The default value is vars.CONJUR_APPLIANCE_URL, which should be specified in the application caller workflow | ❌*¹ | string | vars.CONJUR_APPLIANCE_URL |
| `conjur-account` | CyberArk Conjur Account. The default value is vars.CONJUR_ACCOUNT, which should be specified in the application caller workflow | ❌*¹ | string | vars.CONJUR_ACCOUNT |
| `conjur-workload-id` | Conjur workload ID for source environment (optional) | ❌*¹ | string |
| `conjur-api-key` | API key for source Conjur workload (optional) | ❌*¹ | string |
| `secrets-json` | GitHub environment secrets are provided in JSON format, which can be exported for JSON transformation or used to create a generic Kubernetes Secret | ❌*² | string |
| `github-token` | GitHub token used for authentication when accessing GitHub Packages | ❌ | string |

*¹ - The Conjur credentials are required to fetch the specified secrets in conjur-variable-json from Conjur. If this applies to your application, the Conjur workload ID and Conjur API key—specific to your application’s safe—must be provided by your application team. These credentials can be obtained by contacting the Conjur team.
Refer to the reference documentation section listed below for more details.

*² - Required when `secret-operation` is `gh-to-secret-manager` or `secret-with-kms`

> [!CAUTION]
> It is the responsibility of the application team to securely manage all secrets, whether stored in Conjur or GitHub Secrets. Secrets must never be logged, exposed, or configured in a way that could cause them to appear in application logs.
If a secret is suspected to be leaked or compromised in any way, it must be reported immediately and rotated without delay.

---
 
## Jobs & Steps
- Checkout Code ➡️→ Upload GitHub Secrets to AWS Secrets Manager (if 'gh-to-secret-manager') ➡️→ Conjur Secrets to AWS Secret Manager (if 'conjur-to-secret-manager') ➡️→ Create or Update Secret with KMS (if 'secret-with-kms') ➡️→ Delete Secret from AWS Secrets Manager (if 'delete') ➡️→ Clean Up Runner workspace.
    
### **aws-secrets** 🛠️
The `aws-secrets` job authenticates to AWS, retrieves secrets from GitHub and/or Conjur, and then creates, updates, encrypts (optionally with BYOK), or deletes secrets in AWS Secrets Manager according to the selected workflow inputs.

| Action Name | Purpose |
|-------------|---------|
| [**action-conjur-fetch-secrets**](https://github.com/BHGitOps/action-conjur-fetch-secrets) | Securely fetch secrets from CyberArk Conjur using API key authentication |
| [**action-configure-aws-credentials**](https://github.com/BHGitOps/action-configure-aws-credentials) | Configure AWS CLI with credentials and assume the specified IAM role |
| [**action-aws-secret-upload**](https://github.com/BHGitOps/action-aws-secret-upload) | Fetch secrets from GitHub and add them to AWS Secrets Manager |
| [**action-conjur-aws-secret-manager**](https://github.com/BHGitOps/action-conjur-aws-secret-manager) | Composite action to use secrets retrieved from Conjur and add them to AWS Secrets Manager |
| [**action-aws-secrets-manager-byok**](https://github.com/BHGitOps/action-aws-secrets-manager-byok) | Composite action to create secrets and implement Bring Your Own Key (BYOK) for encrypting AWS Secrets Manager if opted |
| [**action-aws-secret-delete**](https://github.com/BHGitOps/action-aws-secret-delete) | Composite GitHub Action to delete a secret from AWS Secrets Manager, with optional recovery window |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Safely delete all files in the current workspace to free up space after a job |

---

## Changelog 📝

| Version | Date       | Tags                                                                 | Changes |
|:--------:|:------------|----------------------------------------------------------------------|---------|
| **v3**  | 2026-01-22 | CyberArk Conjur integration, enhanced security | - **Added:** Source/Target EKS support<br>- **Added:** Conjur secret retrieval for fetching secrets |
| **v2**  | 2025-10-31 | Multi-environment deployment, artifact improvements | - **Changed:**  Updated GitHub Secrets to AWS Secret Manager step to use BHGitOps/action-aws-secret-upload@v2 for improved handling of JSON secret<br>- **Changed:** Updated 'secret-operation' input values to 'gh-to-secret-manager', 'conjur-to-secret-manager', 'secret-with-kms' or 'delete'  <br>- **Changed:** Updated Create or Update Secret step to use BHGitOps/action-aws-secrets-manager-byok@v2 for better KMS integration<br>- **Removed:**  secret-keys input<br>- **Improved:** OIDC role handling moved from secrets to inputs for better flexibility |
| **v1**  | 2025-06-11 | Initial Release | - **Added:** Support for upload, create, and delete operations<br>- **Added:** OIDC-based authentication for secure AWS access<br>- **Added:** Automatic cleanup of runner workspace |

---
## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflow</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>
  
  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1412694042/workflow-aws-secrets-manager">Workflow-aws-secrets-manager</a>
    </strong>
    <p>
      Workflow-aws-secrets-manager - Reusable GitHub workflow configuring secrets in AWS Secret Manager.
    </p>
  </article>

---

## Feedback/Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
