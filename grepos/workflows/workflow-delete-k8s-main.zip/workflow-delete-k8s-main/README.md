<h1 align="center">workflow-delete-k8s</h1>

## Overview
This repository provides a reusable GitHub workflow for deleting **Kubernetes resources** from an **Amazon EKS** cluster.  
It supports deletion of Kubernetes **Services**, **Deployments**, **Namespaces**, **Endpoints**, **ConfigMaps**, and **Secrets**, using secure AWS OIDC authentication.

The workflow automates cleanup operations for app teardown, environment refresh, or CI/CD resource management.

---

## Getting Started
These documents will help you get up to speed with our engineering practices and tools:

- [Overview](#overview)
- [Reusable Workflow Summary](#reusable-workflow-summary)
- [Mock Caller Repositories](#mock-caller-repositories)
- [Key Features & Capabilities](#key-features--capabilities)
---

## Reusable Workflow Summary

| Workflow Name | workflow-delete-k8s |
|-----------------|---------------------|
| **Latest Stable Version** | v1 |
| **Current Version** | v1 |
| **Cloud Environment** | AWS |
| **Cloud Services** | EKS (Kubernetes) |
| **TechStacks** | Kubernetes, AWS |
| **Is Conjur integrated** | No |

---

## Mock Caller Repositories

A mock workflow is available that demonstrates how to delete Kubernetes resources using this reusable workflow.

| Mock Repository URL | Purpose | Technology Stack |
|----------------------|----------|------------------|
| [**mock-k8s-crud**](https://github.com/BHGitOps/mock-k8s-crud) | Demonstrates deletion of K8s resources using this workflow | Kubernetes |

---

## Key Features & Capabilities
* Delete a wide range of Kubernetes resources:
  - Services  
  - Deployments  
  - Namespaces  
  - Endpoints  
  - ConfigMaps (entire or key‑level)  
  - Secrets (entire or key‑level)
* Secure authentication using **AWS IAM OIDC** (no long-lived credentials).
* Conditional deletion logic based on `delete-type`.
* Clean runner workspace at the end of every run.
* Fully compatible with GitHub-hosted and self-hosted runners.

> [!TIP]  
> Validate the resource name and namespace before executing a deletion job to avoid accidental removal of shared resources.

> [!NOTE]  
> This workflow is suitable for teardown stages, cleanup pipelines, or removing stale resources after environment promotions.

---

## Prerequisites

- An operational **Amazon EKS cluster**.
- IAM role configured for **GitHub → AWS OIDC** authentication.
- Sufficient permissions to delete Kubernetes resources via IAM Role.
- Namespace and resource names must exist before deletion.

> [!IMPORTANT]  
> Ensure your assumed IAM role has Kubernetes RBAC permissions mapped via the `aws-auth` ConfigMap in the `kube-system` namespace. Contact the EKS/IaC team if unsure.

---

## Usage

### Example: Delete a Kubernetes Service

```yaml
uses: BHGitOps/workflow-delete-k8s/.github/workflows/workflow.yml@v1
with:
  deploy-environment: "dev"
  deploy-runner-type: "ubuntu-latest"
  aws-region: "us-west-2"
  role-session-name: "delete-session"
  oidc-assume-role: "arn:aws:iam::123456789012:role/GitHubOIDCRole"
  cluster-name: "eks-dev"
  namespace: "default"
  delete-type: "k8s-service"
  k8s-service-name: "my-service"
secrets:
  secrets-json: ${{ secrets.SECRETS_JSON }}
```

---

## Inputs

| Name | Description | Required | Type | Default |
|------|-------------|----------|-------|---------|
| `deploy-environment` | Target deployment environment | ✅ | string | - |
| `deploy-runner-type` | GitHub runner where the delete job runs | ✅ | string | ubuntu-latest |
| `aws-region` | AWS region of the EKS cluster | ✅ | string | - |
| `role-session-name` | Session name when assuming IAM role | ✅ | string | - |
| `oidc-assume-role` | IAM role ARN for OIDC authentication | ✅ | string | - |
| `cluster-name` | Name of the EKS cluster | ✅ | string | - |
| `namespace` | Kubernetes namespace containing the resource | ✅ | string | - |
| `delete-type` | Kubernetes resource type to delete (`k8s-service`, `k8s-deployment`, `k8s-namespace`, `k8s-endpoint`, `k8s-configmap`, `k8s-secret`) | ✅ | string | - |
| `k8s-service-name` | Kubernetes Service name | ❌ | string | - |
| `k8s-deployment-name` | Kubernetes Deployment name | ❌ | string | - |
| `k8s-endpoint-name` | Kubernetes Endpoints resource name | ❌ | string | - |
| `configmap-name` | ConfigMap name | ❌ | string | - |
| `configmap-key-name` | Optional: key in ConfigMap to delete | ❌ | string | - |
| `secret-name` | Secret name | ❌ | string | - |
| `secret-keys` | Optional: keys in Secret to delete | ❌ | string | - |

---

## Secrets

| Name | Description | Required | Type |
|------|-------------|----------|-------|
| `secrets-json` | JSON object containing additional values for configuration | ❌ | string |

> [!CAUTION]  
> Never print secrets in GitHub Actions logs. If any secret leak is suspected, rotate the secret immediately and notify your security team.

---

## Jobs & Steps

Below are the individual actions performed by this workflow.

### Delete Kubernetes Resources 🛠️

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checks out the repository to load configuration files |
| [**action-configure-aws-credentials**](https://github.com/BHGitOps/action-configure-aws-credentials) | Configures AWS credentials using OIDC to assume IAM role |
| [**action-install-aws-cli**](https://github.com/BHGitOps/action-install-aws-cli) | Installs AWS CLI |
| [**action-install-kubectl**](https://github.com/BHGitOps/action-install-kubectl) | Installs kubectl client |
| [**action-authenticate-eks**](https://github.com/BHGitOps/action-authenticate-eks) | Authenticates to the EKS cluster |
| [**action-delete-k8s-service**](https://github.com/BHGitOps/action-delete-k8s-service) | Deletes a Kubernetes Service |
| [**action-delete-k8s-deployment**](https://github.com/BHGitOps/action-delete-k8s-deployment) | Deletes a Kubernetes Deployment |
| [**action-delete-k8s-namespace**](https://github.com/BHGitOps/action-delete-k8s-namespace) | Deletes an entire Kubernetes namespace |
| [**action-delete-k8s-endpoint**](https://github.com/BHGitOps/action-delete-k8s-endpoint) | Deletes a Kubernetes Endpoints resource |
| [**action-delete-k8s-configmaps**](https://github.com/BHGitOps/action-delete-k8s-configmaps) | Deletes a ConfigMap or a specific key |
| [**action-delete-k8s-secrets**](https://github.com/BHGitOps/action-delete-k8s-secrets) | Deletes a Secret or selected keys |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Cleans the runner workspace |

---

## Changelog 📝

| Version | Date       | Tags               | Changes |
|:--------:|:------------|---------------------|---------|
| **v1**  | 2025-11-27 | Initial Release     | - **Added:** Delete K8s resources (Service, Deployment, Namespace, Endpoint, ConfigMap, Secret)<br>- **Added:** Secure AWS OIDC authentication<br>- **Added:** Automatic runner cleanup |

---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>
  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1578008971/workflow-delete-k8s+Reusable+Workflow+to+support+deletion+of+K8s+resources+in-progress">Workflow-delete-k8sᵈ²</a>
    </strong>
    <p>
      Workflow-delete-k8s - Detailed documentation for deleting Kubernetes resources across Amazon EKS cluster
    </p>
  </article>  

---

## Feedback / Need Help? 📬  
If you have any questions or need assistance, don’t hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
