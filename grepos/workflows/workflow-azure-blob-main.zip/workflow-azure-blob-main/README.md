<h1 align="center">
  <a href=".github/workflows/workflow.yml">workflow-azure-blob</a>
</h1>

## Overview
This repository contains a **reusable GitHub Actions workflow** for performing **Azure Blob Storage operations**. It supports uploading, downloading, copying, deleting, and listing blobs or directories in Azure Storage containers. The workflow also includes optional artifact upload for downloaded content and comprehensive filtering and sorting capabilities. It supports **Service Principal (OIDC)** and **SAS Token–based** authentication.

---

## Getting Started

These documents will help you get up to speed with our engineering practices and tools.

## Reusable Workflow Summary

The table outlines the essential details of the reusable Azure Blob Storage workflow, including its name, current stable version, supported cloud environment and services.

| Workflow Name | workflow-azure-blob |
| :------| :-------------|
| **Latest Stable Version** | [**v2**](https://github.com/BHGitOps/workflow-azure-blob/blob/v2/README.md) |
| **Current Version** | [**v2**](https://github.com/BHGitOps/workflow-azure-blob/blob/v2/README.md) |
| **Cloud Environment** | Azure |
| **Cloud Services** | Blob storage |
| **TechStacks** | Any |
| **Is Conjur integrated** | No |
| **Supported Operations** | Upload, Batch Upload, Copy, Download, Delete, List |
| **Authentication Method** | Azure Service Principal, SAS Token |
| **Runner Compatibility** | GitHub-hosted and self-hosted runners |

---

## Mock Caller Repositories

A mock workflow, shown below, provides a solid starting point for implementing this reusable workflow to upload/copy/delete the files/directories to Azure Blob storage. Refer to the table below for the list of available caller workflows.

| Mock Repository URL | Purpose | Technology Stack |
|---------------------|----------|------------------|
| [**mock-azure-blob-crud**](https://github.com/BHGitOps/mock-azure-blob-crud) | Demonstrates upload, copy, download, and delete operations using this workflow | Any |

---

## Key Features & Capabilities

* Upload files or directories to Azure Blob Storage (with batch upload support.)
* Copy files or directories between Azure Blob Storage accounts.
* Delete files or directories from Azure Blob Storage
* Download files, folders, or entire containers from Azure Blob Storage
* List contents of Azure Blob Storage containers with sorting and filtering options
* Secure authentication using **Azure Service Principal** or **SAS Token**
* Optional artifact upload for downloaded content
* Support for multiple runner types (self-hosted, ubuntu-latest, etc.)
* Environment-specific deployments (dev, qa, prod)

---

## Prerequisites

> [!IMPORTANT]
> Before using this reusable workflow to copy/upload/delete the files/directories to Azure Blob Storage, ensure the following prerequisites are met.
> Please coordinate with the IAC team to obtain all required infrastructure details before attempting to use our reusable workflow, as the infrastructure setup must always be completed first.

- An active Azure storage account
- Managed Identity should be created or already available
- Managed Identity must have necessary permissions to access the storage account
- client-id, tenant-id and subscription-id should be configured as secrets in GitHub

--- 

## **Usage**
### **Current Version: v1**
#### **Example: Upload a Directory to Azure Blob Storage**
```yaml
uses: BHGitOps/workflow-azure-blob/.github/workflows/workflow.yml@v2
with:
  deploy-environment: "dev"
  ...
secrets:
  client-id: ${{ secrets.CLIENT_ID }}
  tenant-id: ${{ secrets.TENANT_ID }}
  subscription-id: ${{ secrets.SUBSCRIPTION_ID }}
```

---

## Inputs
| Name | Description | Required | Type | Default |
|------------|-------------| :----------: |------|---------|
| `deploy-runner-type` | Runner where the deployment job gets executed | ✅ | string | [**Refer GitHub Reusable Workflowᵈ¹**](#resources) |
| `deploy-environment` | Environment name (dev, qa, prod) | ✅ | string | - |
| `source-storage-account` | Source Azure Storage Account | ✅ | string | - |
| `download-type` | Determines download mode: `file`, `folder`, or `container` | ✅ | string | - |
| `blob-name`  | Name of blob to download | ✅  | string | - |
| `file-name`   | Local filename after download   | ❌ | string | - |
| `download-folder-name` | Folder where downloaded content will be stored  | ✅  | string | blobdownload |
| `folder-prefix` | Folder prefix for folder downloads   | ✅ | string | - |
| `destination-storage-account` | Destination Storage Account (copy workflows only) | ❌ | string | - |
| `source-container-name` | Blob container to read from | ✅ | string | - |
| `destination-container-name` | Blob container to write to | ❌ | string | - |
| `blob-operation-mode` | `upload`, `copy`, `delete`, `download`, `batch-upload`, or `list` | ✅ | string | - |
| `source-path` | Path of file/directory inside the container | ❌ | string | - |
| `destination-directory-name` | Target directory (copy directory) | ❌ | string | - |
| `destination-blob-name` | Target file path (copy file) | ❌ | string | - |
| `target-directory-name` | Directory to delete | ❌ | string | - |
| `target-file-name` | File to delete | ❌ | string | - |
| `file-prefix`  | Filter blobs by prefix when listing   | ❌ | string | - |
| `sort-by`  | Sorting field: `creationTime` or `lastModified` | ❌ | string | lastModified |
| `upload-artifact`  | Upload the downloaded file, folder, or container to artifacts | ❌ | boolean | true |
| `sort-order` | Sorting order: `asc` or `desc`  | ❌ | string | desc |
| `top-n`   | Number of top items to list   | ❌ | string | - |
| `delete-destination`   | Delete blobs in the destination that do not exist in the source  | ❌ | boolean | false |
| `compare-hash-md5`   | Add --compare-hash=MD5 to azcopy sync   | ❌ | boolean | false |

---

## Secrets
| Name | Description | Required | Type | Default |
|------|-------------| :----------: |------|---------|
| `client-id` | Client ID of the Azure Service Principal used for authentication | ❌*¹ | string | - |
| `tenant-id` | Azure Active Directory Tenant ID associated with the Service Principal | ❌*¹ | string | - |
| `subscription-id` | Azure Subscription ID under which the authentication and resource access occur | ❌*¹ | string | - |
| `sas-token` | Shared Access Signature token for secure access | ❌ | string | - |

*¹ - These authentication parameters (client-id, tenant-id, and subscription-id) are used to log into Azure through a Service Principal. Once authenticated, the system uses this identity to securely access Azure resources. This ensures that all interactions with Azure resources follow role‑based access controls and comply with your subscription’s security policies. 


> [!CAUTION]
> It is the responsibility of the application team to securely manage all secrets, whether stored in Conjur or GitHub Secrets. Secrets must never be logged, exposed, or configured in a way that could cause them to appear in application logs.
If a secret is suspected to be leaked or compromised in any way, it must be reported immediately and rotated without delay.

---

## **Jobs & Steps**
### **Azure Blob Operation**
Runs on specified runner type in the specified environment.

**Steps:**
1. **Checkout repository** - Retrieves the repository code using BHGitOps/action-checkout@v1
2. **Azure Login** - Authenticates to Azure using Service Principal credentials via BHGitOps/action-azlogin@v1
3. **Upload file or directory to Azure Blob Storage** - Executes when `blob-operation-mode` is `upload` or `batch-upload`
   - Uses BHGitOps/action-azure-upload-to-blob@v1
4. **Copy file or directory from Azure Blob to Azure Blob Storage** - Executes when `blob-operation-mode` is `copy`
   - Uses BHGitOps/action-azure-blob-copy@v2
5. **Delete file or directory from Azure Blob Storage** - Executes when `blob-operation-mode` is `delete`
   - Uses BHGitOps/action-azure-blob-delete@v1
6. **Downloads files, folders, or containers from Azure Blob Storage** - Executes when `blob-operation-mode` is `download`
   - Uses BHGitOps/action-azure-blob-download@v1
   - Optionally uploads to GitHub Artifacts
7. **List Storage Container Contents** - Executes when `blob-operation-mode` is `list`
   - Uses BHGitOps/action-azure-list-storage-blob@v1
   - Supports sorting and filtering options
8. **Clean Up Runner workspace** - Cleanup step that always runs (success or failure)
   - Uses BHGitOps/action-clean-runner-artifacts@v1
This Blob job performs Azure Blob Storage operations such as upload, download, batch-upload, copy, delete, and list based on the selected blob-operation-mode.

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checkout repository (optionally with Super Linter) |
| [**action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Logs into Azure and optionally authorizes NuGet when using Azure Artifacts |
| [**action-azure-upload-to-blob**](https://github.com/BHGitOps/action-azure-upload-to-blob) | Upload to Azure Blob Storage |
| [**action-azure-blob-copy**](https://github.com/BHGitOps/action-azure-blob-copy) | Copy blobs between Azure Storage accounts, containers, or paths |
| [**action-azure-blob-delete**](https://github.com/BHGitOps/action-azure-blob-delete) | Delete from Azure Blob Storage |
| [**action-azure-blob-download**](https://github.com/BHGitOps/action-azure-blob-download) | Download File, Folder or Container from Azure Blob Storage |
| [**action-azure-list-storage-blob**](https://github.com/BHGitOps/action-azure-list-storage-blob) | List Azure blobs by date with top-n (>=1) |

---

## **Example Scenarios**
- **Upload a directory** to Azure Blob Storage with a destination directory name
- **Batch upload** multiple files to Azure Blob Storage
- **Copy files** between two Azure Blob Storage accounts with optional destination cleanup
- **Delete a file** or directory from Azure Blob Storage
- **Download a container** and upload it as an artifact for backup
- **List top N blobs** sorted by last modified date in descending order
- **Filter blobs** by file prefix within a folder and download matching files

---

## **Authentication Methods**
The workflow supports two authentication approaches:

1. **Azure Service Principal** (recommended for CI/CD)
   - Requires: `client-id`, `tenant-id`, `subscription-id`
   - Uses Azure RBAC for fine-grained access control

2. **SAS Token** (recommended for specific container/blob access)
   - Requires: `sas-token`
   - Provides time-limited, scoped access to storage resources
   - Can be used in conjunction with Service Principal authentication

---

## Changelog 📝

| Version | Date       | Tags                                                                 | Changes |
|:--------:|:------------|----------------------------------------------------------------------|---------|
| **v2**  | 2026-01-20 | Azcopy sync support has been added | - **Added:** Added support azcopy sync command <br>- **Added:** Added support for batch-upload |
| **v1**  | 2025-10-31 | Initial Release                    | - **Added:** Support for upload, copy, delete, download, and list operations for Azure Blob Storage 

---

<h2 id="Resources">Resources 📚</h2>

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1578041345/workflow-azure-blob+Reusable+CI+CD+Workflow+for+Azure+Blob+Storage+Operations">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>

---

## Feedback/Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
