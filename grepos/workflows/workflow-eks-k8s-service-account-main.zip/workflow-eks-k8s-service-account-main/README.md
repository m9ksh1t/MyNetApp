<h1 align="center">workflow-eks-k8s-service-account</h1>

## **Overview**
This repository provides a reusable GitHub workflow for creating Kubernetes Service Accounts in EKS (Amazon Elastic Kubernetes Service). It supports secure authentication and provisioning of service accounts with associated IAM roles.



## Getting Started

These documents will help you get up to speed with our engineering practices and tools.

## Reusable Workflow Summary

The table outlines the essential details of the reusable EKS k8s service account workflow, including its name, current stable version, supported cloud environment and services.

| • Workflow Name | workflow-eks-k8s-service-account |
| :------| :-------------|
| • **Latest Stable Version** | v1 |
| • **Current Version** | v1 |
| • **Cloud Environment** | AWS |
| • **Cloud Services** | EKS |
| • **TechStacks** | NA |
| • **Is Conjur integrated** | NA |

---

## Mock Caller Repositories

A mock workflow, shown below, provides a solid starting point for implementing this reusable workflow to support k8s service account creation in AWS Environments. Refer to the table below for the list of available caller workflow.

| Mock Repository | Purpose | Repository URL | Technology Stack |
|------------------|-------------|----------|------|
| **mock-k8s-crud** | Provides a reference implementation for creating k8s service account in EKS using this reusable workflow | https://github.com/BHGitOps/mock-k8s-crud| NA |

---

## Key Features & Capabilities
* Create Kubernetes Service Accounts in EKS clusters.
* Associate IAM roles for EKS.
* Secure authentication using OIDC for AWS.
* Supports namespace and custom service account names.



> [!TIP]
> It’s recommended to start by creating a basic service account with minimal permissions. Kubernetes workflows fully support operating with a least‑privilege service account, and you can extend its permissions or integrate it with cloud‑specific identities (like AWS IRSA) later when the application requires broader access.

---

## Prerequisites



> [!IMPORTANT]
> Before using this reusable workflow to create K8s service account in AWS Elastic Kubernetes Service (EKS), ensure the following prerequisites are met in EKS accounts.
> Please coordinate with the IAC team to obtain all required infrastructure details before attempting to use our reusable workflow, as the infrastructure setup must always be completed first.

- An active AWS cluster, cluster-name, region details required
- OIDC provider should be enabled for the EKS
- K8s namespace for service account creation
- Kubectl and AWS CLI access required
- Service Account, namespace and AWS IAM role details required
- GitHub → AWS IAM OIDC provider is configured

  
---
 
## Usage

#### Example: Create K8s service account in AWS EKS
```yaml
uses: BHGitOps/workflow-create-k8s-service-account/.github/workflows/workflow.yml@v1
    with:
      deploy-runner-type: ${{ fromJSON(needs.prepare-vars-for-environment.outputs.dev-vars-json).DEPLOY_RUNNER_TYPE }}
      deploy-environment: 'dev'
      target-cluster: 'eks'
      aws-region: 'us-west-2'                                  
      cluster-name: 'dso-sb-eks-cluster01'                         
      service-account-name: 'dso-test-service-account-test'    
      namespace: 'dso'
      role-session-name: ${{ vars.ROLE_SESSION_NAME_DEV }}
      oidc-assume-role: ${{ vars.OIDC_ASSUME_ROLE_DEV }}
      aws-account-id: ${{ vars.AWS_ACCOUNT_ID_DEV }}
      service-account-role: ${{ vars.SERVICE_ACCOUNT_ROLE_DEV }}
```

---
 
## Inputs
| Name | Description | Required | Type | Default |
|------|-------------| :----------: |------|---------|
| `deploy-runner-type` | Runner where the build job gets executed | ✅ | string | ubuntu-latest |
| `deploy-environment` | Deploy Environment | ✅ | string | - |
| `target-cluster` | Target cluster type where the service account will be created | ✅ | string | - |
| `aws-region` | AWS region where cluster is created | ❌ | string | us-west-2 |
| `role-session-name` | Unique identifier for the role session used for an IAM role | ❌ | string | - |
| `oidc-assume-role` | ARN of the IAM role to assume using OIDC, granting the workflow temporary access to its permissions associated with that IAM role | ❌ | string | - |
| `aws-account-id` | AWS Account ID where resources will be accessed or deployed | ❌ | string | - |
| `service-account-role` | IAM role ARN to associate with the Kubernetes service account in EKS | ❌ | string | - |
| `namespace` | Kubernetes namespace where the service account will be created | ❌ | string | - |
| `service-account-name` | Name of the Kubernetes service account to be created | ❌ | string | - |
| `container-registry` | Name of the container registry used for deployments | ❌ | string | - |
| `cluster-name` | Name of the kubernetes cluster | ❌ | string | - |

---

---
 
## Jobs & Steps
- Codecheckout → Configure AWS Credentials → Install AWS CLI → Install kubectl → Authenticate EKS cluster → Create k8s service account.
    
### **Create-service-account-eks** ☸️
This job does handle checks out the repository code, configures AWS credentials, installs the AWS CLI and kubectl, authenticates to the Amazon EKS cluster, creates a Kubernetes service account within the cluster, and finally cleans up temporary runner artifacts generated during the job.

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checkout repository (optionally with Super Linter). |
| [**action-configure-aws-credentials**](https://github.com/BHGitOps/action-configure-aws-credentials) | Configures AWS CLI with credentials and assumes the specified IAM role using OIDC. |
| [**action-install-aws-cli**](https://github.com/BHGitOps/action-install-aws-cli) | Downloads and installs the AWS CLI to manage AWS services. |
| [**action-install-kubectl**](https://github.com/BHGitOps/action-install-kubectl) | Downloads and install kubectl needed for k8s service account creation. |
| [**action-authenticate-eks**](https://github.com/BHGitOps/action-authenticate-eks) | Updates the kubeconfig to authenticate with an Amazon EKS cluster to execute K8s commands. |
| [**action-create-k8s-service-account**](https://github.com/BHGitOps/action-create-k8s-service-account) | Creates a Kubernetes Service Account in a specified namespace. |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Performs final cleanup of temporary files on the runner. |

---

## Changelog 📝

| Version | Date       | Tags                                                                 | Changes |
|:--------:|:------------|----------------------------------------------------------------------|---------|
| **v1**  | 2025-10-31 | Initial Release                                                       | - **Added:** Basic k8s service account creation workflow with AWS CLI Installation, kubectl setup and k8s account creation in AWS.|

---
## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>
  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1577320529/workflow-k8s-service-account+Reusable+Workflow+to+support+K8s+in-progress">workflow-create-k8s-service-accountᵈ²</a>
    </strong>
    <p>
      workflow-create-k8s-service-account - Reusable GitHub workflow to create k8s service accounts in AWS EKS.
    </p>
  </article>  

---

## Feedback/Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
