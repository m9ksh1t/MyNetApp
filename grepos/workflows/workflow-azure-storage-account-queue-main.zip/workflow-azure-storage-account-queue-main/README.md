<h1 align="center">workflow-azure-storage-account-queue</h1>

## Overview
This repository provides a reusable GitHub workflow for managing **Azure Storage Account Queues**, including inserting/updating (upsert), deleting queues, or clearing existing queue contents.  
It authenticates using an **Azure Service Principal** and supports SAS token–based access when needed.

This workflow enables secure, automated, and environment-driven queue operations for distributed systems, event-driven microservices, and data ingestion pipelines.

---

## Getting Started
These documents will help you get up to speed with our engineering practices and tools.

## Reusable Workflow Summary

| Workflow Name | workflow-azure-storage-account-queue |
|-----------------|---------------------------------------|
| **Latest Stable Version** | v1 |
| **Current Version** | v1 |
| **Cloud Environment** | Azure |
| **Cloud Services** | Azure Storage Accounts (Queues) |
| **TechStacks** | Azure Queues |
| **Is Conjur integrated** | No |

---

## Mock Caller Repositories

Use the mock workflow linked below to understand how this reusable workflow is typically invoked.

| Mock Repository URL | Purpose | Technology Stack |
|----------------------|----------|------------------|
| [**mock-azure-storage-account**](https://github.com/BHGitOps/mock-azure-storage-account) | Demonstrates inserting, updating, clearing, and deleting Azure Queue messages | Azure Queues |

---

## Key Features & Capabilities
* Insert, update, or delete messages in Azure Storage Queues.
* Clear all messages before upserting (optional).
* Delete entire Azure Storage Queue.
* Load queue messages from a **JSON file** containing a `value` array.
* Authenticate securely using **Azure Service Principal** credentials.
* Supports optional **SAS token authentication** for direct queue access.
* Runs on GitHub-hosted or Azure self-hosted runners.

> [!TIP]  
> Store your queue message payloads in version-controlled JSON files (e.g., `configs/queue-messages.json`) to easily manage and promote changes across environments.

> [!NOTE]  
> SAS tokens should be used sparingly. Prefer Azure AD authentication through a Service Principal for better security and auditing.

---

## Prerequisites

- Azure Storage Account and associated Queue.
- Azure Service Principal with appropriate RBAC roles:
  - **Storage Queue Data Contributor** *(recommended)*
- If using SAS tokens:
  - Ensure the token grants the required permissions (`r`, `a`, `u`, etc.).
- JSON file must contain:
  ```json
  {
    "value": ["message1", "message2"]
  }
  ```

> [!IMPORTANT]  
> Ensure the Service Principal has access to the **correct subscription and resource group**.  
> If deleting queues, ensure that no other application currently depends on that queue.

---

## Usage

### Example: Upsert Messages into Azure Storage Queue

```yaml
uses: BHGitOps/workflow-azure-storage-account-queue/.github/workflows/workflow.yml@v1
with:
  deploy-runner-type: "azure"
  deploy-environment: "dev"
  azure-storage-account-name: "mystorageaccount"
  azure-storage-queue-name: "myqueue"
  json-file-path: "configs/myqueue.json"
  operation-type: "upsert"
  clear-queue: false
secrets:
  client-id: ${{ secrets.AZURE_CLIENT_ID }}
  tenant-id: ${{ secrets.AZURE_TENANT_ID }}
  subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}
  sas-token: ${{ secrets.SAS_TOKEN }}
```

### Example: Delete Azure Storage Queue
```yaml
uses: BHGitOps/workflow-azure-storage-account-queue/.github/workflows/workflow.yml@v1
with:
  deploy-runner-type: "azure"
  deploy-environment: "dev"
  azure-storage-account-name: "mystorageaccount"
  azure-storage-queue-name: "oldqueue"
  operation-type: "delete"
secrets:
  client-id: ${{ secrets.AZURE_CLIENT_ID }}
  tenant-id: ${{ secrets.AZURE_TENANT_ID }}
  subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}
  sas-token: ${{ secrets.SAS_TOKEN }}
```

---

## Inputs

| Name | Description | Required | Type | Default |
|------|-------------|----------|-------|---------|
| `deploy-runner-type` | Runner type to execute the queue operation | ✅ | string | azure |
| `deploy-environment` | Deployment environment (dev, staging, prod) | ✅ | string | - |
| `azure-storage-account-name` | Azure Storage Account name | ✅ | string | - |
| `azure-storage-queue-name` | Queue name inside the Storage Account | ✅ | string | - |
| `json-file-path` | Path to JSON file containing queue messages | ❌ | string | - |
| `operation-type` | Operation to perform (`upsert`, `delete`) | ✅ | string | - |
| `clear-queue` | Whether to clear the queue before upsert | ❌ | boolean | false |

---

## Secrets

| Name | Description | Required |
|------|-------------|----------|
| `client-id` | Azure Service Principal Client ID | ✅ |
| `tenant-id` | Azure Tenant ID | ✅ |
| `subscription-id` | Azure Subscription ID | ✅ |
| `sas-token` | SAS Token for direct queue access | ❌ |

> [!CAUTION]  
> SAS tokens should be rotated frequently and never printed in logs. Prefer Azure AD–based authentication whenever possible.

---

## Jobs & Steps

Below are the key steps performed by this workflow:

### Manage Azure Storage Queue ☁️

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Check out the repository to load JSON files |
| [**action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Authenticate to Azure via Service Principal |
| [**action-azure-install-cli**](https://github.com/BHGitOps/action-azure-install-cli) | Install Azure CLI for queue operations |
| [**action-azure-storage-account-queue**](https://github.com/BHGitOps/action-azure-storage-account-queue) | Inserts/updates queue messages from JSON file |
| [**action-delete-azure-storage-account-queue**](https://github.com/BHGitOps/action-delete-azure-storage-account-queue) | Deletes entire Azure Storage Queue |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Cleans GitHub runner workspace at the end |

---

## Changelog 📝

| Version | Date       | Tags                                               | Changes |
|:--------:|:------------|----------------------------------------------------|---------|
| **v1.1.0** | 2025-11-14 | Feature Update, Minor Breaking Change             | - **Added:** `operation-type` input with support for **`upsert`** and **`delete`** flows.<br>- **Added:** Ability to **delete** an Azure Storage Queue via `action-delete-azure-storage-account-queue@v1`.<br>- **Changed:** `json-file-path` made **optional** (required only for `upsert`).<br>- **Removed:** `azure-resource-group` input (no longer required by actions).<br>- **Improved:** Clearer job steps and conditional execution based on `operation-type`. |
| **v1.0.0** | 2025-11-03 | Initial Release                                   | - **Added:** Insert (upsert) **messages** into Azure Storage Queue using JSON `value` array.<br>- **Added:** Optional **clear queue** capability prior to insert.<br>- **Added:** Azure login and CLI setup; runner cleanup on completion. |

---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>

---

## Feedback / Need Help? 📬  
If you need help or have questions, feel free to contact your team lead or the Platform Engineering Support team. We're here to help you succeed!
