<h1 align="center">workflow-azure-keyvault-secret-injector</h1>

## Overview
This repository provides a reusable GitHub workflow to securely **fetch secrets from Azure Key Vault** and **export them as environment variables** for use in subsequent jobs.  
The workflow authenticates using an **Azure Service Principal**, supports loading secret names from a **JSON file**, and works across multiple environments.

---

## Getting Started
These documents will help you get up to speed with our engineering practices and tools.

---

## Reusable Workflow Summary

| Workflow Name | workflow-azure-keyvault-secret-injector |
|----------------|----------------------------------------|
| **Latest Stable Version** | v1 |
| **Current Version** | v1 |
| **Cloud Environment** | Azure |
| **Cloud Services** | Key Vault |
| **TechStacks** | Any (language/runtime agnostic) |
| **Is Conjur integrated** | No |

---

## Mock Caller Repositories

A mock workflow is available to help you implement and validate this reusable workflow.

| Mock Repository URL | Purpose | Technology Stack |
|---------------------|---------|------------------|
| [**mock-azure-keyvault**](https://github.com/BHGitOps/mock-azure-keyvault) | Demonstrates fetching Key Vault secrets and exporting them to env for downstream jobs | Any |

---

## Key Features & Capabilities
* Authenticate to Azure using **Service Principal** (OIDC- or secret-backed).
* Load a list of secret names from a **JSON file**.
* Fetch secrets from **Azure Key Vault** and export them to environment variables.
* Support **multi‑environment** usage (dev → test → prod).
* Run on **Azure** or **self-hosted** runners.

> [!TIP]  
> Keep your secret list in a versioned JSON file (e.g., `config/dev/secrets.json`) so you can reuse the same workflow across environments by just switching files.

> [!NOTE]  
> Secrets are exported for the **current job** and can be consumed by **subsequent steps**. If you need them in other jobs, pass them through **job outputs** or **environment files** securely.

---

## Prerequisites

- **Azure Key Vault** instance and required **access policies** (or RBAC) for the Service Principal.
- **Azure Service Principal** (Client ID, Tenant ID, Subscription ID) with permissions to read Key Vault secrets.
- A **JSON file** in your repository that contains an array of secret names (e.g., `["DB-PASSWORD","API-KEY"]`).

> [!IMPORTANT]  
> Ensure the Service Principal has **Get** permissions on secrets (Key Vault Access Policies) or equivalent **Key Vault Secrets User** role when using RBAC.

---

## Usage

### Example: Fetch and Export Secrets from Azure Key Vault

```yaml
uses: BHGitOps/workflow-azure-keyvault-secret-injector/.github/workflows/workflow.yml@v1
with:
  deploy-environment: "dev"
  deploy-runner-type: "azure"
  azure-resource-group: "my-resource-group"
  keyvault-name: "my-keyvault"
  secret-file: "config/dev/secrets.json"
secrets:
  client-id: ${{ secrets.AZURE_CLIENT_ID }}
  tenant-id: ${{ secrets.AZURE_TENANT_ID }}
  subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}
```

---

## Inputs

| Name | Description | Required | Type | Default |
|------|-------------|--------|------|---------|
| `deploy-environment` | Target environment (e.g., dev, test, prod) | ✅ | string | - |
| `deploy-runner-type` | Runner where the job executes | ✅ | string | azure |
| `azure-resource-group` | Azure Resource Group that contains the Key Vault | ❌ | string | - |
| `keyvault-name` | Azure Key Vault name to fetch secrets from | ❌ | string | - |
| `secret-file` | Relative path to a JSON file containing an **array of secret names** | ❌ | string | - |

---

## Secrets

| Name | Description | Required | Type |
|------|-------------|:--------:|------|
| `client-id` | Azure Service Principal Client ID | ✅ | string |
| `tenant-id` | Azure Tenant ID | ✅ | string |
| `subscription-id` | Azure Subscription ID | ✅ | string |

> [!CAUTION]  
> Store Azure credentials in **GitHub Secrets**. Do **not** echo or log secrets. If exposure is suspected, **rotate immediately**.

---

## Jobs & Steps

- Checkout ➡️ Azure Login ➡️ Load Secret List ➡️ Fetch & Export Secrets

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checks out the repository so the workflow can access the secret list file |
| [**action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Authenticates to Azure using the Service Principal |
| [**action-azure-keyvault-list-handler**](https://github.com/BHGitOps/action-azure-keyvault-list-handler) | Loads and validates the list of secret names from the JSON file |
| [**action-azure-keyvault-export-secrets**](https://github.com/BHGitOps/action-azure-keyvault-export-secrets) | Fetches secrets from Key Vault and exports them as environment variables |

---

## Changelog 📝

| Version | Date       | Tags            | Changes |
|--------|------------|----------------|---------|
| **v1**  | 2025-11-26 | Initial Release | - **Added:** Fetch secrets from Azure Key Vault and export as environment variables<br>- **Added:** Load secret names from JSON file<br>- **Added:** Azure Service Principal authentication |

---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>
  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1665007918/workflow-azure-keyvault-secret-injector+v1+-+Reusable+Workflow+to+Fetch+and+Export+Secrets+from+Key+Vault">workflow-azure-keyvault-secret-injectorᵈ²</a>
    </strong>
    <p>
      workflow-azure-keyvault-secret-injector - Detailed documentation for fetching and exporting Azure Key Vault secrets with GitHub Actions.
    </p>
  </article> 

---

## Feedback / Need Help? 📬  
If you have questions or need assistance, reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
