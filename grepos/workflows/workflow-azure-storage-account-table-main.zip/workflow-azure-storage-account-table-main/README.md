<h1 align="center">workflow-azure-storage-account-table</h1>

## Overview
This repository provides a reusable GitHub workflow for managing **Azure Storage Account Tables**, supporting **upsert (insert/update)** and **delete** operations for table entities.  
The workflow authenticates securely using an **Azure Service Principal**, installs Azure CLI, and operates on Azure Table Storage using JSON‑based entity definitions.

This enables teams to manage configuration data, seed environment-specific values, or clear tables during deployments in a consistent and automated manner.

---

## Getting Started
To start using this reusable workflow in your repository:

## Reusable Workflow Summary

| Workflow Name | workflow-azure-storage-account-table |
|-----------------|--------------------------------------|
| **Latest Stable Version** | v2 |
| **Current Version** | v2 |
| **Cloud Environment** | Azure |
| **Cloud Services** | Azure Storage (Table Storage) |
| **TechStacks** | Any |
| **Is Conjur integrated** | No |

---

## Mock Caller Repositories

A mock workflow is available to demonstrate usage of this reusable workflow.

| Mock Repository URL | Purpose | Technology Stack |
|----------------------|----------|------------------|
| [**mock-azure-storage-account**](https://github.com/BHGitOps/mock-azure-storage-account) | Demonstrates insert, update, and delete operations on Azure Table Storage | Any |

---

## Key Features & Capabilities
* Upsert entities (insert or update) in Azure Table Storage using JSON files.
* Delete all entities from an Azure Storage Table.
* Authenticate securely using Azure Service Principal credentials.
* Optionally use SAS tokens for direct data-plane access.
* Works with GitHub-hosted or Azure-hosted runners.
* Designed for multi-environment pipelines (dev → qa → prod).

> [!TIP]  
> Keep your table entity payloads in version-controlled JSON (e.g., `configs/table-entities.json`) for easy environment promotions.

> [!NOTE]  
> SAS tokens should only be used when absolutely required. Prefer Azure AD authentication through a Service Principal for security and auditability.

---

## Prerequisites

- Azure Storage Account with Table Storage enabled.
- Azure Storage Table created before workflow runs.
- Azure Service Principal with proper RBAC permissions:
  - **Storage Table Data Contributor** *(recommended)*.
- JSON file with table entities structured as an array of objects.

> [!IMPORTANT]  
> Ensure the Service Principal has the required access to the Azure Storage Account and resource group. Contact the Cloud/IaC team if you’re unsure.

---

## Usage

### Example: Upsert Azure Storage Table Entities

```yaml
uses: BHGitOps/workflow-azure-storage-account-table/.github/workflows/workflow.yml@v2
with:
  deploy-runner-type: "azure"
  deploy-environment: "dev"
  azure-storage-account-name: "dsostorage"
  azure-storage-table-name: "mytable"
  json-file-path: "configs/upsert-entities.json"
  azure-resource-group: "rg-dso-dev"
  operation-type: "upsert"
secrets:
  client-id: ${{ secrets.AZURE_CLIENT_ID }}
  tenant-id: ${{ secrets.AZURE_TENANT_ID }}
  subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}
  sas-token: ${{ secrets.SAS_TOKEN }}
```

### Example: Delete All Entities From Azure Storage Table

```yaml
uses: BHGitOps/workflow-azure-storage-account-table/.github/workflows/workflow.yml@v2
with:
  deploy-runner-type: "azure"
  deploy-environment: "dev"
  azure-storage-account-name: "dsostorage"
  azure-storage-table-name: "mytable"
  json-file-path: "configs/delete-entities.json"
  azure-resource-group: "rg-dso-dev"
  operation-type: "delete"
secrets:
  client-id: ${{ secrets.AZURE_CLIENT_ID }}
  tenant-id: ${{ secrets.AZURE_TENANT_ID }}
  subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}
  sas-token: ${{ secrets.SAS_TOKEN }}
```

---

## Inputs

| Name | Description | Required | Type | Default |
|------|-------------|----------|-------|---------|
| `deploy-runner-type` | Runner where the job executes | ✅ | string | azure |
| `deploy-environment` | Deployment environment | ✅ | string | - |
| `azure-storage-account-name` | Azure Storage Account name | ✅ | string | - |
| `azure-storage-table-name` | Name of the Azure Storage Table | ✅ | string | - |
| `json-file-path` | Path to JSON entity file | ✅ | string | - |
| `azure-resource-group` | Azure Resource Group name | ✅ | string | - |
| `operation-type` | Operation: `upsert` or `delete` | ✅ | string | - |

---

## Secrets

| Name | Description | Required | Type |
|------|-------------|----------|-------|
| `client-id` | Azure Service Principal Client ID | ✅ | string |
| `tenant-id` | Azure Tenant ID | ✅ | string |
| `subscription-id` | Azure Subscription ID | ✅ | string |
| `sas-token` | SAS Token for direct Table Storage access | ❌ | string |

> [!CAUTION]  
> SAS tokens must never be logged. Rotate tokens immediately if exposure is suspected.

---

## Jobs & Steps

### Manage Azure Storage Tables ☁️

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checks out repository to access JSON files |
| [**action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Authenticates to Azure using Service Principal |
| [**action-azure-install-cli**](https://github.com/BHGitOps/action-azure-install-cli) | Installs Azure CLI |
| [**action-azure-storage-account-table**](https://github.com/BHGitOps/action-azure-storage-account-table) | Upserts table entities |
| [**action-delete-azure-storage-account-table**](https://github.com/BHGitOps/action-delete-azure-storage-account-table) | Deletes all entities from the table |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Cleans runner workspace after completion |

---

## Changelog 📝

| Version | Date       | Tags            | Changes |
|--------|------------|----------------|---------|
| **v2**  | 2025‑07‑30 | Breaking Changes | - **Improved:** Support for upsert/delete operations across environments<br>- **Enhanced:** Table entity processing and cleanup |
| **v1**  | 2025‑02‑27 | Initial Release | - **Added:** Insert/Update/Delete table entities via JSON file<br>- **Added:** SAS token support and Azure login integration |

---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>
  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1731428362/workflow-azure-storage-account-table+v2+Reusable+Workflow+Azure+Storage+Tables+Management">Workflow-azure-storage-account-tableᵈ²</a>
    </strong>
    <p>
      Workflow-azure-storage-account-table - Reusable GitHub workflow for Azure Storage Account Table workflows, usage patterns, and examples.
    </p>
  </article>  

---

## Feedback / Need Help? 📬  
If you need help or have questions, reach out to your team lead or the Platform Engineering Support team.  
We're here to help you succeed!
