<h1 align="center">Workflow-azure-keyvault-keys</h1>

## Overview
This repository provides a **reusable GitHub workflow for managing Azure Key Vault keys** using a JSON-driven configuration model. The workflow standardizes key lifecycle operations such as creation, update, deletion, and optional purge, and is designed to be consumed by multiple repositories through `workflow_call`.

It leverages a dedicated **Azure Key Vault Key Action**, Azure CLI authentication, and environment-aware execution to ensure secure and consistent key management across environments.

---

## Getting Started
This document helps application teams quickly adopt the reusable workflow and integrate Azure Key Vault key management into their CI/CD pipelines.

---

## Reusable Workflow Summary

The table outlines the essential details of the reusable Azure KeyVault Keys deployment workflow, including its name, current stable version, supported cloud environment and services, and configuration model.

| • Workflow Name | workflow-azure-keyvault-keys |
| :------| :-------------|
| • **Latest Stable Version** | v1 |
| • **Current Version** | v1 |
| • **Cloud Environment** | Azure |
| • **Cloud Services** | Azure Key Vault |
| • **Configuration Model** | JSON-based key definitions |
| • **TechStacks** | Azure Key Vault |
| • **Is Conjur integrated** | No |

---

## Mock Caller Repositories

The following mock repository provides a reference implementation for consuming this reusable workflow.

| Mock Repository URL | Purpose | Technology Stack |
|-----------------|---------|----------------|
| [**mock-azure-keyvault-keys**](https://github.com/BHGitOps/mock-azure-keyvault-keys)  | Reference implementation demonstrating how to call the reusable workflow to manage Azure Key Vault keys using a JSON configuration file | Azure Key Vault |

---

## Key Features & Capabilities

- Manage Azure Key Vault keys using declarative JSON configuration
- Supports **upsert** (create/update) and **delete** operations
- Optional purge of soft-deleted keys with retry handling
- Environment-aware execution using GitHub Environments
- Secure authentication using Azure Service Principal
- Reusable across repositories via `workflow_call`
- Automated cleanup of runner artifacts

---

## Prerequisites

- Azure Key Vault already exists
- Azure Service Principal has required RBAC permissions on the Key Vault
- GitHub Environment is configured (dev / qa / prod, etc.)
- JSON file defining key operations is available in the repository

> [!IMPORTANT]
> Before using this reusable workflow to Azure KeyVault Keys, ensure the following prerequisites are met.
> Please coordinate with the IAC team to obtain all required infrastructure details before attempting to use our reusable workflow, as the infrastructure setup must always be completed first.

---

## Usage
#### Example: Calling This Reusable Workflow

```yaml
uses: BHGitOps/workflow-azure-keyvault-keys/.github/workflows/workflow.yml@v1
with:
  keyvault-name: my-keyvault
  deploy-runner-type: azure
  deploy-environment: prod
  keys-file-path: ./config/keys.json
secrets:
  client-id: ${{ secrets.AZURE_CLIENT_ID }}
  tenant-id: ${{ secrets.AZURE_TENANT_ID }}
  subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}
```

---

## JSON Configuration Example

```json
[
  {
    "name": "app-key",
    "operation": "upsert",
    "keyType": "RSA",
    "rsaKeySize": 2048,
    "expiryDays": 365,
    "disablePreviousVersions": true
  },
  {
    "name": "legacy-key",
    "operation": "delete",
    "purge": true
  }
]
```

---

## Inputs

| Name | Description | Required | Type | Default |
|----|------------|----------|------|---------|
| `keyvault-name` | Name of the Azure Key Vault | ✅ | string | — |
| `deploy-runner-type` | GitHub Actions runner to use | ✅ | string | `azure` |
| `deploy-runner-type` | Runner where the deployment job gets executed | ✅ | string | [**Refer GitHub Reusable Workflowᵈ¹**](#Resources) |
| `keys-file-path` | Path to JSON file defining key operations | ✅ | string | — |

---

## Secrets

| Name | Description | Required | Type | Default |
|----|------------|----------|------|---------|
| `client-id` | Azure Service Principal Client ID | ✅ | string | — |
| `tenant-id` | Azure Active Directory Tenant ID | ✅ | string | — |
| `subscription-id` | Azure Subscription ID | ✅ | string | — |

> [!CAUTION]
> It is the responsibility of the application team to securely manage all secrets, whether stored in Conjur or GitHub Secrets. Secrets must never be logged, exposed, or configured in a way that could cause them to appear in application logs.
If a secret is suspected to be leaked or compromised in any way, it must be reported immediately and rotated without delay.

---

## Jobs & Steps

- sync-keys

### **1. sync-keys** 🛠️
Runs on the runner and environment passed by the caller and orchestrates all Key Vault key operations.

| Action Name | Purpose |
|-------------|---------|
| [**BHGitOps/action-checkout**](https://github.com/BHGitOps/action-checkout) | Checkout repository content to the runner. |
| [**BHGitOps/action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Login to Azure using the provided Service Principal (Client ID / Tenant ID / Subscription ID). |
| [**BHGitOps/action-azure-install-cli**](https://github.com/BHGitOps/action-azure-install-cli) | Install and/or verify Azure CLI on the runner. |
| [**BHGitOps/action-azure-keyvault-keys**](https://github.com/BHGitOps/action-azure-keyvault-keys) | Process Azure Key Vault key operations from the JSON file (upsert, delete, optional purge). |
| [**BHGitOps/action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Remove temporary files and artifacts from the runner (always runs). |

---

## Best Practices

- Store key configuration files in version control
- Follow least-privilege RBAC principles
- Use environment approvals for production workflows
- Avoid purging keys unless explicitly required

---

## Changelog 📝

| Version | Date       | Tags                                                                 | Changes |
|:--------:|:------------|----------------------------------------------------------------------|---------|
| **v1**  | 2026-02-06 | Initial Release                                                       | - **Added:** Initial reusable workflow for Azure Key Vault key management |

---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>
  
---

## Feedback / Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!