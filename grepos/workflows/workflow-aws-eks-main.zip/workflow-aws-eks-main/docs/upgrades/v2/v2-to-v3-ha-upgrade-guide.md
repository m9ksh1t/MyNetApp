
# Upgrade Guide: workflow-aws-eks (v2 → v3)

This document provides step-by-step instructions to migrate your GitHub workflows from **v2** to the **major v3 release** of the [**workflow-aws-eks**](../../../.github/workflows/workflow.yml) reusable workflow.

> [!NOTE]
> This upgrade includes **breaking changes**, and all application teams must migrate to the updated reusable workflow version to ensure compatibility with new enhancements, including **High Availability (HA)** support.
> 
> Any caller workflow referencing workflow versions **≤v2** must follow this upgrade path, as older versions are not compatible with the changes introduced in v3 and must be updated to ensure continued functionality and support.


> [!CAUTION]
> Migration deadline is April 7, 2026.

---

## 🔄 Overview of Changes
The v3 upgrade requires updates across all application caller workflows that reference the [**workflow-aws-eks**](../../../.github/workflows/workflow.yml) reusable workflow, specifically:
- Updating the reusable workflow version reference to v3
- Updating parameters for ECR Matrix and EKS Deploy Matrix

Follow the instructions below to complete the migration safely.

---

## Mock Caller Repositories

A mock workflow, shown below, provides a solid starting point for implementing this version upgrade. Refer to the below mock example.

| Mock Repository URL | Purpose |
|------------------|-------------|
| [**mock-eks-deploy-dotnet:v4**](https://github.com/BHGitOps/mock-eks-deploy-dotnet/blob/main/.github/workflows/01-deploy-docker-file-path-and-secrets-mounted-multiple-env.yml) | Provides a reference implementation for deploying a .NET application using this reusable workflow including HA and Wiz upgrade |

> **Tip:** In the mock repository, an additional job—prepare-vars-for-environment—is included to source environment‑level variables. The subsequent job typically consumes these variables from the job outputs (e.g., dev-vars-json or qa-vars-json) and injects them into each matrix item using ${{ fromJSON(...) }}.

> Refer to the [**prepare-vars-for-environment**](../../common/prepare-vars-for-environment.md) guide for detailed instructions on retrieving environment‑level variables.
> This job is optional, the values can be hardcoded, but using it is recommended.

---

## 📝 Step 1: Update the workflow-aws-eks version reference

Change your reusable workflow reference from **v2** to the **v3** release.

**Before:**
```yaml
uses: BHGitOps/workflow-aws-eks/.github/workflows/workflow.yml@v2
```

**After:**
```yaml
uses: BHGitOps/workflow-aws-eks/.github/workflows/workflow.yml@v3
```

---

## 📝 Step 2: Update parameters for High Availability (HA)
These steps explain all subsequent changes that are related to High Availability (HA). Although your application does not currently require HA, the workflow still requires passing the target ecr/cluster parameter in the matrix. This ensures that the pipeline can support multi–ECR image pushes and multi‑cluster deployments in the future, if needed.

### Parameter Mapping: v2 → v3 (Single-Target → Matrix Configuration)

This table summarizes how **v2 single-target parameters** map to the new **v3 matrix-based configuration** (`ecr-matrix-config` and `deploy-matrix-config`). Use it as a quick reference when migrating your workflow inputs.

> [!NOTE]
> Refer **Mapping Table** below. Rename the v2 (Old Parameters) to v3 (New Parameters) and place them under the appropriate matrix location. This highlights that, instead of pushing images to a single ECR repository, the workflow now supports using a matrix strategy to push images to multiple ECR repositories.
> Similarly, this approach also enables deploying images from multiple ECR repositories to multiple EKS clusters.

---

## 🔁 Mapping Table

| v2 (Old Parameter) | v3 (New Parameter) | Location | Notes |
|---|---|---|---|
| `target-aws-account-id` | `target-ecr-aws-account-id` | **ECR matrix** | Target Account-Id used for ECR push.*² |
| `target-aws-account-id` | `target-eks-aws-account-id` | **EKS deploy matrix** | Target Account-Id used for cluster access/deploy.*³ |
| `target-aws-region` | `target-ecr-aws-region` | **ECR matrix** | Target aws region for ECR operations (e.g., `us-west-2`).*² |
| `target-aws-region` | `target-eks-aws-region` | **EKS deploy matrix** | Target aws region of the EKS cluster.*³ |
| `target-oidc-assume-role` | `target-ecr-oidc-assume-role` | **ECR matrix** | Target OIDC role used for ECR push.*² |
| `target-oidc-assume-role` | `target-eks-oidc-assume-role` | **EKS deploy matrix** | Target OIDC role used for EKS access.*³ |
| `target-role-session-name` | `target-ecr-role-session-name` | **ECR matrix** | Target STS role session name for ECR.*²  |
| `target-role-session-name` | `target-eks-role-session-name` | **EKS deploy matrix** | Target STS role session name for EKS.*³ |
| `target-container-repository` | `target-ecr-container-repository` | **ECR matrix** | Target ECR repository for image push.*² |
| `target-container-repository` | `target-ecr-container-repository` | **EKS deploy matrix** | Target ECR repository referenced to ensure consistent image paths during deployments.*³ |
| `target-deployment-file` | `target-deployment-file` | **EKS deploy matrix** | Target Path to the manifest values moved inside the deploy matrix.*¹ |
| `target-service-account-role` | `target-service-account-role` | **EKS deploy matrix** | Target service-account-role moved inside the deploy matrix.*¹ |
| `target-cluster-name` | `target-cluster-name` | **EKS deploy matrix** | Target Cluster identifier moved inside the deploy matrix.*¹ |
| `target-namespace` | `target-namespace` | **EKS deploy matrix** | Target Kubernetes namespace moved inside the deploy matrix.*¹ |

*¹ - The parameter names remain the same—however, these values are now placed inside the deploy-matrix-config, where each array item can define its own deployment‑specific values, enabling support for multiple deployments across different clusters.

*² - These values are specific to ECR and are now placed inside the ecr-matrix-config, where each array item defines the target ECR repository to which images should be pushed—enabling support for copying images across multiple ECR locations.

*³ -  These values are specific to EKS and are now placed inside the deploy-matrix-config, where each array item can define its own deployment‑specific settings. This enables support for multiple deployments across different EKS clusters, each capable of pulling images from any ECR.

---

## 📋 Example Snippets (for QA)

**ECR Matrix (v3):**
```yaml
ecr-matrix-config: |
  [
    {
      "target-ecr-oidc-assume-role": "${{ fromJSON(needs.prepare-vars-for-environment.outputs.qa-vars-json).OIDC_ASSUME_ROLE }}",
      "target-ecr-role-session-name": "${{ fromJSON(needs.prepare-vars-for-environment.outputs.qa-vars-json).ROLE_SESSION_NAME }}",
      "target-ecr-aws-region": "us-west-2",
      "target-ecr-container-repository": "dso-sb-ecr01",
      "target-ecr-aws-account-id": "${{ fromJSON(needs.prepare-vars-for-environment.outputs.qa-vars-json).AWS_ACCOUNT_ID }}"
    }
  ]
```

**EKS Deploy Matrix (v3):**
```yaml
deploy-matrix-config: |
  [
    {
      "target-eks-oidc-assume-role": "${{ fromJSON(needs.prepare-vars-for-environment.outputs.qa-vars-json).OIDC_ASSUME_ROLE }}",
      "target-eks-role-session-name": "${{ fromJSON(needs.prepare-vars-for-environment.outputs.qa-vars-json).ROLE_SESSION_NAME }}",
      "target-deployment-file": "k8s/devdeployment.yml",
      "target-namespace": "dso",
      "target-eks-aws-region": "us-west-2",
      "target-cluster-name": "dso-eks-cluster-2",
      "target-ecr-container-repository": "dso-sb-ecr01",
      "target-eks-aws-account-id": "${{ fromJSON(needs.prepare-vars-for-environment.outputs.qa-vars-json).AWS_ACCOUNT_ID }}"
    }
  ]
```

> [!WARNING]
> All parameter names and their value assignments inside the `ecr-matrix-config` and `deploy-matrix-config` inputs must be wrapped in **double quotes** to prevent exceptions or value errors.

---

## 🧪 Step 3 : Deprecated or Renamed Parameters

- The following parameters have either been deprecated or renamed:

    - If a parameter is deprecated, it can be safely removed from your workflow.
    - If a parameter has been renamed, update your workflow to use the new parameter name in place of the old one.

### Parameter/Input Changes

| Status      | Old Input Name       | New Input Name       | Notes                                    |
|-------------|----------------------|----------------------|-------------------------------------------|
| Deprecated  | `artifact-path`      | —                        | Remove this parameter from your workflow. |
| Renamed     | `wiz_client_id`      | `wiz-client-id`      | Updated to hyphen-based naming.           |
| Renamed     | `wiz_client_secret`  | `wiz-client-secret`  | Updated to hyphen-based naming.           |


---

## 🧪 Step 4 (Optional): Validate the workflow

After updating:
1. Commit the changes  
2. Push to your branch  
3. Trigger the workflow manually or wait for the next run  
4. Confirm the job completes successfully without authentication or version issues  

---

## ✅ Migration Complete

Your project is now upgraded to the **v3** reusable workflow.  

---

## 📚 Resources

If you'd like a full updated workflow example or additional enhancements, please refer below!

| Mock Repository URL | Purpose | Technology Stack |
|------------------|-------------|----------|
| [**mock-eks-deploy-dotnet**](https://github.com/BHGitOps/mock-eks-deploy-dotnet) | Provides a reference implementation for deploying a .NET application using this reusable workflow | .NET |

---

## 📬 Feedback/Need Help?

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
