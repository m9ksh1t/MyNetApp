# Upgrade Guide: workflow-aws-eks (v4 → v5)

This document provides step-by-step instructions to migrate your GitHub workflows from **v4** to the **v5** of the [**workflow-aws-eks**](../../../.github/workflows/workflow.yml) reusable workflow.

> [!NOTE]
> This upgrade includes **breaking changes**, and all application teams must migrate to the updated reusable workflow version to ensure compatibility with new enhancements, including **skip-build-job** support.
>
> > Any caller workflow that references versions prior to the latest release must follow this upgrade path. Earlier versions are not compatible with the changes introduced in this release and must be updated to ensure continued functionality and support.

> [!CAUTION]
> Migration deadline : Flexible **(Any new onboarding must adopt this version** to ensure compatibility and support.)

---

## 🔄 Overview of Changes
The new tag introduces the ability to skip the application build job and directly execute subsequent stages, including Docker Build, ECR Push (Source), Deploy EKS (Source), ECR Push (Target), and Deploy EKS (Target).
This enhancement enables technology stacks such as Python and Curity to bypass the application-specific build phase and rely solely on Docker images for building and deploying to EKS.
Version **v5** introduces a new parameter, **skip-build-job**, which defaults to false. When set to true, the build job is skipped and the workflow continues with the docker build and deployment stages.

This change requires updates across all application caller workflows that reference the [**workflow-aws-eks**](../../../.github/workflows/workflow.yml) reusable workflow, specifically:
- Updating the reusable workflow version reference to **v5**
- Configure skip-build-job=true (default is false) for technology stacks that do not require an application build process.

## Justification
In the previous v4 version, the build job is skipped only when the framework type is Python. As the technology stack continues to evolve, there are additional scenarios—such as the current Curity use case—where skipping the build job is necessary.
Introducing the new skip-build-job parameter allows the build stage to be skipped regardless of the technology stack, providing greater flexibility and control. This enhancement improves overall maintainability, reduces repetitive pipeline definitions, and better aligns the deployment workflow with modern container based deployment patterns.

Follow the instructions below to complete the migration safely.

---

## Mock Caller Repositories

A mock workflow, shown below, provides a solid starting point for implementing this version upgrade. Refer to the below mock example.

| Mock Repository URL | Purpose |
|------------------|-------------|
| [**mock-eks-deploy-dotnet**](https://github.com/BHGitOps/mock-eks-deploy-dotnet/blob/main/.github/workflows/01-deploy-docker-file-path-and-secrets-mounted-multiple-env.yml) | Provides a reference implementation for deploying a .NET application using this reusable workflow including HA and Wiz upgrade |
| [**mock-eks-deploy-python**](https://github.com/BHGitOps/mock-eks-deploy-python/blob/main/.github/workflows/aws-eks-deploy-python-ha-v3.yml) | Provides a reference implementation for deploying a Python application using this reusable workflow including HA, Wiz upgrade to 1.x and skip-build-job option |

> **Tip:** In the mock repository, an additional job—prepare-vars-for-environment—is included to source environment‑level variables. The subsequent job typically consumes these variables from the job outputs (e.g., dev-vars-json or qa-vars-json) and injects them into each matrix item using ${{ fromJSON(...) }}.

> Refer to the [**prepare-vars-for-environment**](../../common/prepare-vars-for-environment.md) guide for detailed instructions on retrieving environment‑level variables.
> This job is ***optional***, the values can be hardcoded, but using it is recommended.

---

## 📝 Step 1: Update the workflow-aws-eks version reference

Change your reusable workflow reference from **v4** to the **v5** release.

**Before:**
```yaml
uses: BHGitOps/workflow-aws-eks/.github/workflows/workflow.yml@v4
```

**After:**
```yaml
uses: BHGitOps/workflow-aws-eks/.github/workflows/workflow.yml@v5
```

---

## 📝 Step 2: Set new parameter 'skip-build-job'

The latest workflow tag introduces an optional skip-build-job parameter. When set to true, this parameter allows technology stacks such as Python and Curity to bypass the application‑specific build phase and rely solely on Docker image builds for deploying to EKS.

**New Parameter:**
```yaml
skip-build-job: true
```

> [!NOTE]
> This parameter is optional which **default: false**.

---

## 🧪 Step 3 : Deprecated, Renamed, and New Parameters

- This version introduces changes to workflow inputs, including deprecated parameters, renamed parameters, and the addition of a new optional parameter.

    - If a parameter is deprecated, it can be safely removed from your workflow.
    - If a parameter has been renamed, update your workflow to use the new parameter name in place of the old one.
    - New optional parameters can be added as needed based on your technology stack.

### Parameter/Input Changes

| Status      | Old Input Name       | New Input Name       | Notes                                     |
|-------------|----------------------|----------------------|-------------------------------------------|
| New         | —                    | skip-build-job       | Boolean (default: false). When set to true, skips the build job |

---

## 🧪 Step 4 (Optional): Validate the workflow

After updating:
1. Commit the changes  
2. Push to your branch  
3. Trigger the workflow manually or wait for the next run  
4. Confirm the job completes successfully without version issues  

---

## ✅ Migration Complete

Your project is now upgraded to the **latest** reusable workflow.  

---

## 📚 Resources

If you'd like a full updated workflow example or additional enhancements, please refer below!

| Mock Repository URL | Purpose | Technology Stack |
|------------------|-------------|----------|
| [**mock-eks-deploy-dotnet**](https://github.com/BHGitOps/mock-eks-deploy-dotnet) | Provides a reference implementation for deploying a .NET application using this reusable workflow | .NET |
| [**mock-eks-deploy-python**](https://github.com/BHGitOps/mock-eks-deploy-python) | Provides a reference implementation for deploying a .NET application using this reusable workflow | Python |

##  README.md
For detailed functionality and implementation steps, refer to the workflow‑specific [**README.md**](https://github.com/BHGitOps/workflow-aws-eks/blob/main/README.md) guide.

---

## 📬 Feedback/Need Help?

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
