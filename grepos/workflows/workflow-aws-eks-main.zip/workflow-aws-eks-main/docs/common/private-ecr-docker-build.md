# Private ECR Base Images in Docker-Build

Use private ECR login during `Docker-Build` when your Dockerfile references base images stored in a private Amazon ECR repository.

## When to use this

Enable private ECR login when both conditions are true:

1. You are running the `Docker-Build` job.
2. Your Docker base image is hosted in private ECR.

Set the workflow input below to enable this flow:

- `docker-build-base-image-ecr-login-enabled: true`

When enabled, the workflow configures AWS credentials, installs AWS CLI, logs in to ECR, and then pulls the private base image during Docker build.

## Docker-Build inputs for private ECR base image access

| Input Parameter | Purpose | Default Value |
|---|---|---|
| `docker-build-base-image-ecr-login-enabled` | Turns on AWS auth and ECR login steps before Docker build for private base image pulls. If not provided, the default `false` is used and private ECR login steps are skipped. | `false` |
| `docker-build-base-image-aws-account-id` | AWS account ID hosting the private ECR base image repository. If not provided, workflow uses `source-aws-account-id`. | None |
| `docker-build-base-image-aws-region` | AWS region for the private ECR base image repository. If not provided, workflow uses `source-aws-region`. | `us-west-2` |
| `docker-build-base-image-oidc-assume-role` | OIDC IAM role to assume for private ECR authentication in Docker-Build. If not provided, workflow uses `source-oidc-assume-role`. | None |
| `docker-build-base-image-role-session-name` | Role session name used when assuming the OIDC role for private ECR authentication. If not provided, workflow uses `source-role-session-name`. | None |

## Fallback behavior in the workflow

If the Docker-Build-specific values are not provided, the workflow falls back to source account inputs in the Docker-Build steps:

- `source-oidc-assume-role`
- `source-role-session-name`
- `source-aws-region`
- `source-aws-account-id`

## Runners

Use a self-hosted runner by default for Docker builds that only need private ECR access:

- `docker-runner: "aws-westus2-pool"`

This runner can authenticate to private ECR, pull base images, and build Docker images.

If your Dockerfile includes commands that require public internet access and cannot run from this self-hosted runner, first try removing or replacing those commands so the build can remain on self-hosted infrastructure.

Example command pattern to avoid when possible:

- `RUN apt update && apt install -y curl`
