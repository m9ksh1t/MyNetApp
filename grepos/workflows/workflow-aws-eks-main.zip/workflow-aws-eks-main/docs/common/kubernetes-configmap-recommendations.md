# Kubernetes ConfigMap Recommendations

This document recommends using Kubernetes ConfigMaps for non-sensitive runtime configuration in this workflow.

## Why use ConfigMaps

Configuration should always be external to the application.

For small sets of configuration values, the easiest way to externalize configuration is by putting values into universally supported environment variables.

The advantage of ConfigMap and Secret indirection is that environment variables can be managed independently from the Pod definition.

## Security reminder

Environment variables are not secure by default. Putting sensitive, readable information into environment variables makes this information easy to read, and it may even leak into logs.

Use ConfigMaps for non-sensitive settings. Use Kubernetes Secrets for sensitive values.

## Recommended usage patterns

1. Banner recommendation: Use ConfigMaps for non-sensitive data that can be stored and retrieved as environment variables or mounted as volumes.
2. Prefer file-based ConfigMaps when you already maintain environment files.
3. Prefer vars-based ConfigMaps for small, explicit key sets.
4. Keep naming consistent across environments (for example, same `configmap-name` with environment-specific values).
5. Keep sensitive keys out of ConfigMaps and place them in Secrets.
6. Use ConfigMap updates to change runtime configuration without rebuilding application images.

## Workflow references

The reusable workflow already includes explicit ConfigMap creation steps in both the source and target deployment paths:

- Step name: `Create Kubernetes Configmaps` (source deployment path)
- Step name: `Create Kubernetes Configmaps` (target deployment path)

These steps call:

- `BHGitOps/action-create-k8s-configmaps@v1`

The step runs when either a config file path or variable names are provided:

- Source condition: `inputs.source-configmap-file-path != '' || inputs.vars-name != ''`
- Target condition: `inputs.target-configmap-file-path != '' || inputs.vars-name != ''`

## Action input references

The action-create-k8s-configmaps definition at [`action-create-k8s-configmaps`](https://github.com/BHGitOps/action-create-k8s-configmaps) defines the required inputs used by the ConfigMap step:

- `vars-json`: JSON object containing variable values
- `vars-name`: Comma-separated variable names to include
- `configmap-name`: Name of the ConfigMap to create
- `namespace`: Kubernetes namespace
- `configmap-file-path`: File path for `.env`, `.json`, or other supported file-based ConfigMap sources

## How ConfigMap keys are consumed in Pods

Once a ConfigMap is created and holds data, keys can be consumed in two ways:

- As references for environment variables, where the key becomes the environment variable name.
- As files mapped into a mounted volume, where the key becomes the filename.

## Practical recommendation for this repository

When using this reusable workflow, enable the Create Kubernetes Configmaps step by setting either:

- `source-configmap-file-path` or `target-configmap-file-path`
- `vars-name` with corresponding `vars-json`

This keeps deployment configuration external, repeatable, and easier to manage across source and target environments.
