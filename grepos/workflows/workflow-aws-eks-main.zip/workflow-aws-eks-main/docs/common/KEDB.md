# 📘 KEDB (Known Error Database)

## 1. Overview / Purpose
This Known Error Database (KEDB) documents **recurring errors**, **root causes**, and **resolutions** encountered in this repository or associated workflows.  

---

## 2. How to Use This KEDB
1. Search for the error message or affected component  
2. Review the documented **Symptom → Root Cause → Resolution → Prevention**  
3. Apply the fix or workaround  
4. If the error is not documented, create a new entry using the template below and submit a PR

---

## 3. Quick Triage Checklist
Before deep investigation, verify:
- ❑ Which job/component failed  
- ❑ The exact error message  
- ❑ Inputs, parameters, and secrets are valid  
- ❑ Syntax and formatting (YAML/JSON) are correct  
- ❑ Any recent workflow or infra changes  

---

## 4. Error - Resolution

```yaml
**Error :** 
Error when evaluating 'strategy' for job 'ECR-Push-Target'. BHGitOps/workflow-aws-eks/.github/workflows/workflow.yml@v4 (Line: 848, Col: 18): Error from function 'fromJson': Unexpected symbol: 'arn'. Located at line 3 position 36 within JSON., BHGitOps/workflow-aws-eks/.github/workflows/workflow.yml@v4 (Line: 848, Col: 18): Unexpected value ''

**Resolution :**
All parameter names and their value assignments inside the ecr-matrix-config and deploy-matrix-config inputs must be wrapped in double quotes to prevent exceptions or value errors.
```
