
# Prepare Environment Variables for Matrix Environments (dev --> qa or qa --> prod)

This workflow job prepares **environment-scoped variables** from GitHub Environments (e.g., `dev`, `qa`) and exposes them as **compact JSON outputs** that downstream jobs can consume. It supports a matrix over environments, so the job runs once per environment and produces the appropriate output.

---

## What this job does

- Selects the target GitHub **Environment** via a matrix (`dev`, `qa`).
- Loads all **Environment Variables** available in that environment via the `vars` context.
- Uses the reusable action `BHGitOps/action-prepare-env-vars@v1` to:
  - Read the raw variables JSON.
  - Filter/shape them for the current environment.
  - Emit compact JSON strings as **job outputs** (`dev-vars-json`, `qa-vars-json`).
- Makes those JSON strings easy to consume using `fromJSON(...)` in downstream jobs/steps.

---

## Why use environments and `vars`?

GitHub **Environments** let you define *environment-scoped variables* (e.g., different API keys, endpoints, or IDs for `dev` vs `qa` vs `prod`). The `vars` context contains those environment variables when the job is attached to an environment:

```yaml
environment: ${{ matrix.environment }}
```

The `toJson(vars)` call serializes the full set of environment-level variables into JSON for the action to process.

> ⚠️ **Note**: `vars` refers to **Environment Variables** defined in *Settings → Environments → [dev|qa]*. It’s distinct from secrets (`secrets`) and repository/organization variables.

---

## Job YAML

```yaml
prepare-vars-for-environment:
  runs-on: ubuntu-latest
  environment: ${{ matrix.environment }}
  strategy:
    matrix:
      environment: [dev, qa]
  outputs:
    dev-vars-json: ${{ steps.set-vars.outputs.dev-vars-json }}
    qa-vars-json: ${{ steps.set-vars.outputs.qa-vars-json }}
  steps:
    - name: prepare-vars
      id: set-vars
      uses: BHGitOps/action-prepare-env-vars@v1
      with:
        raw-vars-json: ${{ toJson(vars) }}
        env-name: ${{ matrix.environment }}
```

---

## Consuming the outputs in subsequent jobs

To reference a variable inside the JSON produced by this job:

```yaml
${{ fromJSON(needs.prepare-vars-for-environment.outputs.dev-vars-json).WIZ_PROJECT_ID }}
```

Below is a typical usage example:

```yaml
downstream-job:
  runs-on: ubuntu-latest
  needs: [prepare-vars-for-environment]
  steps:
    - name: Use a dev variable
      run: |
        echo "DEV WIZ Project ID: $WIZ_PROJECT_ID_DEV"
      env:
        WIZ_PROJECT_ID_DEV: ${{ fromJSON(needs.prepare-vars-for-environment.outputs.dev-vars-json).WIZ_PROJECT_ID }}
```

---

## Troubleshooting

- **`fromJSON(...)` returns null** → Verify variable exists in the GitHub Environment.
- **Outputs appear empty** → Ensure the job is bound to an environment (`environment: ${{ matrix.environment }}`).
- **Secrets missing** → Secrets are *not* included in `vars`; access them via `secrets` context.

---

## Quick Reference

- Serialize vars:
  ```yaml
  raw-vars-json: ${{ toJson(vars) }}
  ```
- Access key from dev JSON:
  ```yaml
  fromJSON(needs.prepare-vars-for-environment.outputs.dev-vars-json).KEY
  ```

---

  
> [!IMPORTANT]
> If you execute the caller workflow with qa included in the environment: [dev, qa] matrix while running from a feature branch, the workflow will fail.
> This is because the qa job is restricted and can only run from the **main** branch.
> In such cases, update the matrix to remove qa and adjust the output references accordingly—for example:
>

```yaml
matrix:
  environment: [dev]

outputs:
  dev-vars-json: ${{ steps.set-vars.outputs.dev-vars-json }}   # Outputs a compact JSON string of environment-level variables
  qa-vars-json:  ${{ steps.set-vars.outputs.dev-vars-json }}   # Temporarily mapped to dev when QA is not available
```

---

## Feedback/Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
