# Kubernetes Secrets & GitHub-to-K8s Secret Workflow Guide

This file is a pointer to the canonical documentation maintained in the `workflow-k8s-secret-handler` repository.

👉 Please see the canonical `kubernetes-secrets-overview.md` document here:  
[**kubernetes-secrets-overview.md**](https://github.com/BHGitOps/workflow-k8s-secret-handler/blob/main/docs/common/kubernetes-secrets-overview.md)
