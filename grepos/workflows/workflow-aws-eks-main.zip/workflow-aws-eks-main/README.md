<h1 align="center">
  <a href=".github/workflows/workflow.yml">workflow-aws-eks</a>
</h1>

## Overview
This repository delivers a reusable GitHub Actions workflow for deploying applications to **AWS EKS (Elastic Kubernetes Service)**. It supports secure authentication via OIDC, optional integration with CyberArk Conjur for secrets management, Docker image build and push to Amazon ECR, and Wiz image scanning. The workflow is designed to handle advanced multi‑environment and multi‑account deployment scenarios.

Using this workflow, you can efficiently and securely deploy .NET, Angular, Python, or Backstage applications to AWS EKS. It also provides enhanced matrix support for promoting container images across **multiple Amazon ECR repositories in different AWS accounts or regions, and for deploying workloads across multiple **(EKS)** AWS accounts and regions.

---

## Getting Started

These documents will help you get up to speed with our engineering practices and tools.

## Reusable Workflow Summary

The table outlines the essential details of the reusable AWS EKS deployment workflow, including its name, current stable version, supported cloud environment and services, compatible tech stacks, and confirmation of Conjur integration

| Workflow Name | [**workflow-aws-eks**](.github/workflows/workflow.yml) |
| :------| :-------------|
| **Latest Stable Version** | v5 |
| **Current Version** | v5 |
| **Cloud Environment** | AWS |
| **Cloud Services** | EKS |
| **TechStacks** | .NET, Angular, node/yarn, **Python** |
| **Is Conjur integrated** | Yes*¹ (optional) |
| **High Availability Supported** | Yes |

*¹ - CyberArk Conjur is integrated into this workflow to securely manage sensitive information such as API keys, credentials, and environment variables. Secrets can be fetched dynamically during build and deployment steps, ensuring compliance and security. **Using Conjur is optional**—you may supply the same values via GitHub environment secrets instead.

---

## Reusable Workflow Upgrade Guide

It is considered a best practice to keep your caller/application workflows updated to reference the latest stable version of the reusable workflow. Doing so ensures you benefit from the newest features, security patches, enhancements, and bug fixes provided in the workflow-aws-eks reusable workflow

<u>For detailed upgrade paths, refer to the table below.</u>

[**workflow-aws-eks (v2 → v3)**](docs/upgrades/v2/v2-to-v3-ha-upgrade-guide.md)

[**workflow-aws-eks (v3 → v4)**](docs/upgrades/v3/v3-to-v4-wiz-upgrade-guide.md)

[**workflow-aws-eks (v4 → v5)**](docs/upgrades/v4/v4-to-v5-skip-build-job-upgrade-guide.md)

---

## Common Guides 📖

| Guide | Description |
|-------|-------------|
| [**Private ECR Docker Build Guide**](docs/common/private-ecr-docker-build.md) | Use this guide when your Docker build pulls base images from a private Amazon ECR repository and you need to enable the private ECR login inputs. |
| [**Kubernetes ConfigMap Recommendations**](docs/common/kubernetes-configmap-recommendations.md) | Best practices and recommendations for creating and managing Kubernetes ConfigMaps in this workflow. |
| [**Kubernetes Secrets Recommendations**](docs/common/kubernetes-secrets-recommendations.md) | Best practices and recommendations for creating and managing Kubernetes Secrets in this workflow. |

---

## Mock Caller Repositories

A mock workflow, shown below, provides a solid starting point for implementing this reusable workflow to support application deployments to AWS EKS. Refer to the table below for the list of available caller workflows.

| Mock Repository URL | Purpose | Technology Stack |
|------------------|-------------|----------|
| [**mock-eks-deploy-dotnet**](https://github.com/BHGitOps/mock-eks-deploy-dotnet) | Provides a reference implementation for deploying a .NET application using this reusable workflow | .NET |
| [**mock-eks-deploy-angular**](https://github.com/BHGitOps/mock-eks-deploy-angular) | Provides a reference implementation for deploying an Angular application using this reusable workflow | Angular |
| [**mock-eks-deploy-backstage**](https://github.com/BHGitOps/mock-eks-deploy-angular) | Provides a reference implementation for deploying an backstage application using this reusable workflow | node/yarn |
| [**mock-eks-deploy-python**](https://github.com/BHGitOps/mock-eks-deploy-python) | Provides a reference implementation for deploying a python application using this reusable workflow | Python |

> **Tip:** In the mock repository, an additional job—prepare-vars-for-environment—is included to source environment‑level variables. The subsequent job typically consumes these variables from the job outputs (e.g., dev-vars-json or qa-vars-json) and injects them into each matrix item using ${{ fromJSON(...) }}.

> Refer to the [**prepare-vars-for-environment**](docs/common/prepare-vars-for-environment.md) guide for detailed instructions on retrieving environment‑level variables.
> This job is optional, the values can be hardcoded, but using it is recommended.

---

## Key Features & Capabilities
* Build and publish application artifacts for deployment.  
* Build Docker images and perform security scanning using Wiz.  
* Push Docker images to Amazon ECR and deploy workloads to AWS EKS clusters.  
* Support multi‑environment (source → target) deployments and promote images/manifests across environments (e.g., dev → qa, qa → prod).  
* Provide secure authentication using AWS OIDC and integrate CyberArk Conjur for runtime secret management (**optional**).  
* Allow configuration of Kubernetes resources such as Secrets, ConfigMaps, and Service Accounts.  
* Deploy framework‑based applications (e.g., .NET, Angular, **Python**, node/yarn) to AWS EKS.  
* Validate Kubernetes manifests before deployment to ensure correctness.  
* Store sensitive values in GitHub Secrets, while retrieving runtime secrets from Conjur (optional).  
* Use digest‑based deployments for immutable and secure image references.  
* Matrix support for ECR push and EKS deploy across multiple accounts/regions via `ecr-matrix-config` and `deploy-matrix-config`.  
* Select target container registry via `registry` input (`ecr` default supported via image tagging action).

> [!TIP]
> It's recommended to begin with just a single environment (the source), since the workflow fully supports operating with only the source environment. You can add and configure the target environment later when needed.

> [!NOTE]
> Conjur is **optional** and can be used as the source of truth for secrets. Our reusable workflows support both Conjur and GitHub Secrets so teams can transition at their own pace.  
> Use `conjur-variable-json` to fetch secrets from Conjur, and use `secrets-json` to retrieve secrets from GitHub environment secrets. The mock examples demonstrate both approaches.

---

## Prerequisites

- An active AWS EKS cluster, cluster-name, region  
- ECR repository with proper push/pull permissions configured  
- k8s namespace for the application  
- Proper RBAC permissions for the service account in that namespace  
- **Source** account: `source-aws-account-id`, `source-oidc-assume-role`, `source-role-session-name`  
- **Target ECR** account (if promoting images): `target-ecr-aws-account-id`, `target-ecr-oidc-assume-role`, `target-ecr-role-session-name`  
- **Target EKS** account (if deploying to target): `target-eks-aws-account-id`, `target-eks-oidc-assume-role`, `target-eks-role-session-name`  
- GitHub → AWS IAM OIDC provider is configured
  
> [!IMPORTANT]
> Before using this reusable workflow to deploy an application to AWS Elastic Kubernetes Service (EKS), ensure the following prerequisites are met for both the source and target AWS accounts.  
> Please coordinate with the IAC team to obtain all required infrastructure details before attempting to use our reusable workflow, as the infrastructure setup must always be completed first.
> 
---
 
## Usage
#### Example: Deploy Application to AWS EKS (.NET)
```yaml
uses: BHGitOps/workflow-aws-eks/.github/workflows/workflow.yml@v4
with:
  framework-type: "dotnet"
  working-directory: "src/"
  file-name-to-build: "MyApp.sln"
  file-name-to-publish: "MyApp.csproj"
  image-tag: "latest"
  docker-file-path: "Dockerfile"
  docker-build-context: "."
  build-runner: "ubuntu-latest"
secrets:
  # Azure (optional, only if using Azure Artifacts/NuGet)
  client-id: ${{ secrets.CLIENT_ID }}
  tenant-id: ${{ secrets.TENANT_ID }}
  subscription-id: ${{ secrets.SUBSCRIPTION_ID }}

  # Wiz (can be provided here or via Conjur mapping)
  wiz-client-id: ${{ secrets.WIZ_CLIENT_ID_V1 }}
  wiz-client-secret: ${{ secrets.WIZ_CLIENT_SECRET_V1 }}
```

#### Example: Matrix promotion & deploy
Provide JSON strings to run **ECR pushes** and **EKS deploys** across multiple targets.
```yaml
ecr-matrix-config: |
  [
    {
      "target-ecr-aws-region": "us-west-2",
      "target-ecr-aws-account-id": "222222222222",
      "target-ecr-container-repository": "repo-west",
      "target-ecr-oidc-assume-role": "arn:aws:iam::222222222222:role/github-oidc-role-ecr",
      "target-ecr-role-session-name": "qa-ecr-session"
    }
  ]

deploy-matrix-config: |
  [
    {
      "target-eks-aws-region": "us-west-2",
      "target-eks-aws-account-id": "222222222222",
      "target-cluster-name": "eks-target",
      "target-namespace": "qa",
      "target-deployment-file": "k8s/target-deploy.yaml",
      "target-eks-oidc-assume-role": "arn:aws:iam::222222222222:role/github-oidc-role-eks",
      "target-eks-role-session-name": "qa-eks-session",
      "target-ecr-container-repository": "repo-west",
      "target-service-account-role": "arn:aws:iam::222222222222:role/eks-sa-role"
    }
  ]
```
 
---
 
## Inputs
| Name | Description | Required | Type | Default |
|------------|-------------| :----------: |------|---------|
| `build-runner` | Github runner where the build job gets executed | ❌ | string | ubuntu-latest |
| `docker-runner` | Runner where the docker build job gets executed | ✅ | string | [**Refer GitHub Reusable Workflowᵈ¹**](#Resources) |
| `deploy-runner-type` | Runner where the deployment job gets executed | ✅ | string | [**Refer GitHub Reusable Workflowᵈ¹**](#Resources) |
| `build-environment` | Build job environment | ❌ | string | dev |
| `framework-type` | Type of framework used to build and deploy code | ❌ | string | - |
| `framework-version` | Version of the framework to install | ❌ | string | - |
| `yarn-version` | Specific Yarn version to install and activate | ❌ | string | - |
| `working-directory` | Path to the working directory containing the application | ❌ | string | - |
| `dependency-version` | Version of the dependency package to install | ❌ | string | - |
| `file-name-to-restore` | Specific filename (e.g., .sln or .csproj) to restore | ❌ | string | - |
| `nuget-config-path` | Path to the NuGet configuration file | ❌*² | string | - |
| `configuration` | Build configuration (Debug/Release) | ❌ | string | - |
| `file-name-to-build` | Solution or project file to build for .NET apps | ❌ | string | - |
| `file-name-to-publish` | Path to the csproj file to publish the project | ❌ | string | - |
| `build-artifacts` | Output directory for build artifacts | ❌ | string | output/ |
| `artifact-name` | Artifact name for uploaded build files | ❌ | string | build-artifacts |
| `image-name` | Docker image artifact name | ❌ | string | docker-image |
| `image-tag` | Docker tag to use (e.g., latest) | ✅ | string | - |
| `policy-name` | Security policy name for image scanning | ❌ | string | - |
| `project-id` | Project ID for image scanning/reporting | ❌ | string | - |
| `source-deployment-file` | Path to source Kubernetes deployment YAML | ❌ | string | - |
| `target-deployment-file` | Path to target Kubernetes deployment YAML | ❌ | string | - |
| `package-source-org` | GitHub/Azure DevOps org for package publishing | ❌ | string | BHGitOps |
| `target-file` | Target file to overwrite with environment secrets | ❌ | string | - |
| `external-ip-service-name` | Name of the Kubernetes service/ingress to extract IP | ❌ | string | - |
| `external-ip-service-namespace` | Namespace of the service | ❌ | string | default |
| `external-ip-service-type` | Resource type (service/ingress) | ❌ | string | service |
| `external-ip-wait-seconds` | Max wait time for IP assignment | ❌ | string | 300 |
| `secret-name` | Kubernetes secret name | ❌ | string | - |
| `vars-json` | Environment variables in JSON format | ❌ | string | - |
| `vars-name` | Comma-separated list of variable names for ConfigMap | ❌ | string | - |
| `configmap-name` | Kubernetes ConfigMap name | ❌ | string | - |
| `service-account-name` | Kubernetes service account name | ❌ | string | - |
| `docker-file-path` | Path to Dockerfile | ❌ | string | - |
| `docker-build-context` | Docker build context path | ❌ | string | - |
| `package-source` | NuGet package source | ❌ | string | azure-artifacts |
| `nginx-repository` | NGINX ECR repository name | ❌ | string | - |
| `nginx-tag` | NGINX image tag | ❌ | string | - |
| `registry` | Target registry: 'ecr' | ❌ | string | ecr |
| `source-aws-region` 🌎 | Source AWS region | ❌ | string | us-west-2 |
| `target-eks-aws-region` 🌎 | Target AWS region for EKS | ❌ | string | us-west-2 |
| `target-ecr-aws-region` 🌎 | Target AWS region for ECR | ❌ | string | us-west-2 |
| `source-container-repository` 📦 | Source ECR repo | ❌ | string | - |
| `target-ecr-container-repository` 📦 | Target ECR repo | ❌ | string | - |
| `source-namespace` | Source Kubernetes namespace | ❌ | string | - |
| `target-namespace` | Target Kubernetes namespace | ❌ | string | - |
| `source-cluster-name` ☸️ | Name of the source EKS cluster | ❌ | string | - |
| `target-cluster-name` ☸️ | Name of the target EKS cluster | ❌ | string | - |
| `source-configmap-file-path` | File for source ConfigMap variables | ❌ | string | - |
| `target-configmap-file-path` | File for target ConfigMap variables | ❌ | string | - |
| `artifact-download-path` | Artifact download destination | ❌ | string | . |
| `source-environment` | Source deployment environment | ❌ | string | - |
| `target-environment` | Target deployment environment | ❌ | string | - |
| `source-aws-account-id` | Source AWS account ID | ❌ | string | - |
| `target-eks-aws-account-id` | Target AWS account ID of EKS | ❌ | string | - |
| `target-ecr-aws-account-id` | Target AWS account ID of ECR | ❌ | string | - |
| `source-role-session-name` | Role session name (source) | ❌ | string | - |
| `target-eks-role-session-name` | Role session name of EKS (target) | ❌ | string | - |
| `target-ecr-role-session-name` | Role session name of ECR (target) | ❌ | string | - |
| `source-oidc-assume-role` | Source OIDC assume role | ❌ | string | - |
| `target-ecr-oidc-assume-role` | Target OIDC assume role of ECR | ❌ | string | - |
| `target-eks-oidc-assume-role` | Target OIDC assume role of EKS | ❌ | string | - |
| `source-service-account-role` | Source service account role | ❌ | string | - |
| `target-service-account-role` | Target service account role | ❌ | string | - |
| `nginx-aws-account-id` | AWS account ID for NGINX deployment | ❌ | string | - |
| `image-artifact` | Name of the image artifact | ❌ | string | image.tar |
| `include-super-linter` | Enable or disable linting | ❌ | boolean | false |
| `linter-filter-regex-include` | Regex include filter for linting | ❌ | string | - |
| `linter-filter-regex-exclude` | Regex exclude filter for linting | ❌ | string | - |
| `linter-rules-config-path` | Path to linter config files | ❌ | string | - |
| `submodules` | Enable submodules with token | ❌ | boolean | false |
| `repositories-owner` | GitHub org/user owning repositories | ❌ | string | BHGitOps |
| `repositories` | Repositories requiring GitHub App token | ❌ | string | - |
| `skip-build-job` | Skip the application‑specific build phase and rely solely on Docker image builds for deploying to EKS | ❌ | boolean | false |
| `skip-deploy-job` | Skip the deployment job | ❌ | boolean | false |
| `skip-ecr-push` | Skip ECR push job | ❌ | boolean | false |
| `skip-docker-build` | Skip Docker build job | ❌ | boolean | false |
| `skip-clean` | Set false to perform clean build | ❌ | boolean | false |
| `secrets-keys` | Keys to include in K8s secret | ❌ | string | - |
| `conjur-variable-json` | JSON mapping of Conjur safe/secret to env var names | ❌*¹ | string | - |
| `azure-org` | Azure DevOps org name | ❌ | string | Bannerhealth |
| `azure-feed` | Azure Artifacts feed name | ❌ | string | - |
| `package-source-name` | Alias for NuGet source | ❌ | string | Azure |
| `azure-user-name` | Azure Artifacts username | ❌ | string | AzureDevOps |
| `azure-pat` | Azure DevOps PAT | ❌ | string | - |
| `retag-image` | Whether to retag Docker image | ❌ | boolean | true |
| `ecr-matrix-config` | JSON configuration for matrix-based ECR push | ❌ | string | '' |
| `deploy-matrix-config` | JSON configuration for matrix-based deploy | ❌ | string | '' |

> [!NOTE]
> For Docker-Build inputs related to pulling base images from a private Amazon ECR repository, refer to the [**Private ECR Docker Build Guide**](docs/common/private-ecr-docker-build-readme.md).

```yaml
*¹ Example for retrieving Wiz credentials via Conjur (optional). Define Conjur variables that map to environment variable names used by the workflow:
conjur-variable-json: |
  {
    "CApp_GitOrgSecrets": {
      "GitHub-WIZ_CLIENT_ID": "WIZ_CLIENT_ID_V1",
      "GitHub-WIZ_CLIENT_SECRET": "WIZ_CLIENT_SECRET_V1"
    }
  }
```

> [!NOTE]
> *ⁿᵘᵍᵉᵗ⁻ᶜᵒⁿᶠᶦᵍ⁻ᵖᵃᵗʰ - In Banner, Azure DevOps Artifacts serves as our organization’s internal package manager, enabling teams to store, manage, and share common packages used across applications. We maintain two Azure Artifacts feeds **bh-dbt-azure-greenfield-feed** and **bh-dbt-azure-feed** where most shared application packages are published.  
> Our reusable pipelines support restoring dependencies directly from these feeds, with the configuration defined in the nuget.config file, which specifies the sources to pull packages from. For implementation guidance, refer to the examples provided in our mock repository.

---
 
## Secrets
| Name | Description | Required | Type | Default |
|------|-------------| :----------: |------|---------|
| `client-id` | Client ID of the Azure Service Principal used for authentication | ❌*¹ | string | - |
| `tenant-id` | Azure Active Directory Tenant ID associated with the Service Principal | ❌*¹ | string | - |
| `subscription-id` | Azure Subscription ID under which the authentication and resource access occur | ❌*¹ | string | - |
| `conjur-appliance-url` | CyberArk Conjur Appliance URL. The default value is vars.CONJUR_APPLIANCE_URL, which should be specified in the application caller workflow | ❌*² | string | vars.CONJUR_APPLIANCE_URL |
| `conjur-account` | CyberArk Conjur Account. The default value is vars.CONJUR_ACCOUNT, which should be specified in the application caller workflow | ❌*² | string | vars.CONJUR_ACCOUNT |
| `source-conjur-workload-id` | Conjur workload ID for source environment | ❌*² | string | - |
| `source-conjur-api-key` | API key for source Conjur workload | ❌*² | string | - |
| `target-conjur-workload-id` | Conjur workload ID for target environment | ❌*² | string | - |
| `target-conjur-api-key` | API key for target Conjur workload | ❌*² | string | - |
| `secrets-json` | GitHub environment secrets are provided in JSON format, which can be exported for JSON transformation or used to create a generic Kubernetes Secret | ❌ | string | - |
| `github-token` | GitHub token used for authentication when accessing GitHub Packages | ❌ | string | - |
| `gh-app-id` | GitHub App ID used for authentication and token generation. Required when Git submodules are used | ❌*³ | string | - |
| `gh-app-private-key` | Private key for the GitHub App, used to authenticate and generate tokens. Required when Git submodules are used | ❌*³ | string | - |
| `wiz-client-id` | Wiz Client ID used for image security scanning | ❌*⁴ | string | - |
| `wiz-client-secret` | Wiz Client Secret used for image security scanning | ❌*⁴ | string | - |

*¹ - These authentication parameters (client-id, tenant-id, and subscription-id) are used to log into Azure through a Service Principal. Once authenticated, the system uses this identity to securely access Azure DevOps and retrieve the required packages. This ensures that all interactions with Azure resources and DevOps artifacts follow role‑based access controls and comply with your subscription’s security policies. 

*² - Conjur usage is **optional**. Provide these only if your application retrieves secrets from Conjur or if you choose to supply Wiz credentials via Conjur. Otherwise, use GitHub Secrets.

*³ - These inputs are required only when Git submodules are used and can be ignored if your workflow does not utilize submodules.

*⁴ - Provide Wiz credentials either directly in GitHub Secrets (`wiz-client-id`, `wiz-client-secret`) **or** via Conjur using `conjur-variable-json` mapping (see Inputs section). At least one source must be provided for image scanning to run.

> [!CAUTION]
> It is the responsibility of the application team to securely manage all secrets, whether stored in Conjur or GitHub Secrets. Secrets must never be logged, exposed, or configured in a way that could cause them to appear in application logs.  
> If a secret is suspected to be leaked or compromised in any way, it must be reported immediately and rotated without delay.

---
 
## Jobs & Steps
- Build ➡️→ Docker Build ➡️→ ECR Push (Source) ➡️→ Deploy EKS (Source) ➡️→ ECR Push (Target) ➡️→ Deploy EKS (Target).
    
### **1. Build** 🛠️
The Build job compiles the application from source code, restores dependencies, authenticates package sources, applies transformations, and prepares a publish-ready artifact.

> **Python note:** When `framework-type: python`, the Build job **skips** framework/tool restore, Azure login/NuGet, and artifact upload. Python apps typically proceed directly to the Docker Build job using your `Dockerfile`.

| Action Name | Purpose |
|-------------|---------|
| [**action-generate-github-app-token**](https://github.com/BHGitOps/action-generate-github-app-token) | Generates a GitHub App installation token that can be used to access private repositories or submodules in your workflows. (optional when using submodules) |
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checkout repository (optionally with Super Linter) |
| [**action-docker-setup**](https://github.com/BHGitOps/action-docker-setup) | Sets up Docker and prepares the environment for container-based workflows |
| [**action-setup-framework**](https://github.com/BHGitOps/action-setup-framework) | Installs and configures the required development framework and dependency manager |
| [**action-setup-dependency**](https://github.com/BHGitOps/action-setup-dependency) | Installs project‑specific dependencies needed for the build |
| [**action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Logs into Azure and optionally authorizes NuGet when using Azure Artifacts |
| [**action-azure-devops-access-token**](https://github.com/BHGitOps/action-azure-devops-access-token) | Generates an Azure DevOps access token for secure operations |
| [**action-authorize-nuget-restore**](https://github.com/BHGitOps/action-authorize-nuget-restore) | Authorizes NuGet restore, typically for private or authenticated azure devops feeds |
| [**action-restore-dependencies**](https://github.com/BHGitOps/action-restore-dependencies) | Restores dependencies required for the application build |
| [**action-clean**](https://github.com/BHGitOps/action-clean) | Cleans the project output or environment before building |
| [**action-json-transform**](https://github.com/BHGitOps/action-json-transform) | Performs JSON transformations (optional step for dynamic config) |
| [**action-build**](https://github.com/BHGitOps/action-build) | Builds the application based on its framework typ |
| [**action-publish**](https://github.com/BHGitOps/action-publish) | Publishes build output based on the framework type |
| [**action-upload-artifacts**](https://github.com/BHGitOps/action-upload-artifacts) | Uploads build artifacts for later workflow stages |

### 2. Docker Build 🐳
This job converts the build output into a Docker image, scans it for security vulnerabilities, and produces an image artifact.
  
> **Python note:** For Python projects, this job builds directly from your source using the provided `Dockerfile`. The artifact download step is skipped.

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checks out the repository to prepare for the Docker build workflow. |
| [**action-download-artifact**](https://github.com/BHGitOps/action-download-artifact) | Downloads previously generated build artifacts needed for image creation. |
| [**action-docker-setup**](https://github.com/BHGitOps/action-docker-setup) | Sets up Docker and prepares the runner for image build operations. |
| [**action-container-build**](https://github.com/BHGitOps/action-container-build) | Builds the Docker image using the specified Dockerfile and build context. |
| [**action-conjur-fetch-secrets**](https://github.com/BHGitOps/action-conjur-fetch-secrets) | Retrieves secrets from CyberArk Conjur for secure build-time use. (optional) |
| [**action-wiz-setup**](https://github.com/BHGitOps/action-wiz-setup) | Installs and configures the Wiz CLI for image security scanning. |
| [**action-container-scan**](https://github.com/BHGitOps/action-container-scan) | Runs Wiz security scanning on the built Docker image. |
| [**action-docker-save-image**](https://github.com/BHGitOps/action-docker-save-image) | Saves the Docker image into a tarball format for later consumption or upload. |
| [**action-upload-artifacts**](https://github.com/BHGitOps/action-upload-artifacts) | Uploads the generated Docker image tar or other artifacts. |
| [**action-docker-cleanup-images**](https://github.com/BHGitOps/action-docker-cleanup-images) | Cleans up Docker images to free runner space. |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Cleans remaining artifacts from the runner at the end of the job. |

### 3. ECR Push (Source) 📦
Pushes the built Docker image from the pipeline into the Source AWS Account’s ECR registry.

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checks out the repository for the ECR push workflow. |
| [**action-download-artifact**](https://github.com/BHGitOps/action-download-artifact) | Downloads the previously built image artifact (e.g., the saved tar). |
| [**action-docker-setup**](https://github.com/BHGitOps/action-docker-setup) | Sets up Docker on the runner for image operations. |
| [**action-docker-tag-image**](https://github.com/BHGitOps/action-docker-tag-image) | Loads the saved image and applies the proper ECR repository tag(s). |
| [**action-configure-aws-credentials**](https://github.com/BHGitOps/action-configure-aws-credentials) | Configures AWS credentials via OIDC and assumes the specified role. |
| [**action-install-aws-cli**](https://github.com/BHGitOps/action-install-aws-cli) | Installs the AWS CLI for ECR and registry operations. |
| [**action-ecr-login**](https://github.com/BHGitOps/action-ecr-login) | Authenticates the Docker client to the Amazon ECR registry. |
| [**action-ecr-push**](https://github.com/BHGitOps/action-ecr-push) | Pushes the tagged Docker image to the specified Amazon ECR repository. |
| [**action-docker-cleanup-images**](https://github.com/BHGitOps/action-docker-cleanup-images) | Cleans up local Docker images to free runner space. |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Performs final runner cleanup (artifacts/temp files), always runs. |

### 4. Deploy EKS (Source) ☸️
Deploys the image stored in Source ECR into the Source AWS EKS cluster. Also handles secret creation, configmaps, image scanning, and environment provisioning.

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checks out the repository to load deployment manifests and configuration. |
| [**action-docker-setup**](https://github.com/BHGitOps/action-docker-setup) | Sets up Docker for handling container images on the runner. |
| [**action-configure-aws-credentials**](https://github.com/BHGitOps/action-configure-aws-credentials) | Configures AWS credentials using OIDC and assumes the required IAM role. |
| [**action-install-aws-cli**](https://github.com/BHGitOps/action-install-aws-cli) | Installs the AWS CLI to interact with ECR, EKS, and other AWS services. |
| [**action-ecr-login**](https://github.com/BHGitOps/action-ecr-login) | Logs into Amazon ECR to allow pulling images securely. |
| [**action-ecr-pull**](https://github.com/BHGitOps/action-ecr-pull) | Pulls the specified Docker image from Amazon ECR. |
| [**action-get-image-digest**](https://github.com/BHGitOps/action-get-image-digest) | Retrieves the SHA256 digest of the container image for EKS deployment. |
| [**action-conjur-fetch-secrets**](https://github.com/BHGitOps/action-conjur-fetch-secrets) | Fetches secrets from CyberArk Conjur for Kubernetes deployment usage. (optional) |
| [**action-wiz-setup**](https://github.com/BHGitOps/action-wiz-setup) | Sets up the Wiz CLI for security scanning. |
| [**action-container-scan**](https://github.com/BHGitOps/action-container-scan) | Performs Wiz container scanning using image tag and digest. |
| [**action-install-kubectl**](https://github.com/BHGitOps/action-install-kubectl) | Installs kubectl to interact with the Kubernetes cluster. |
| [**action-authenticate-eks**](https://github.com/BHGitOps/action-authenticate-eks) | Authenticates to the AWS EKS cluster. |
| [**action-gh-secrets-to-k8s**](https://github.com/BHGitOps/action-gh-secrets-to-k8s) | Creates Kubernetes secrets using GitHub‑stored JSON secrets. |
| [**action-conjur-k8s-secret**](https://github.com/BHGitOps/action-conjur-k8s-secret) | Creates Kubernetes generic secrets using values sourced from Conjur. |
| [**action-create-k8s-configmaps**](https://github.com/BHGitOps/action-create-k8s-configmaps) | Creates ConfigMaps using files or variables. |
| [**action-create-k8s-service-account**](https://github.com/BHGitOps/action-create-k8s-service-account) | Provisions a Kubernetes service account with IAM role mappings. |
| [**action-aws-eks-deploy**](https://github.com/BHGitOps/action-aws-eks-deploy) | Deploys application workloads to EKS using Kubernetes manifests. |
| [**action-k8s-external-ip**](https://github.com/BHGitOps/action-k8s-external-ip) | Extracts the external IP from a Kubernetes service. |
| [**action-docker-tag-image**](https://github.com/BHGitOps/action-docker-tag-image) | Re‑tags the image for additional processing or promotion. |
| [**action-docker-save-image**](https://github.com/BHGitOps/action-docker-save-image) | Saves the Docker image as a .tar file for artifact storage. |
| [**action-upload-artifacts**](https://github.com/BHGitOps/action-upload-artifacts) | Uploads image tarballs and other build/deploy artifacts. |
| [**action-docker-cleanup-images**](https://github.com/BHGitOps/action-docker-cleanup-images) | Cleans up Docker images from the runner to save space. |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Performs final cleanup of runner artifacts and temporary files. |
 
### 5. ECR Push (Target) 📦
This job takes the Source image and pushes it into the Target AWS Account’s ECR registry, enabling cross-account promotion. Supports **matrix** runs via `ecr-matrix-config`.

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checks out the repository to prepare for the target‑environment ECR push. |
| [**action-download-artifact**](https://github.com/BHGitOps/action-download-artifact) | Downloads the previously uploaded image artifact from the source environment. |
| [**action-docker-setup**](https://github.com/BHGitOps/action-docker-setup) | Sets up Docker to load, tag, and push container images. |
| [**action-docker-tag-image**](https://github.com/BHGitOps/action-docker-tag-image) | Loads the image tar and applies the target repository tag. |
| [**action-configure-aws-credentials**](https://github.com/BHGitOps/action-configure-aws-credentials) | Configures AWS credentials via OIDC for the target AWS account. |
| [**action-install-aws-cli**](https://github.com/BHGitOps/action-install-aws-cli) | Installs the AWS CLI to interact with AWS services, including ECR. |
| [**action-ecr-login**](https://github.com/BHGitOps/action-ecr-login) | Logs in to Amazon ECR in the target AWS account. |
| [**action-ecr-push**](https://github.com/BHGitOps/action-ecr-push) | Pushes the Docker image to the target account’s ECR repository. |
| [**action-docker-cleanup-images**](https://github.com/BHGitOps/action-docker-cleanup-images) | Removes local Docker images to free runner disk space. |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Performs final cleanup of temporary files and artifacts on the runner. |

### 6. Deploy EKS (Target) ☸️
Deploys the image from Target ECR into the Target AWS EKS cluster, performing final production/stage deployment steps. Supports **matrix** runs via `deploy-matrix-config`.

| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checks out the repository to load deployment configuration for the target environment. |
| [**action-docker-setup**](https://github.com/BHGitOps/action-docker-setup) | Sets up Docker on the runner to work with images pulled from ECR. |
| [**action-configure-aws-credentials**](https://github.com/BHGitOps/action-configure-aws-credentials) | Configures AWS credentials using OIDC and assumes the target IAM role. |
| [**action-install-aws-cli**](https://github.com/BHGitOps/action-install-aws-cli) | Installs the AWS CLI for interacting with ECR, EKS, and other AWS services. |
| [**action-ecr-login**](https://github.com/BHGitOps/action-ecr-login) | Logs into Amazon ECR in the target AWS account. |
| [**action-ecr-pull**](https://github.com/BHGitOps/action-ecr-pull) | Pulls the specified Docker image from the target ECR repository. |
| [**action-get-image-digest**](https://github.com/BHGitOps/action-get-image-digest) | Retrieves the SHA digest of the container image for secure deployment. |
| [**action-conjur-fetch-secrets**](https://github.com/BHGitOps/action-conjur-fetch-secrets) | Fetches deployment secrets from CyberArk Conjur for the target environment. (optional) |
| [**action-wiz-setup**](https://github.com/BHGitOps/action-wiz-setup) | Installs and configures the Wiz CLI for image scanning. |
| [**action-container-scan**](https://github.com/BHGitOps/action-container-scan) | Performs Wiz vulnerability scanning using the image tag and digest. |
| [**action-install-kubectl**](https://github.com/BHGitOps/action-install-kubectl) | Installs kubectl to interact with the Kubernetes cluster. |
| [**action-authenticate-eks**](https://github.com/BHGitOps/action-authenticate-eks) | Authenticates the runner to the target AWS EKS cluster. |
| [**action-gh-secrets-to-k8s**](https://github.com/BHGitOps/action-gh-secrets-to-k8s) | Creates Kubernetes secrets using GitHub Secrets JSON. |
| [**action-conjur-k8s-secret**](https://github.com/BHGitOps/action-conjur-k8s-secret) | Creates Kubernetes secrets using keys stored in CyberArk Conjur. |
| [**action-create-k8s-configmaps**](https://github.com/BHGitOps/action-create-k8s-configmaps) | Creates Kubernetes ConfigMaps from variables or file inputs. |
| [**action-create-k8s-service-account**](https://github.com/BHGitOps/action-create-k8s-service-account) | Creates a Kubernetes ServiceAccount with IAM roles attached. |
| [**action-aws-eks-deploy**](https://github.com/BHGitOps/action-aws-eks-deploy) | Deploys workloads to the target EKS cluster using Kubernetes manifests. |
| [**action-k8s-external-ip**](https://github.com/BHGitOps/action-k8s-external-ip) | Extracts the external IP address from a Kubernetes service. |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Performs final cleanup of temporary files and artifacts on the runner. |

---

## Changelog 📝

| Version | Date       | Tags                                                                 | Changes |
|:--------:|:------------|----------------------------------------------------------------------|---------|
| **v5.3.0**  | 2026-06-09 | Docker-Build private ECR enhancement | - **Added:** Private ECR Docker Build guide and README references <br>- **Added:** Runner guidance for private ECR Docker builds |
| **v5**  | 2026-04-02 | skip-build-job | - **Added:** skip-build-job parameter to bypass the application‑specific build phase |
| **v4**  | 2026-02-23 | Python support, Wiz Upgrade | - **Added:** Python container-first path (skip framework build; build in Docker) <br>- **Added:** `wiz-client-id` and `wiz-client-secret` to Secrets section <br>- |
| **v3**  | 2026-02-23 | High Availability, Conjur, registry selector | **Added:** `ecr-matrix-config` and `deploy-matrix-config` for multi-target promotion/deploy <br>- **Added:** `yarn-version` input <br>- **Added:** `registry` input (ECR default) <br>- **Changed:** Conjur now **optional** across jobs <br>-  **Enhanced:** Split target roles/regions into `target-ecr-*` and `target-eks-*` <br>- **Enhanced:** Image re-tagging control (`retag-image`, default true) |
| **v2**  | 2025-10-10 | Multi-environment deployment, artifact improvements                   | - **Added:** Source-target deployment pattern and promotion artifacts<br>- **Improved:** Image scanning and artifact handling |
| **v1**  | 2025-06-10 | Initial Release                                                       | - **Added:** Basic EKS deployment workflow with Docker build and ECR push |

---
## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>
  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1613332521/workflow-aws-eks+v2+Reusable+CI+CD+Workflow+for+AWS+EKS+Deployment">Workflow-aws-eksᵈ²</a>
    </strong>
    <p>
      Workflow-aws-eks - Reusable GitHub workflow building and deploying applications to AWS EKS
    </p>
  </article>  

---

## Feedback/Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
