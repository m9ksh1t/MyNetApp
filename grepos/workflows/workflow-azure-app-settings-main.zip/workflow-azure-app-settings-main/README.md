<h1 align="center">workflow-azure-app-settings</h1>

## Overview
This repository provides a reusable GitHub workflow for securely managing **Azure App Service configuration**, including:

- App Settings  
- Connection Strings  
- JSON-based configuration transformations  
- Secret retrieval from CyberArk Conjur  
- Updates from GitHub Secrets and GitHub Variables  

The workflow supports Azure Web Apps, Function Apps, and Static Web Apps, ensuring a unified and secure configuration strategy across multiple Azure application types.

---

## Getting Started
These documents will help you get up to speed with our engineering practices and tools.

---

## Reusable Workflow Summary

| • Workflow Name | workflow-azure-app-settings |
|-----------------|-----------------------------|
| • **Latest Stable Version** | v3 |
| • **Current Version** | v3 |
| • **Cloud Environment** | Azure |
| • **Cloud Services** | App Services, Function Apps, Static Web Apps |
| • **Tech Stacks** | .NET, Node.js, Java, Python, any runtime supported by App Services |
| • **Is Conjur integrated** | Yes*¹ |

*¹ This workflow integrates with **CyberArk Conjur** to securely fetch sensitive application values such as connection strings, API keys, and secret variables before updating Azure App Settings.

---

## Mock Caller Repositories

| Mock Repository URL | Purpose | Technology Stack |
|---------------------|----------|------------------|
| [**mock-azure-app-settings**](https://github.com/BHGitOps/mock-azure-app-settings) | Demonstrates updating App Settings, Connection Strings, and JSON transformations using this reusable workflow | Any |

---

## Key Features & Capabilities
* Transform JSON configuration files with GitHub Secrets/Variables and Conjur secrets.
* Update Azure App Settings using:
  - Transformed JSON template files  
  - Raw JSON configuration files  
  - GitHub Secrets (JSON format)  
  - GitHub Variables  
  - CyberArk Conjur secrets  
* Add, update, and delete Connection Strings.
* Delete existing Azure App Settings.
* Supports Azure Web Apps, Function Apps, and Static Web Apps.
* Secure authentication using Azure Service Principals.
* Clean runner workspace to remove temporary sensitive files.
* Consistent multi-environment configuration support (dev → qa → prod).

> [!TIP]  
> Start with **JSON file–based configuration updates**. This workflow fully supports template-based app configuration and Conjur-based overrides.

> [!NOTE]  
> Conjur is strongly recommended as the primary source of truth for sensitive application configuration. Use `conjur-variable-json` to securely fetch secrets and apply them to Azure App Settings.

---

## Prerequisites

### Azure Requirements
- Azure App Service / Function App / Static Web App must already exist.
- Azure Resource Group name.
- Azure Service Principal with Contributor or App Configuration write permissions.
- Properly exported secrets in GitHub Secrets if using `secrets-json`.

### Conjur Requirements
- Conjur Appliance URL
- Conjur Account
- Conjur Workload ID & API Key
- Valid `conjur-variable-json` mapping

> [!IMPORTANT]  
> Always coordinate with the Infrastructure or Cloud Engineering team to ensure that Azure resources and Conjur workload identities are fully set up before running this reusable workflow.

---

## Usage

### Example: Update Azure App Settings from Transformed JSON File

```yaml
uses: BHGitOps/workflow-azure-app-settings/.github/workflows/workflow.yml@v3
with:
  deploy-environment: dev
  deploy-runner-type: azure
  cloud-app-name: sample-webapp
  deployment-resource-type: azure-web-app
  json-transform-file-path: "config/appsettings.template.json"
  vars-json: |
    { "ENV": "dev" }
  update-appsettings-from-transformed-file: true
secrets:
  client-id: ${{ secrets.AZURE_CLIENT_ID }}
  tenant-id: ${{ secrets.AZURE_TENANT_ID }}
  subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}
  secrets-json: ${{ secrets.APP_SETTINGS_JSON }}
```

### Example: Update Azure App Settings Using Conjur Secrets

```yaml
uses: BHGitOps/workflow-azure-app-settings/.github/workflows/workflow.yml@v3
with:
  deploy-runner-type: azure
  cloud-app-name: sample-func-app
  deployment-resource-type: azure-function-app
  conjur-variable-json: |
    {
      "SAFE_NAME": {
        "DB_PASSWORD": "path/to/password",
        "API_KEY": "path/to/api-key"
      }
    }
  conjur-secret-to-azure-appsettings: true
secrets:
  conjur-appliance-url: ${{ secrets.CONJUR_APPLIANCE_URL }}
  conjur-account: ${{ secrets.CONJUR_ACCOUNT }}
  conjur-workload-id: ${{ secrets.CONJUR_WORKLOAD_ID }}
  conjur-api-key: ${{ secrets.CONJUR_API_KEY }}
  client-id: ${{ secrets.AZURE_CLIENT_ID }}
  tenant-id: ${{ secrets.AZURE_TENANT_ID }}
  subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}
```

---

## Inputs

| Name | Description | Required | Type | Default |
|------|-------------|----------|-------|---------|
| `cloud-app-name` | Name of the Azure resource (Web App, Function App, Static Web App) | ❌ | string | - |
| `deployment-resource-type` | azure-web-app / azure-function-app / static-web-app | ❌ | string | - |
| `deploy-environment` | Target deployment environment | ❌ | string | - |
| `deploy-runner-type` | GitHub runner for deployment execution | ✅ | string | azure |
| `json-transform-file-path` | JSON template file path for transformation | ❌ | string | - |
| `update-appsettings-from-transformed-file` | Apply transformed JSON to Azure App Settings | ❌ | boolean | false |
| `app-settings-file-path` | JSON file for direct App Settings update | ❌ | string | - |
| `update-azure-appsettings-from-file` | Update App Settings using provided file | ❌ | boolean | false |
| `github-secret-to-azure-appsettings` | Apply App Settings using GitHub Secrets JSON | ❌ | boolean | false |
| `github-variables-to-azure-appsettings` | Apply App Settings using GitHub Variables JSON | ❌ | boolean | false |
| `delete-azure-appsettings` | Delete a specific Azure App Setting | ❌ | boolean | false |
| `app-settings-name` | App Setting key name to delete | ❌ | string | - |
| `azure-resource-group-name` | Azure Resource Group name | ❌ | string | - |
| `add-edit-connection-string` | Add or update connection string | ❌ | boolean | false |
| `update-azure-connection-string-from-file` | Bulk update connection strings from JSON file | ❌ | boolean | false |
| `delete-connection-string` | Delete a connection string | ❌ | boolean | false |
| `connection-string-name` | Name of the connection string | ❌ | string | - |
| `connection-string-value` | Value of the connection string | ❌ | string | - |
| `connection-string-type` | SQLServer / MySQL / etc. | ❌ | string | - |
| `vars-json` | JSON variables for transformation | ❌ | string | - |
| `conjur-variable-json` | JSON mapping for Conjur secret retrieval | ❌ | string | - |
| `conjur-secret-to-azure-appsettings` | Apply Conjur secrets to App Settings | ❌ | boolean | false |

---

## Secrets

| Name | Description | Required | Default |
|------|-------------|----------|---------|
| `client-id` | Azure SP Client ID | ❌*¹ | - |
| `tenant-id` | Azure Tenant ID | ❌*¹ | - |
| `subscription-id` | Azure Subscription ID | ❌*¹ | - |
| `secrets-json` | GitHub Secrets JSON string | ❌ | - |
| `conjur-appliance-url` | Conjur appliance URL | ❌*² | - |
| `conjur-account` | Conjur account name | ❌*² | - |
| `conjur-workload-id` | Conjur host workload ID | ❌*² | - |
| `conjur-api-key` | Conjur API key | ❌*² | - |

*¹ Required for Azure actions (login, app settings, connection strings).  
*² Required only if using Conjur for secret-based configuration.

> [!CAUTION]  
> Secrets must **never** be echoed or logged. Immediately rotate them if any leak is suspected.

> [!NOTE]
> A mock workflow is provided to help teams quickly understand how to implement this reusable workflow in real scenarios.

---

## Jobs & Steps
Below are the key steps executed by this workflow:

### Build 🛠️
| Action Name | Purpose |
|-------------|---------|
| [**action-checkout**](https://github.com/BHGitOps/action-checkout) | Checkout repository (optionally with Super Linter) |
| [**action-conjur-fetch-secrets**](https://github.com/BHGitOps/action-conjur-fetch-secrets) | Retrieves secrets from CyberArk Conjur for secure build-time use. |
| [**action-json-transform**](https://github.com/BHGitOps/action-json-transform) | Performs JSON transformations (optional step for dynamic config) |
| [**action-azlogin**](https://github.com/BHGitOps/action-azlogin) | Logs into Azure |
| [**action-gh-azure-app-settings**](https://github.com/BHGitOps/action-gh-azure-app-settings) | Sets or updates Azure App Settings using a JSON string or file path for key-value pairs |
| [**action-conjur-azure-app-settings**](https://github.com/BHGitOps/action-conjur-azure-app-settings) | Sets or updates Azure App Settings using a JSON string or file path for key-value pairs |
| [**action-delete-azure-appsettings**](https://github.com/BHGitOps/action-delete-azure-appsettings) | Removes a specified App Setting from an Azure Web App or Function App within a given resource group |
| [**action-azure-manage-connection-strings**](https://github.com/BHGitOps/action-azure-manage-connection-strings) | Adds or updates a connection string in an Azure Web App or Function App |
| [**action-azure-delete-connection-strings**](https://github.com/BHGitOps/action-azure-delete-connection-strings) | Checks for and deletes an existing Azure connection string from a specified Web App or Function App |
| [**action-azure-manage-connection-strings-from-json**](https://github.com/BHGitOps/action-azure-manage-connection-strings-from-json) | Adds or updates single or multiple connection strings in an Azure Web App or Function App |
| [**action-clean-runner-artifacts**](https://github.com/BHGitOps/action-clean-runner-artifacts) | Cleans remaining artifacts from the runner at the end of the job. |

---

## Changelog 📝

| Version | Date       | Tags                                               | Changes |
|:--------:|:------------|----------------------------------------------------|---------|
| **v3**  | 2026-02-04 | Conjur integration, JSON v3 support                | - **Added:** Conjur secret integration for Azure App Settings<br>- **Added:** JSON Transform v3 engine<br>- **Added:** Bulk connection string management |
| **v2**  | 2025-10-31 | App Settings + Connection Strings expansion        | - **Added:** App Setting deletion capability<br>- **Improved:** Connection string management process<br>- **Enhanced:** JSON-based configuration update handling |
| **v1**  | 2025-07-23 | Initial Release                                    | - **Added:** Basic JSON transformations<br>- **Added:** Update Azure App Settings from file |

---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>
  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1566965762/workflow-azure-app-settings+Reusable+CI+CD+Workflow+to+manage+Azure+App+Service+Environment+variables">Workflow-azure-app-settingsᵈ²</a>
    </strong>
    <p>
      Workflow-azure-app-settings - Reusable GitHub workflow for updating App Settings for azure webapps, static webapps and function apps.
    </p>
  </article>  

---

## Feedback / Need Help? 📬  
If you have questions or need assistance, don’t hesitate to reach out to your team lead or Platform Engineering Support. We're here to help you succeed!
