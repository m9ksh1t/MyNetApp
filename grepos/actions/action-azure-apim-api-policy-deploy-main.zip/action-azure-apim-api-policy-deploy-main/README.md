## API Policy Deploy Action

This GitHub Action **applies a policy to a specific API in Azure API Management (APIM)** using Azure PowerShell. It is useful for enforcing API-level policies such as authentication, rate limiting, transformation, or custom rules during CI/CD workflows.

---

## Features

- Deploys an API-specific policy to an APIM instance.
- Uses Azure PowerShell for secure and declarative policy deployment.
- Supports custom policy files in XML format.
- Allows specifying the API ID for targeted policy application.
---

## Usage

**Current Version:** `v1`

To use this action to deploy an API-specific policy to APIM:

```yml
runs:
  using: "composite"
  steps:
    - name: Update APIM API policy

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `apim-resource-group` | resource group of the azure resource | ❌ | string | No |
| `apim-service-name` | service name of the APIM | ❌ | string | No |
| `apim-api-id` | unique identifier for the API | ❌ | string | No |
| `apim-policy-source-file` | policy source file to apply policies to API | ✅ | string | Yes |

---

## Outputs

- This action does not produce explicit outputs.
- Updates the API-specific policy in the specified APIM instance.

---

## Jobs & Steps

- **Update APIM API policy**
    - Creates an APIM context using New-AzApiManagementContext.
    - Applies the API-specific policy using Set-AzApiManagementPolicy with the provided XML file and API ID.

---

## Example Scenarios

- Apply API-specific policies for authentication and authorization.
- Enforce rate limits or quotas for a specific API.
- Automate APIM policy deployment during CI/CD.

---

## Best Practices 

- **Ensure Azure PowerShell and Az modules are installed** before running this action.
- **Validate policy XML format** to avoid deployment errors.
- **Combine with Azure Login** Action for authentication.
- **Pin the action version** for stability (e.g., @v1).

---

## What The Action Does

This action:

- Connects to the specified APIM instance.
- Applies the API-specific policy from the provided XML file.
- Uses Azure PowerShell for secure and declarative deployment.

---

## 📜Changelog

[v1.0.0] - 10-20-2025

Tags: Initial Release

	•	First stable release of API Policy Deploy Action
	•	Supports APIM context creation and global policy deployment
    •	Handles XML-based policy files

---

[v1] - 10-20-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-azure-apim-api-policy-deploy`

---

## 📬 Need Help?

If you have any questions or need assistance, feel free to reach out to DevSecOps.

---

This workflow is maintained by the Banner Health DevSecOps Platform Team.