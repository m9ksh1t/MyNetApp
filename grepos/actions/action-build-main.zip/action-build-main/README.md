## Build Action

This GitHub Action **builds the source code for .NET or Angular/JavaScript, or Backstage projects**. It ensures the application is compiled according to the specified configuration before deployment or testing.

---

## Features

- Builds .NET applications using dotnet build.
- Builds Angular or JavaScript applications using npm run build:<configuration>.
- Builds Backstage applications by:
	- Generating TypeScript types (yarn tsc -b)
	- Creating the backend bundle (yarn build:backend)
- Supports specifying working directory and build configuration.

---

## Usage

**Current Version:** `v1`

To use this action to build your project:

```yml
runs:
  using: "composite"
  steps:
    - name: Build Dotnet Application
      if: ${{ inputs.framework-type == 'dotnet' }}

    - name: Build Angular application
      if: ${{ inputs.framework-type == 'angular' || inputs.framework-type == 'javascript'}}

	- name: Generate types
      if: ${{ inputs.framework-type == 'backstage' }}

	- name: Build backend bundle
      if: ${{ inputs.framework-type == 'backstage' }}

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `framework-type` | Type of framework used to build the code | ❌ | string | No |
| `working-directory` | Working directory to create build | ✅ | string | No |
| `configuration` | Specify the configuration (e.g., Release) | ✅ | string | No |
| `file-name-to-build` | Solution or project file that we will build | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It compiles the source code for the specified framework and configuration.

---

## Jobs & Steps

- **Build Dotnet Application**
- **Build angular application**
- **Generate Backstage types (yarn tsc -b)**
- **Build Backstage backend bundle (yarn build:backend)**

---

## Example Scenarios

- Build a .NET solution in Release mode before running tests.
- Build an Angular application using a custom configuration like production.
- Build a Backstage backend by first generating types and then bundling the backend.
- Use in CI/CD pipelines to prepare artifacts for deployment.

---

## Best Practices 

- **Run restore before build** using dotnet restore, npm install, or yarn install to ensure dependencies are available.
- **Pin framework versions** using actions/setup-dotnet or actions/setup-node for consistency.
- **Validate build scripts** for Angular projects (ensure npm run build:<configuration> exists in package.json).
- **Combine with caching** for dependencies to optimize build times.

---

## What The Action Does

This action:

- For .NET projects, runs dotnet build on the specified file with the given configuration and skips restore (--no-restore).
- For Angular/JavaScript projects, runs npm run build:<configuration> in the specified working directory.
- Ensures the application is compiled and ready for subsequent steps like testing or deployment.
- For Backstage projects, executes yarn tsc -b and yarn build:backend.


---

## 📜Changelog

[v1.1.1] - 2026-02-03

Tags: Backstage build support

	•	Added Backstage framework handling
	•	Supports running:
		• Generate Types using yarn tsc -b
		• Build Backend Bundle using yarn build:backend

[v1.0.0] - 06-09-2025

Tags: Initial Release

	•	First stable release of the Action Build
	•	Supports running:
	•	builds the source code for .NET or Angular/JavaScript projects
	•	With --framework-type, --working-directory, --configuration and --file-name-to-build
	•	Validates working-directory and file-name-to-build input
	•	Build .Net and Angular/JavaScript projects.

---

[v1] - 06-09-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-build`