<h1 align="center">
  <a href="action.yml">action-container-scan</a>
</h1>

## Container Image Security Scan

This GitHub Action **performs a security scan on a specified container image using Wiz CLI**. It supports scanning of container images for vulnerabilities and policy violations. It supports scanning by either full image URI (digest) or image tag, and enforces a specified Wiz policy within a designated Wiz project.

---

## Getting Started

These documents will help you get up to speed with our engineering practices and tools.

## Action Summary

The table below provides a concise overview of the GitHub Composite Action, including its name, versioning, supported cloud environments, and compatible technology stacks

| Action Name | action-container-scan |
| :------| :-------------|
| **Latest Stable Version** | v2.1.1 |
| **Current Version** | v2.1.1 |
| **Cloud Environment** | Linux-only (runs on any GitHub-hosted Linux runner) |
| **Cloud Services** | N/A |
| **TechStacks** | Any containerized workload (.NET, Angular, Node/Yarn, Python) |

---

## Jobs & Steps

- **Validate Inputs**
- **Scan Container Image with Wiz**

---

## Features
- Validates Inputs
    - Confirms that required inputs (policy-name, project-id) are provided.
    - Checks that at least one image identifier is supplied:
        - image-uri (preferred)
        - or image-tag
    - Stops execution early if policy-name or project-id are missing, or if neither image-uri nor image-tag is supplied.
- Executes Wiz Security Scan
    - If image-uri is provided:
        - Performs a container image scan using the full image URI (typically includes a digest).
        - Runs a Wiz tag operation for the scanned image.
    - If only image-tag is provided:
        - Runs a scan using the image tag (e.g., my-app:latest).
    - Scans container images for vulnerabilities using Wiz CLI.
    - Applies a custom Wiz policy during the scan.
    - Associates scans with a specific Wiz project.

---

## Usage

To use this action to scan a container image:

```yml
runs:
  using: "composite"
  steps:
    - name: Validate Inputs
    - name: Scan Container Image with Wiz

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? | Default |
|-----------------|-------------|:----------:|---------|:--------------:|:---------:|
| `policy-name`   | Wiz policy name to apply during the scan. | ✅ | string | No | - |
| `project-id`    | The Wiz project ID where the scan will be recorded. | ✅ | string | No | - |
| `image-tag`     | Image name:tag (e.g., my-image:latest). Used only if image-uri is not provided. | ❌ | string | No | - |
| `image-uri`     | Full image URI (e.g., registry.example.com/ns/app@sha256:...). If provided, takes precedence and enables tagging via wizcli tag. | ❌ | string | No | - |

---

## Outputs

- This action does not produce explicit outputs.
- It performs a Wiz CLI scan and logs results in the workflow output.

---

## Best Practices 

- **Run Wiz CLI installation and authentication** first using the Wiz CLI Download and Install action.
- **Use image digests (URI)** for immutable scans rather than tags.
- **Store Wiz credentials in GitHub Secrets** for security.
- **Fail the pipeline on critical vulnerabilities** by adding conditional checks after the scan.

---

## What The Action Does

This action:

- Checks if image-uri is provided:
    - If yes, scans using the URI and tags the image in Wiz.
    - If no, scans using the image tag.
- Applies the specified Wiz policy and associates the scan with the given project ID.

---

## 📜Changelog

| Version | Date       | Tags                                                                 | Changes |
|:--------:|:------------|----------------------------------------------------------------------|---------|
| **v2.1.1**  | 2026-06-09 | Error to Info   															| - **Enhanced:**  Handling empty parameters for "image-uri" and "image-tag" is changed from error to info |
| **v2.1.0**  | 2026-03-02 | Wiz CLI upgrade 															| - **Enhanced:**  Upgraded Wiz CLI from v0.109.1‑d13f4e6 to the v1.x series |
| **v2**  		| 2025-08-12 | ReTag                                        | - **Added:** ReTag operation for image URIs |
| **v1**  		| 2025-05-14 | Initial Release                              | - Implemented Docker image scanning using the **Wiz CLI** |

---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>

---

## Feedback/Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
