## Setup Docker

This GitHub Action **installs Docker and ensures the Docker service is running on the runner**. It is useful for workflows that require Docker for building, testing, or deploying containerized applications.

---

## Features

- Installs Docker if it is not already available on the runner.
- Starts and enables the Docker service.
- Verifies Docker installation and configuration.

---

## Usage

**Current Version:** `v1`

Use this action to install docker on runner environment and verify the docker setup.

```yaml
runs:
  using: "composite"
  steps:
    - name: Install Docker
      shell: bash

    - name: Verify Docker setup
      shell: bash
```
---

## Inputs

- This action does not require any inputs

---

## Outputs 

- This action does not produce outputs directly; it ensures Docker is installed and running.

---

## Jobs & Steps

- **Install Docker**
- **Verify Docker setup**

---

## Example Scenarios

- Prepare a runner for building Docker images in CI/CD pipelines.
- Enable Docker for workflows that run containerized tests.
- Ensure Docker is available for deployment steps requiring container operations.

---

# Best Practices

- Use this action at the beginning of workflows that depend on Docker.
- Combine with caching strategies for Docker layers to optimize build performance.
- Validate Docker installation before running container-related steps.
- Keep the runner environment updated to avoid compatibility issues.

---

## What The Action Does

This action runs a composite script that:

- Checks if Docker is installed.
- Installs Docker using apt-get if not found.
- Starts and enables the Docker service.
- Verifies installation by running docker --version and docker info.

## Repository

GITHUB: `BHGitOps/action-docker-setup`