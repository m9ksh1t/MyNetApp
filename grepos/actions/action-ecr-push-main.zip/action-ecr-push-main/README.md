## Push Docker Image to AWS ECR Action

This GitHub Action **pushes a Docker image to an Amazon Elastic Container Registry (ECR) to support containerized deployments**. It is useful for workflows that build and publish images for use in AWS-based environments.

---

## Features

- Pushes a Docker image to a specified ECR repository.
- Supports custom image tags for versioning.
- Works with authenticated Docker sessions (requires prior ECR login).

---

## Usage

**Current Version:** `v2`

To use this action to push a Docker image to ECR:

```yml
runs:
  using: "composite"
  steps:
    - name: Push Docker Image to ECR

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `aws-region` | AWS region where the ECR repository is located (e.g., us-east-1) | ❌ | string | No |
| `aws-account-id` | AWS account ID that owns the ECR repository | ❌ | string | No |
| `container-repository` | Name of the ECR repository to push the Docker image to | ✅ | string | No |
| `image-tag` | Tag to assign to the Docker image (e.g., latest, v1.0.0) | ✅ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It pushes the specified Docker image to the ECR repository.

---

## Jobs & Steps

- **Push Docker Image to ECR**
    - Executes docker push to upload the image to the specified ECR repository using the provided account ID, region, repository name, and tag.

---

## Example Scenarios

- Push a newly built Docker image to ECR for deployment in ECS or EKS.
- Publish versioned images for CI/CD pipelines.
- Store container images in ECR for later scanning or promotion.

---

## Best Practices 

- **Authenticate to ECR first** using the Container Registry Login (ECR) Action.
- **Use descriptive tags** for clarity (e.g., app:v1.0.0).
- **Pin the action version** for stability (e.g., @v2).
- **Combine with build steps** for a complete image lifecycle.

---

## What The Action Does

This action:

- Executes docker push to upload the Docker image to AWS ECR.
- Uses the provided AWS account ID, region, repository name, and image tag to construct the full image URI.

---

## 📜Changelog

[v2.0.0] - 07-24-2025

Tags: Second Release

	•	Second stable release of the  Push Docker Image to AWS ECR Action
	•	Docker image push to ECR
	•	With --aws-region, --aws-account-id, --container-repository and --image-tag
    •	Custom image tags

---

[v2] - 07-24-2025

Tags: Release Alias

	•	v2 is a moving tag pointing to the latest stable v2.x.x version (currently v2.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-ecr-push`