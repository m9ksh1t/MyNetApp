# APIM Logging Configuration

---

## Action usage and description
This action configures Application Insights diagnostic logging for an Azure API Management (APIM) API.
It supports both:

- Developer-provided configuration via JSON file
- Default/basic logging configuration when no config file is provided

Based on the inputs and optional configuration file, the action will:
- Create or update the `applicationinsights` diagnostic setting
- Delete it if diagnostics are disabled

---

## Features

- Enables or disables Application Insights diagnostics for a specific APIM API
- Supports optional configuration file
- Applies default/basic logging when config file is not provided
- Supports input-driven configuration fallback
- Uses an existing APIM logger (no logger creation)
- Configures sampling, verbosity, and frontend request/response logging
- Safely deletes diagnostics when disabled
- Validates configuration and fails fast for invalid inputs

---

## Usage

**Latest Stable/Current Version:** `v1.1.0`

To use this action in your repository:

#### Example: Configure Application Insights diagnostics for an APIM API
```yaml
- name: Configure APIM Logging (Config File)
  uses: BHGitOps/action-azure-apim-logging@v1.1.0
  with:
    apim-resource-group: "my-resource-group"
    apim-service-name: "my-apim-instance"
    apim-subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}
    apim-api-id: "my-api"
    config-file-path: "./config/apim-logging.json"

```

#### Example: Configure Application Insights diagnostics for an APIM API
```yaml
- name: Configure APIM Logging (Default)
  uses: BHGitOps/action-azure-apim-logging@v1.1.0
  with:
    apim-resource-group: "my-resource-group"
    apim-service-name: "my-apim-instance"
    apim-subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}
    apim-api-id: "my-api"
    apim-logger-name: "default-apim-logger"

```

---

### Inputs

| Name | Description | Required | Type | Is Sensitive? | Default |
|------|-------------|----------|------|---------------|---------|
| `apim-resource-group` | Azure resource group containing the API Management service | ✅ | string | No | - |
| `apim-service-name` | Name of the Azure API Management service instance | ✅ | string | No | - |
| `apim-subscription-id` | Azure Subscription ID where the APIM resources are deployed | ✅ | string | No | - |
| `apim-api-id` | Unique identifier for the API for which the diagnostic will be configured | ✅ | string | No | - |
| `config-file-path` | Path to a JSON file containing logging configuration inputs | ❌ | string | No | - |
| `apim-logger-name` | Logger name (used if not in config file) | ❌ | string | No | - |
| `enable-appinsights-diagnostics` | Enable/disable logging (used when no config file) | ❌ | string | No | true |
| `verbosity` | Logging verbosity (used when no config file) | ❌ | string | No | information |
| `always-log` | Always log setting (used when no config file) | ❌ | string | No | allErrors |
---

### Configuration File

All diagnostic settings are supplied via a JSON configuration file referenced by `config-file-path`.

| Key | Description | Required when enabled | Type | Example |
|-----|-------------|-----------------------|------|---------|
| `enable-appinsights-diagnostics` | Set to `true` to create/update diagnostics; `false` to delete them | ✅ | boolean | `true` |
| `apim-logger-name` | Name of the existing APIM Application Insights logger | ✅ | string | `"my-appinsights-logger"` |
| `always-log` | Always log the specified type of errors regardless of sampling policy | ❌ | string | `"allErrors"` |
| `verbosity` | Verbosity of the applied policy | ❌ | string | `"information"` |
| `sampling-type` | Sampling type | ❌ | string | `"fixed"` |
| `sampling-percentage` | Sampling percentage (0–100) | ❌ | number | `100` |
| `frontend-request-headers` | List of frontend request headers to log | ❌ | array | `["Content-Type"]` |
| `frontend-request-body-bytes` | Number of request body bytes to log | ❌ | number | `1024` |
| `frontend-response-headers` | List of frontend response headers to log | ❌ | array | `["Content-Type"]` |
| `frontend-response-body-bytes` | Number of response body bytes to log | ❌ | number | `1024` |

✅ apim-logger-name is required either in config file or as action input.

#### Example configuration file
```json
{
  "enable-appinsights-diagnostics": true,
  "apim-logger-name": "my-appinsights-logger",
  "always-log": "allErrors",
  "verbosity": "information",
  "sampling-type": "fixed",
  "sampling-percentage": 100,
  "frontend-request-headers": ["Content-Type", "Authorization"],
  "frontend-request-body-bytes": 1024,
  "frontend-response-headers": ["Content-Type"],
  "frontend-response-body-bytes": 1024
}
```
#### Default Behavior (No Config File)
If config-file-path is not provided:
The action applies basic logging configuration using inputs or defaults:

```json
{
  "enable-appinsights-diagnostics": true,
  "verbosity": "information",
  "always-log": "allErrors"
}
```
Logger name must be provided via apim-logger-name
Inputs override defaults if specified

---

### 🔒 Validation Rules

- If config-file-path is provided: File must exist, Must be valid JSON object
- Logger must be provided via: Config file OR input
- `apim-logger-name` is required when `enable-appinsights-diagnostics` is `true` (provide it via config file or action input). The logger must already exist in the APIM instance.
- `sampling-type` and `sampling-percentage` must be provided together when configuring sampling.
- When `enable-appinsights-diagnostics` is `false`, the action will delete the existing `applicationinsights` diagnostic on the API if one is found; all other configuration keys are ignored.

---

### What the Action Does

**1. Determines whether a config file is provided**

**2. If provided: Validates and uses it directly**

**3. If not provided: Builds default config using inputs**

**4. Resolves logger name (config > input)**

**5. If enabled: Resolves APIM logger resource, Builds diagnostics payload, Creates/updates diagnostic using Azure REST API**
```
PUT https://management.azure.com/subscriptions/{subscriptionId}/resourceGroups/{rg}/providers/
    Microsoft.ApiManagement/service/{svc}/apis/{apiId}/diagnostics/applicationinsights
```

---

### Example Scenarios
- Apply default logging to APIs without developer config
- Enable full logging using config file for production APIs
- Disable diagnostics for non-prod environments
- Update verbosity or sampling in CI/CD pipelines

---

### Best Practices
- Store the configuration JSON file in source control and promote it through environments to ensure consistent diagnostic settings
- Use a **dedicated APIM logger** per Application Insights instance; do not share loggers across unrelated services
- Set `sampling-percentage` below `100` in high-traffic production environments to control Application Insights ingestion costs
- Pass `apim-subscription-id` via a GitHub Actions secret or environment variable — **do not hardcode subscription IDs**


---

## 📜 Changelog
All notable changes to this project will be documented in this section.


### [v1] - 2026-05-19
**Tags:** Initial Release
- **Added:** Application Insights diagnostics configuration for APIM APIs
- **Added:** Support for enable/disable toggle via config file
- **Added:** Sampling, verbosity, and frontend request/response capture settings

### [v1.1.0] - 2026-06-11
**Tags:** Incremental Release
- **Added:** optional config file support
- **Added:** default logging fallback
- **Added:** Added input-driven configuration
- **Added:** logger fallback (config → input)
- **Added:** Improved validation and error handling
---

### Repository
**GitHub**: `BHGitOps/action-azure-apim-logging`

### Feedback/Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you!
