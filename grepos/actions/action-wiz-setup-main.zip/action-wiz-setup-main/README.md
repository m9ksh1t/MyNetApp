<h1 align="center">action-wiz-setup</h1>

## Download, Install, and Configure Wiz CLI

This GitHub Action **downloads and installs Wiz CLI on the runner and authenticates using provided Wiz API credentials**. It ensures the Wiz CLI is ready for security scanning and other Wiz operations in your workflow.

---

## Getting Started

These documents will help you get up to speed with our engineering practices and tools.

## Action Summary

The table below provides a concise overview of the GitHub Composite Action, including its name, versioning, supported cloud environments, and compatible technology stacks.

| Action Name | action-wiz-setup |
| :------| :-------------|
| **Latest Stable Version** | v1.1.0 |
| **Current Version** | v1.1.0 |
| **Cloud Environment** | Linux-only (runs on any GitHub-hosted Linux runner) |
| **Cloud Services** | N/A |
| **TechStacks** | Any technology stack requiring Wiz CLI (containerized or non-containerized workloads) |

---

## Jobs & Steps

- **Validate Inputs (Wiz Credentials)**
- **Download and Install Wiz CLI**
- **Verify Wiz CLI Installation**
 
---

## Features

- Validate Inputs (Wiz Credentials)
    - Masks sensitive credential values in the logs.
    - Ensures wiz_client_id and wiz_client_secret are provided.
    - Stops execution early if credentials are missing.
- Download & Install Wiz CLI
    - Downloads the latest Wiz CLI binary for Linux.
    - Grants execute permissions to the Wiz CLI binary.
        - Makes it executable for use within the workflow.
- Verify Installation
    - Verifies installation by checking the Wiz CLI version.
- Prepare Wiz CLI for scanning container images during CI/CD.
- Authenticate Wiz CLI before running security compliance checks.
- Use Wiz CLI to integrate cloud security posture management in workflows.

---

## Usage

Use this action to install and authenticate Wiz CLI:

```yml
runs:
  using: "composite"
  steps:
    - name: Validate Wiz Credentials
    - name: Download and Install Wiz CLI
    - name: Verify Wiz CLI Installation

```
---

## Inputs

| Name                | Description                             | Required  | Type   | Is Sensitive? | Default                                                     |
|---------------------|-----------------------------------------|:---------:|--------|:-------------:|:-----------------------------------------------------------:|
| `wiz_client_id`     | Wiz API token client ID                 | ✅        | string | Yes           | -                                                           |
| `wiz_client_secret` | Wiz API token client secret             | ✅        | string | Yes           | -                                                           |
| `wiz_download_url`  | URL to download the Wiz CLI binary      | ❌        | string | No            | [**WIZ CLI Download**](https://downloads.wiz.io/v1/wizcli/latest/wizcli-linux-amd64) |

---

## Outputs

- This action does not produce explicit outputs.
- It downloads, installs Wiz CLI and authenticates(optionally) it for subsequent steps.

---

## Jobs & Steps

- **Download Wiz CLI**
    - Fetches the latest Wiz CLI binary and makes it executable.
- **Authenticate Wiz CLI**
    - Logs in using provided Wiz API credentials.
- **Verify Wiz CLI Installation**
    - Runs `wizcli version` to confirm successful installation.


---

## Best Practices 

- **Store Wiz credentials in GitHub Secrets** for security.
- **Validate authentication** by checking Wiz CLI version and login status.
- **Rotate Wiz API tokens regularly** for compliance.
- **Run this action early in the workflow** before executing any Wiz CLI commands.

---

## What The Action Does

This action:

- Downloads the Wiz CLI binary from the official Wiz download URL.
- Grants execute permissions to the binary.
- Authenticates Wiz CLI using `wizcli auth --id <CLIENT_ID> --secret <CLIENT_SECRET>`.
- Verifies installation by printing the Wiz CLI version.

---

## 📜Changelog

| Version | Date       | Tags                                                                 | Changes |
|:--------:|:------------|----------------------------------------------------------------------|---------|
| **v1.1.0**  	| 2026-03-02 | Wiz CLI upgrade 															| - **Enhanced:**  Upgraded Wiz CLI from v0.109.1‑d13f4e6 to the v1.x series |
| **v1**  		| 2025-03-11 | ReTag                                                       				| - **Added:** ReTag operation for image URIs |
| **v0**  		| 2025-03-11 | Initial Release                                                       	| - Implemented **Wiz CLI** |

---

## Resources 📚

Here are some essential tools and platforms we use in our engineering organization:

  <article>
    <strong>
      <a href="https://bannerhealth.atlassian.net/wiki/spaces/PE/pages/1473347656/GitHub+Reusable+Workflow">GitHub Reusable Workflowᵈ¹</a>
    </strong>
    <p>
      This page is the central documentation hub for all reusable GitHub workflows maintained by the DSO (DevSecOps) team. It provides an overview of each workflow, including its purpose, usage, and version history, helping teams adopt consistent CI/CD practices and reduce integration issues.
    </p>
  </article>

---

## Feedback/Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
