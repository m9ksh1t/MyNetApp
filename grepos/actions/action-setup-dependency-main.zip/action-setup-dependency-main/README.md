## Setup Dependency Action

This GitHub Action **installs the dependencies required for the application based on the specified framework type**. It supports multiple frameworks and provides options for dependency versioning and configuration.

---

## Features

- Installs dependencies for supported frameworks such as .NET, Angular, Backstage and Python.
- Allows specifying dependency versions for precise control.
- Supports custom working directory for application code.
- Provides an option to use --legacy-peer-deps for npm installations to avoid peer dependency conflicts.
- Supports yarn install with --immutable for Backstage projects.
- Supports optional OpenAPI (Swagger) setup for .NET using Swashbuckle CLI.

---

## Usage

**Current Version:** `v1`

To use this action to install .NET Core and Node dependencies on the runner environment:

```yml
runs:
 using: 'composite'
 steps:
   - name: Setup NuGet.exe

   - name: Install npm dependencies
   
   - name: Install yarn dependencies

   - name: Install python dependencies

   - name: Install Swashbuckle CLI Tool Globally

   - name: Add .NET Tools to PATH


```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `framework-type` | Type of framework used to build the code | ❌ | string | No |
| `dependency-version` | Set up dependency version | ✅ | string | No |
| `working-directory` | Working directory for App code | ❌ | string | No |
| `use-legacy-peer-deps` | Use --legacy-peer-deps with npm install to avoid peer dependency conflicts | ❌ | string | No |
| `requirements-file` | Path to the Python requirements file | ❌ | string | No |
| `target-directory` | Directory where Python dependencies will be installed | ❌ | string | No |
| generate-openapi | Enable OpenAPI (Swagger) support | ❌ | boolean | No |
| swashbuckle-version | Swashbuckle CLI version | ❌ | string | No |


---

## Outputs

- This action does not produce output variables; it modifies the runner environment by installing dependencies for the specified framework.

---

## Jobs & Steps

- **Setup NuGet.exe**
- **Install npm dependencies**
- **Install yarn dependencies** (Backstage only)
- **Install Python dependencies**
- **Install Swashbuckle CLI** Tool (optional)
- **Add .NET** Tools to PATH


---

## Example Scenarios

- Use this action to set up NuGet for managing .NET dependencies before restoring and building your solution.
- Run npm install in the specified working directory, optionally using --legacy-peer-deps to resolve peer dependency conflicts.
- Configure NuGet for backend and npm for frontend in the same workflow for full-stack applications.
- Run yarn install --immutable for Backstage monorepos to ensure lockfile integrity.
- Install Python packages into a local directory using pip.
- Enable optional OpenAPI (Swagger) tooling for .NET projects by installing the Swashbuckle CLI when API  specification generation is required

---

## Best Practices 

- **Pin exact versions** Use specific versions for NuGet , Node and Swashbuckle CLI to ensure reproducible builds.
- **Enable caching** Cache ~/.nuget/packages and ~/.npm to speed up installs and reduce network calls.
- **Verify installations** Add steps like dotnet --info or node -v before build/test to confirm setup.
- **Use lock files** Commit packages.lock.json for .NET and package-lock.json for Node to maintain consistency.
- **Update regularly** Review and update dependency versions for security and compatibility.
- **Enable OpenAPI generation selectively** Set generate-openapi to true only when Swagger/OpenAPI spec generation is required to avoid unnecessary global tool installs


---

## What The Action Does

- **If framework-type = dotnet** Installs NuGet.exe using nuget/setup-nuget@v2 with the specified version.
- **If framework-type = angular** Runs npm install in the given working-directory.
- **If use-legacy-peer-deps** is true, adds --legacy-peer-deps to handle peer dependency conflicts. This option tells npm to ignore peer dependency requirements during installation
- **If framework-type = backstage** Runs yarn install --immutable.
- **If framework-type = python**: Validates requirements file and installs dependencies.
- **If framework-type = dotnet and generate-openapi = true** Installs Swashbuckle.AspNetCore.Cli globally using the configured swashbuckle-version and adds the .NET tools directory to the PATH


---

## Changelog

All notable changes to this project will be documented in this section.

[v1] - 2025-07-11
Tags: Added a new input parameter and updated npm install step to conditionally use --legacy-peer-deps with npm install.

---

## Repository 

GITHUB: `BHGitOps/action-setup-dependency`
