## Publish Action

This GitHub Action **publishes .NET projects to a specified output directory**, supporting single or multiple project files. It provides flexible options for organizing output when publishing multiple projects.

---

## Features

- Publishes one or more .csproj files using dotnet publish.
- Supports custom output location.
- Handles multiple projects with two modes:
    - folder: Creates subfolders for each project.
    - flat: Merges all DLLs into a single output directory.

---

## Usage

**Current Version:** `v2`

To use this action to publish your .NET projects:

```yml
runs:
  using: "composite"
  steps:
    - name: dotnet publish for zip

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `file-name-to-publish` | specific csproj to publish the project | ❌ | string | No |
| `location-to-publish` | specific location to publish output to | ❌ | string | No |
| `multi-project-mode` | For multiple csproj: "flat" puts all DLLs into output/, "folder" creates subfolders | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It generates published binaries in the specified output directory.

---

## Jobs & Steps

- **Publish Single Project**
    - Publishes to the specified output directory.
- **Publish Multiple Projects**
    - Organizes output based on multi-project-mode:
      - folder: Creates subfolders for each project.
      - flat: Merges all files into one directory.

---

## Example Scenarios

- Publish a single .csproj file to output/ for packaging.
- Publish multiple projects into separate folders for modular deployment.
- Merge multiple projects into one folder for containerization or zip packaging.

---

## Best Practices 

- **Run build before publish** to ensure compiled binaries are up-to-date.
- **Use caching** for NuGet packages to speed up publish steps.
- **Validate output** after publish by checking DLLs and configuration files.
- **Pin .NET SDK** version using actions/setup-dotnet for consistent results.

---

## What The Action Does

This action:

- Splits the file-name-to-publish input into individual .csproj files.
- Publishes each project using dotnet publish --no-restore.
- Handles multiple projects by either:
    - Creating subfolders (folder mode).
    - Merging all files into one directory (flat mode).

---

## 📜Changelog

[v2.0.0] - 08-21-2025

Tags: Initial Release

	•	First stable release of v2
	•	Supports running:
	•	publishes .NET projects to a specified output directory
	•	With --file-name-to-publish, --location-to-publish and --multi-project-mode
	•	Publish .Net projects

---

[v2] - 08-21-2025

Tags: Release Alias

	•	v2 is a moving tag pointing to the latest stable v2.x.x version (currently v2.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-publish`