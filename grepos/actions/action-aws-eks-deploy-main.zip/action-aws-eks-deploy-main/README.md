## EKS Deploy Action

This GitHub Action **deploys an application to Amazon EKS using a specified Kubernetes deployment YAML file**. It dynamically substitutes image names and service account details before applying manifests to the cluster.

---

## Features

- Deploys Kubernetes workloads to EKS using kubectl.
- Dynamically injects container image URIs and service account role annotations into deployment files.
- Supports multiple deployment files (comma-separated).
- Handles both application and NGINX image references for multi-container setups.

---

## Usage

**Current Version:** `v1`

To use this action to deploy an application to EKS:

```yml
runs:
  using: "composite"
  steps:
    - name: Set Image name and service account environment variables

    - name: Deploy Image(s) to EKS using kubectl

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `deployment-file` | Path to the Kubernetes deployment YAML file | ✅ | string | No |
| `aws-region` | AWS region where the EKS cluster is hosted (e.g., us-west-2) | ✅ | string | No |
| `image-tag` | The image tag name to use for the container image (e.g., latest) | ✅ | string | No |
| `aws-account-id` | AWS Account ID (e.g., 123456789012) | ✅ | string | No |
| `container-repository` | Name of the container repository in Amazon ECR | ✅ | string | No |
| `namespace` | Kubernetes namespace where the application will be deployed | ✅ | string | No |
| `service-account-role` | Optional: IAM role ARN or name used for service account authentication via OIDC | ❌ | string | No |
| `nginx-repository` | Name of the NGINX container repository in Amazon ECR | ✅ | string | No |
| `nginx-tag` | Tag of the NGINX container image (e.g., stable, latest) | ✅ | string | No |
| `nginx-aws-account-id` | AWS Account ID for Nginx image (e.g., 123456789012) | ✅ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It applies Kubernetes manifests to the specified namespace after substituting environment variables.

---

## Jobs & Steps

- **Set Image name and service account environment variables**
    - Exports application and NGINX image URIs and service account role to $GITHUB_ENV.
- **Deploy Image(s) to EKS using kubectl**
    - Substitutes environment variables in deployment files and applies them using kubectl.

---

## Example Scenarios

- Deploy a multi-container application (app + NGINX) to EKS.
- Automate rolling updates by dynamically injecting image tags.
- Use OIDC-based IAM roles for secure pod-to-AWS resource access.

---

## Best Practices 

- **Authenticate with EKS first** using the Authenticate EKS action.
- **Install kubectl** before running this action.
- **Validate deployment files** for placeholders like ${IMAGE_NAME} and ${NGINX_IMAGE_NAME}.
- **Pin the action version** for stability (e.g., @v1).

---

## What The Action Does

This action:

- Constructs fully qualified ECR image URIs for application and NGINX containers.
- Substitutes placeholders in deployment YAML files using envsubst.
- Applies manifests to the specified namespace using kubectl.

---

## 📜Changelog

[v1.0.0] - 09-17-2025

Tags: Initial Release

	•	First stable release of the EKS Deploy Action
	•	Dynamic image substitution for app and NGINX containers
	•	Multi-file deployment
	•	Optional service account role annotation

---

[v1] - 09-17-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-aws-eks-deploy`