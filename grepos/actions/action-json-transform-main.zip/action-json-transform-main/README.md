## Transform JSON Files With Secrets And Variables

This GitHub Action **replaces values in target JSON files by mapping keys to provided GitHub Secrets and environment variables.** It’s useful for injecting configuration at build time without committing sensitive values to source control.

---

## Features

- Reads all paths/keys from a target JSON file and attempts to replace their values.
- Prioritizes values from secrets JSON; falls back to variables JSON if the secret isn’t present.
- Uses jq to safely parse and update JSON, keeping structure intact.
- Supports nested keys via path traversal (e.g., app.settings.apiKey).

---

## Usage

**Current Version:** `v2`

To use this action to inject secrets and variables into a JSON file:

```yml
runs:
  using: "composite"
  steps:
    - name: Transform JSON files with secrets and variables

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `target-file` | Path to the target JSON file where variables/secrets will be injected | ✅ | string | No |
| `secrets-json` | JSON string containing GitHub Secrets | ✅ | string | Yes |
| `vars-json` | JSON string containing GitHub Environment variables | ✅ | string | No |

---

## Environment Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `conjur_json_file` | Conjur Secrets JSON file | ✅ | file | Yes |

---

## Outputs

- This action does not produce explicit outputs.
- It mutates the target JSON file in-place, replacing values based on matched key paths.

---

## Jobs & Steps

- **Transform JSON files with secrets and variables**

---

## Example Scenarios

- Inject API keys, connection strings, or feature flags into a config.json during CI.
- Maintain a generic appsettings.json and overlay environment-specific values via secrets.
- Populate variables from non-sensitive environment values while reserving sensitive ones for secrets.

---

## Best Practices 

- **Protect sensitive data:** Pass secrets-json using GitHub Secrets (e.g., ${{ secrets.CONFIG_SECRETS_JSON }}) and avoid plaintext in workflow files.
- **Validate transformed output:** After transformation, run jq . ${{ inputs.target-file }} to ensure valid JSON.
- **Keep structure stable:** Ensure key paths in your secrets-json/vars-json match the target file’s paths (after transformation).
- **Fail fast:** Optionally add a step to check that critical keys were set, and fail if missing.
- **Scope secrets:** Include only required keys in secrets-json to reduce exposure.
- **Logging hygiene:** Avoid echoing the transformed file contents to logs; never print secrets.

---

## What The Action Does

- Enumerates all paths in target-file using jq and matches each path against provided mappings.
- Priority order:
  - Conjur Secrets JSON (conjur_json_file)
  - Secrets JSON (secrets-json)
  - Variables JSON (vars-json)
- When a value is found for a given path, it updates the target JSON in-place using jq setpath.
- Temporary files secrets_temp.json and vars_temp.json are cleaned up at the end.

---

## 📜Changelog

[v3.1.0] - 01-13-2026

Tags: Minor Changes

	•	Now Optional Conjur Path & Multi Secret Support has been enabled
	•	Transform JSON Files with Conjur Secrets, GitHub Secrets and Variables
	•	With --target-file, --secrets-json, --vars-json and conjur_json_file
	•	Validates conjur_json_file, target-file, secrets-json and vars-json input
	•	Confirmed that conjur_json_file, secrets-json and vars-json as optional inputs

---

[v3.0.0] - 12-30-2025

Tags: Initial Release

	•	First stable release of the Transform JSON Files with Secrets and Variables GitHub Action
	•	Supports running:
	•	Transform JSON Files with Secrets and Variables
	•	With --target-file, --secrets-json, and --vars-json
	•	Validates target-file, secrets-json and vars-json input
	•	Confirmed both secrets-json and vars-json as required inputs for consistent behavior.

---

[v3] - 12-30-2025

Tags: Release Alias

	•	v2 is a moving tag pointing to the latest stable v2.x.x version (currently v2.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-json-transform`
