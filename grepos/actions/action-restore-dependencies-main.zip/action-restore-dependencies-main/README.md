## Restore Dependencies Action

This GitHub Action **restores project dependencies required for building .NET applications**. It supports restoring from solution (.sln) or project (.csproj) files and optionally uses a custom NuGet configuration file.

---

## Features

- Restores .NET dependencies using dotnet restore.
- Supports specifying a particular solution or project file.
- Allows using a custom NuGet configuration file for private feeds.

---

## Usage

**Current Version:** `v1`

To use this action to restore dependencies:

```yml
runs:
 using: 'composite'
 steps:
   - name: restore dependencies

   - name: restore nuget dependencies

```
---

## Inputs


| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `framework-type` | type of framework used to build the code | ❌ | string | No |
| `file-name-to-restore` | specify a specific filename, examples sln/csproj files to restore. Useful when more than one exist in a single directory | ❌ | string | No |
| `nuget-config-path` | path to the nuget config file | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It restores all required dependencies for .NET projects.

---

## Jobs & Steps

- **restore dependencies**
- **restore nuget dependencies**

---

## Example Scenarios

- Restore dependencies for a single .sln file in a solution-based project.
- Restore dependencies for a specific .csproj file in a multi-project repository.
- Use a custom NuGet configuration file to pull packages from private feeds.

---

## Best Practices

- Pin exact .NET SDK version using actions/setup-dotnet@v4 before running restore.
- Use caching for NuGet packages (~/.nuget/packages) to speed up builds.
- Validate restore by checking exit codes and running dotnet list package after restore.
- Secure private feeds by using GitHub Secrets for credentials in nuget.config.

---

## What The Action Does

This action:

- Runs dotnet restore on the specified file.
- If nuget-config-path is provided, uses --configfile to apply custom NuGet settings.
- Ensures dependencies are available for subsequent build and test steps.

---

## 📜Changelog

[v1.0.0] - 02-18-2025

Tags: Initial Release

	•	First stable release of the Sitecore XM Cloud Deploy GitHub Action
	•	Supports running:
	•	restores project dependencies
	•	With --framework-type, --file-name-to-restore, and --nuget-config-path
	•	Validates framework-type and nuget-config-path input
	•	restore dependencies and nuget dependencies

---

[v1] - 02-18-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository

GITHUB: `BHGitOps/action-restore-dependencies`
