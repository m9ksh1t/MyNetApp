## Clean Runner Workspace Action

This GitHub Action **safely deletes all files in the current GitHub Actions workspace** to free up disk space after a job completes. It includes safety checks to ensure only the intended directory is cleaned.

---

## Features

- Displays the current working directory and GitHub workspace path.
- Validates that the cleanup occurs inside the correct workspace.
- Deletes all files and folders within the workspace to reclaim space.

---

## Usage

**Current Version:** `v1`

To use this action to clean the runner workspace:

```yml
runs:
 using: 'composite'
 steps:
   - name: Show current directory

   - name: Validate workspace path

   - name: Clean workspace

```
---

## Inputs


This action does not require any inputs.

---

## Outputs

- This action does not produce explicit outputs.
- It removes all files from the GitHub Actions workspace.

---

## Jobs & Steps

- **Show current directory**
- **Validate workspace path**
- **Clean workspace**

---

## Example Scenarios

- Free up disk space after large build or test jobs.
- Remove temporary files before starting a new job in the same runner.
- Clean up sensitive files after deployment.

---

## Best Practices

- **Run this action at the end of a workflow** to avoid deleting files needed by subsequent steps.
- **Do not use in shared runners** unless you are certain the workspace is isolated.
- **Validate logs** to confirm cleanup occurred in the correct directory.
- **Avoid running as the first step** in a job to prevent accidental deletion of source code.

---

## What The Action Does

This action:

- Prints the current directory and workspace path.
- Validates that the cleanup occurs inside GITHUB_WORKSPACE.
- Deletes all files and folders inside the workspace using rm -rf.

---

## 📜Changelog

[v1.0.0] - 06-09-2025

Tags: Initial release

	•	First stable release to Clean Runner Workspace 
	•	Supports running:
	•	safely deletes all files in the current GitHub Actions workspace
---

[v1] - 06-09-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository

GITHUB: `BHGitOps/action-clean-runner-workspace`
