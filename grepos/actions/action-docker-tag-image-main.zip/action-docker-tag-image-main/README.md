## Load and Tag Docker Image Action

This GitHub Action **loads a Docker image from a tar archive and tags it for either AWS Elastic Container Registry (ECR) or Azure Container Registry (ACR)** based on provided inputs. It also supports retagging an already tagged image without loading a new one.

---

## Features

- Loads a Docker image from image.tar and extracts its name.
- Tags the image for:
    - AWS ECR using aws-account-id and aws-region.
    - Azure ACR using container-registry.
- Supports retagging an existing image without loading from tar.
- Includes safety checks and AWK installation for parsing Docker output.

---

## Usage

**Current Version:** `v1`

To use this action to load and tag a Docker image:

```yml
runs:
  using: "composite"
  steps:
    - name: Ensure AWK is Installed

    - name: Load Docker Image and Tag for Registry

    - name: Retag Docker Image

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `registry` | Target registry: ecr' or acr | ✅ | string | No |
| `aws-account-id` | AWS Account ID for the ECR registry. Required if tagging for ECR | ❌ | string | No |
| `aws-region` | The AWS region where the ECR repository is located (e.g., us-west-2) | ❌ | string | No |
| `container-repository` | Name of the container repository (ECR or ACR) to tag the image with | ✅ | string | No |
| `image-tag` | Tag to assign to the Docker image (e.g., latest) | ✅ | string | No |
| `container-registry` | Azure Container Registry (ACR) name. Required if tagging for ACR | ❌ | string | No |
| `retag-image` | If true, retags an already tagged image instead of loading a new one | ❌ | boolean | No |

---

## Outputs

- This action does not produce explicit outputs.
- It tags the Docker image for the specified container registry.

---

## Jobs & Steps

- **Ensure AWK is Installed**
    - Installs AWK if missing (required for parsing docker load output).
- **Load Docker Image and Tag for Registry**
    - Loads image from image.tar and tags it for ECR or ACR.
- **Retag Docker Image**
    - Retags an already tagged image without loading from tar.

---

## Example Scenarios

- Load a Docker image from a tar file and tag it for AWS ECR.
- Load and tag a Docker image for Azure ACR.
- Retag an image for a different environment without reloading.

---

## Best Practices 

- **Authenticate with AWS or Azure** before pushing images (use aws-actions/configure-aws-credentials or azure/login).
- **Use descriptive tags** for clarity (e.g., my-app:1.0.0).
- **Run this action after saving/uploading the tar file** in previous steps.
- **Validate registry names and credentials** before tagging.

---

## What The Action Does

This action:

- Loads a Docker image from image.tar and extracts its name.
- Tags the image for AWS ECR or Azure ACR based on provided inputs.
- Supports retagging an existing image without loading from tar.

---

## 📜Changelog

[v1.0.0] - 07-14-2025

Tags: Initial Release

	•	First stable release of the Load and Tag Docker Image Action
	•	Loads a Docker image from a tar archive and tags it for either AWS Elastic Container Registry (ECR) or Azure Container Registry (ACR)
	•	With --aws-account-id, --aws-region, --container-repository, --image-tag, --container-registry and --retag-image

---

[v1] - 07-14-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-docker-tag-image`