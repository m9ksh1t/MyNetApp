## Import Azure APIM API with Optional Versioning

This GitHub Action **imports APIs into Azure API Management (APIM)** from a Swagger/OpenAPI specification file or URL, with optional support for API versioning.

---

## Features

- Import API from **local Swagger/OpenAPI** file or remote URL.
- Supports **optional versioning** using Azure APIM Version Sets.
- Allows configuration of **subscription requirement, tags, and display name**.
- Works for both **single API and multiple versions**.

---

## Usage

**Current Version:** `v2`

To use this action to import APIs into Azure APIM:

```yml
runs:
  using: "composite"
  steps:
    - name: Import API from Swagger file without versioning

    - name: Import API from Swagger file with versioning

    - name: Import API from Swagger URL without versioning

    - name: Import API from Swagger URL with versioning

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `apim-resource-group` | Resource group of the Azure APIM service | ✅ | string | No |
| `apim-service-name` | Name of the Azure APIM service | ✅ | string | No |
| `apim-api-id` | Unique identifier for the API in APIM | ✅ | string | No |
| `apim-api-display-name` | Display name of the API to be created in APIM | ✅ | string | No |
| `apim-api-path` | Base path for the API endpoints | ✅ | string | No |
| `apim-api-subscription-required` | Whether the API requires a subscription key for requests | ❌ | string | No |
| `apim-specification-format` | Format of the API specification for importing | ❌ | string | No |
| `cloud-app-name` | Name of the cloud resource (e.g., Azure Function name) | ❌ | string | No |
| `versions` | Comma-separated list of API versions (e.g., v1,v2,v3) | ❌ | string | No |
| `apim-api-version-set-id` | Describes the Version Set to be used with the API | ❌ | string | No |
| `apim-api-specification-file-path` | Local file path to the Swagger/OpenAPI specification | ❌ | string | No |
| `apim-swagger-url` | URL to the Swagger/OpenAPI specification | ❌ | string | No |
| `apim-api-tags` | Comma-separated list of tags to assign to the API | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- Imports APIs into the specified APIM instance, optionally creating multiple versions.

---

## Jobs & Steps

- **Import API from Swagger file without versioning**
    - Runs when: apim-api-specification-file-path is provided and versions is empty and apim-api-version-set-id is empty.
    - Behavior:
      - Imports a single API using --specification-path.
      - Sets --subscription-required based on input.
- **Import API from Swagger file with versioning**
    - Runs when: apim-api-specification-file-path is provided and both versions and apim-api-version-set-id are provided.
    - Behavior:
      - Splits versions by comma and imports each version using --api-version and --api-version-set-id.
- **Import API from Swagger URL without versioning**
    - Runs when: apim-swagger-url is provided and versions is empty and apim-api-version-set-id is empty.
    - Behavior:
      - Imports a single API using --specification-url.
- **Import API from Swagger URL with versioning**
    - Runs when: apim-swagger-url is provided and both versions and apim-api-version-set-id are provided.
    - Behavior:
      - Splits versions by comma and imports each version from the URL using --api-version and --api-version-set-id.
---

## Example Scenarios

- Import a single API from a local Swagger file.
- Import an API from a remote Swagger URL.
- Import multiple API versions using a Version Set.

---

## Best Practices 

- **Ensure Azure CLI is installed and authenticated** (use azure/login@v2 on GitHub-hosted runners).
- **Keep apim-api-id stable** across updates to avoid duplicate APIs.
- **Validate your OpenAPI/Swagger document** before import to prevent runtime import errors.
- **Use Version Sets** when you have multiple versions; ensure both versions and apim-api-version-set-id are provided.
- **Prefer OpenAPI 3.x where possible** for richer metadata and compatibility.
- **Pin the action version** for stability (e.g., @v2).

---

## What The Action Does

This action:

- Connects to the specified APIM instance via Azure CLI.
- Imports APIs from a **local file path** or remote URL.
- Optionally imports **multiple versions** when version metadata is provided.
- Configures subscription requirement and accepts optional tags.

---

## 📜Changelog

[v2.1.0] - 10-13-2025

Tags: Second Release

	•	Second stable release of Import Azure APIM API with Optional Versioning
	•	Supports import from file and URL.
  •	Supports create operations for single API and multiple versions via Version Set.

---

[v2] - 10-13-2025

Tags: Release Alias

	•	v2 is a moving tag pointing to the latest stable v2.1.x version (currently v2.1.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-azure-apim-definitions`

---

## 📬 Need Help?

If you have any questions or need assistance, feel free to reach out to DevSecOps.

---

This workflow is maintained by the Banner Health DevSecOps Platform Team.