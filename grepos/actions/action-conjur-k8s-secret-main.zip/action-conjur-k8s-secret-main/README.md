## Create Kubernetes Secret from Conjur JSON Action

This GitHub Action **creates a Kubernetes Secret from a JSON file containing Conjur-provided** secrets. It supports optional key filtering, temporary file handling, and secure creation of Kubernetes Secrets using kubectl.
This action is ideal for CI/CD pipelines that require injecting Conjur-managed secrets into Kubernetes workloads.

---

## Features

- Reads secrets from a JSON file defined in environment variable secrets-json.
- Supports creating Kubernetes Secrets in any namespace.
- Optionally filters specific keys from the JSON before creating the Secret.
- Automatically generates temporary files for each key/value pair.
- Uses kubectl to create or update the Kubernetes Secret.
- Ensures cleanup of all temporary resources.

---

## Usage

**Current Version:** `v1`

To use this action to create a Kubernetes Secret:

```yml
runs:
  using: "composite"
  steps:
    - name: Create Kubernetes Secret

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `secret-name` | Name of the Kubernetes Secret to create | ✅ | string | No |
| `namespace` | Namespace where the secret will be created | ✅ | string | No |
| `secrets-keys` | Comma-separated list of keys to include in the Kubernetes Secret (optional) | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- All status messages are logged to the workflow for visibility.

---

## Jobs & Steps

- **Create Kubernetes Secret**
    - Ensures the JSON file path exists.
    - Exits with an error if missing.
    - Creates a unique folder under /tmp/ for secret file assembly.
    - If secrets-keys is provided: Only those keys are included.
    - Otherwise: All keys from the JSON are used.
    - Creates a file per key: /tmp/k8s-secrets-XXXXX/<key>
    - Writes the value into the file.
    - Create or Update Kubernetes Secret
    - Deletes temporary directory after completion.
---

## Example Scenarios

- Create Kubernetes Secrets from Conjur secrets during deployment.
- Pass only required keys to specific microservices.
- Standardize secret provisioning during CI/CD rollouts.
- Replace manual secret creation workflows with automated pipelines.

---

## Best Practices 

- Ensure **secrets-json contains valid JSON** before running the action.
- Use **secrets-keys to limit exposure of sensitive data**.
- **Store Conjur secrets securely and inject** them via GitHub environment variables.
- Validate Kubernetes cluster context (kubectl config current-context) before execution.
- **Pin the action version** for stability (e.g., @v1).

---

## What The Action Does

This action:

- Loads Conjur secrets from JSON.
- Filters and transforms secrets into Kubernetes Secret files.
- Creates or updates a Kubernetes Secret using kubectl.
- Cleans up temporary files to prevent leaks.
- Provides transparent logging for auditing and debugging.

---

## 📜Changelog

[v1.0.0] - 12-01-2025

Tags: Initial Release

	•	First stable release of Create Kubernetes Secret from Conjur JSON Action.
	•	Supports optional key filtering and secure secret creation.
    •	Includes automatic cleanup and safe file handling.

---

[v1] - 12-01-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-conjur-k8s-secret`

---

## 📬 Need Help?

If you have any questions or need assistance, feel free to reach out to DevSecOps.

---

This workflow is maintained by the Banner Health DevSecOps Platform Team.