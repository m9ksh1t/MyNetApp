<h1 align="center">Azure Login Action.</h1>

## Overview
This GitHub Action **authenticates the runner environment with Azure using service principal credentials**. It is essential for workflows that interact with Azure resources for deployment, management, or automation.

---
## Getting Started

These documents will help you get up to speed with our engineering practices and tools.

## Features

- Logs in to Azure using a service principal.
- Supports authentication for multiple Azure subscriptions.
- Configures the environment for Azure CLI and related commands.

---

## Usage

**Current Version:** `v1`

To use this action to log in to Azure:

```yml
runs:
 using: 'composite'
 steps:
   - name: Azure login

```
---

## Inputs


| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `client-id`       | Azure Service Principal Client ID used for authentication with Azure resources            | ✅ | string | Yes |
| `tenant-id`       | Azure Active Directory Tenant ID associated with the Service Principal for authentication | ✅ | string | Yes |
| `subscription-id` | Azure Subscription ID where the resources are deployed (optional for tenant-only login)   | ❌ | string | Yes |

---

## Outputs

- This action does not produce outputs directly. It authenticates the runner environment with Azure for subsequent steps.

---

## Jobs & Steps

| Step Name | Purpose |
|-------------|---------|
| **Validate required inputs are provided** | Validate if all the Validate required inputs are provided |
| **Azure login (with subscription)** | Login to Azure with subscription when provided |
| **Azure login (no subscription)** | Tenant-level login when no subscription id is provided |

---

## Example Scenarios

- Deploy an application to Azure App Service.
- Run Azure CLI commands to manage resources.
- Authenticate before using other Azure GitHub Actions (e.g., azure/webapps-deploy).

---

## Best Practices

- Use GitHub Secrets to store sensitive values like client-id, tenant-id, and subscription-id.
- Validate credentials before running deployment steps to avoid failures.
- Restrict permissions of the service principal to follow least privilege principle.
- Rotate credentials regularly for security compliance.

---

## What The Action Does

This action uses the official azure/login@v2 action to:

- Authenticate with Azure using service principal credentials.
- Configure the environment so that Azure CLI and other Azure actions can run securely.

---

## Changelog

All notable changes to this project will be documented in this section.

[v1] - 2025-02-17

Tags: Initial release with Azure login support

## Repository

GITHUB: `BHGitOps/action-azure-login`
