## APIM Named Values Management

This GitHub Action **adds, updates, or deletes named values in Azure API Management (APIM)**. It supports plain, secret, and KeyVault-based named values using Azure CLI and REST API.

---

## Features

- Manage **plain and secret** named values in APIM.
- Supports **KeyVault-based named values** for secure secret management.
- Handles **create, update (upsert), and delete** operations.
- Allows **configuration via JSON file** or inline JSON strings.
- Provides **error handling and optional** pipeline fail-fast behavior.

---

## Usage

**Current Version:** `v3`

To use this action to manage named values in APIM:

```yml
runs:
  using: "composite"
  steps:
    - name: Filter Named Values plain, secret, keyvault

    - name: Manage APIM Named Values plain and secret

    - name: Manage APIM Named Values KeyVault

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `apim-resource-group` | Resource group of the azure resource | ❌ | string | No |
| `apim-service-name` | Specify the APIM instance name | ❌ | string | No |
| `apim-named-values-file-path` | Path to JSON file containing named values | ❌ | string | No |
| `vars-json` | JSON string of plain type named values | ❌ | string | No |
| `secrets-json` | JSON string of secret type named values | ❌ | string | No |
| `client-id` | Client id to login to Azure | ✅ | string | No |
| `tenant-id` | Tenant id to login to Azure | ✅ | string | No |
| `apim-subscription-id` | Azure subscription ID where APIM resources are located | ❌ | string | No |
| `api-version` | API Management REST API version| ❌ | string | No |
| `failOnUpsertErrorForNamedValues` | Determines if pipeline should fail on named value upsert errors. Default as 'true' to fail immediately on first error | ✅ | boolean | No |

---

## Outputs

- This action does not produce explicit outputs.
- Creates, updates, or deletes named values in the specified APIM instance.

---

## Jobs & Steps

- **Filter Named Values plain, secret, keyvault**
    - Reads JSON file and separates plain, secret, and KeyVault named values.
- **Manage Plain and Secret Named Values**
    - Performs UPSERT or DELETE operations using Azure CLI.
    - Handles type changes (e.g., KeyVault → secret/plain).
- **Manage KeyVault Named Values**
    - Validates KeyVault secret identifiers.
    - Performs UPSERT or DELETE operations using Azure REST API.
    - Validates version format (must be 32 hex characters).
    - Verifies secret existence (latest or specific version).
---

## 🔐 KeyVault Named Values – Enhanced Validation

The action now includes **robust validation** for KeyVault‑based named values.

### ✔️ Version Detection
- Automatically identifies whether the secret identifier includes a version.
- If not present, the latest version is used.

### ✔️ Version Format Validation
- Version must be exactly **32 hex characters**.
- Invalid versions:
  - Skip (if fail flag is false)
  - Fail pipeline (if true)

### ✔️ Secret Existence Validation
- If version is included → validate that *specific version* exists.
- If not included → validate that *latest version* exists.

### ✔️ Secure Masking
- Secret version is masked in logs.

---

## Example Scenarios

- Add new named values for API configuration (plain and secret types).
- Update existing named values to change values or type (e.g., plain → secret).
- Delete unused named values during cleanup.
- Create KeyVault-based named values for secure secret management.

---

## Best Practices 

- **Ensure Azure CLI and REST API access** before running this action.
- **Validate JSON structure for named values** before execution.
- Use **KeyVault for sensitive secrets** instead of plain values.
- **Combine with Azure Login** Action for authentication.
- **Pin the action version** for stability (e.g., @v3).

---

## What The Action Does

This action:

- Connects to the specified APIM instance.
- Reads named values from JSON file or inline JSON.
- Creates, updates, or deletes named values based on configuration.
- Supports plain, secret, and KeyVault types.

---

## 📜Changelog

[v3.1.0] - 12-08-2025

Tags: Third Release

	•	Third stable release of APIM Named Values Management action.
	•	Supports plain, secret, and KeyVault named values.
    •	Handles create, update, and delete operations.

---

[v3] - 12-08-2025

Tags: Release Alias

	•	v3 is a moving tag pointing to the latest stable v3.1.x version (currently v3.1.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-azure-apim-named-values`

---

## 📬 Need Help?

If you have any questions or need assistance, feel free to reach out to DevSecOps.

---

This workflow is maintained by the Banner Health DevSecOps Platform Team.