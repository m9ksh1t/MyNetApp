## Create Kubernetes Secret from GitHub Secrets Action

This GitHub Action **fetches secrets from GitHub and creates a Kubernetes Secret** in the specified namespace. It is useful for securely injecting sensitive data into Kubernetes workloads during CI/CD pipelines.

---

## Features

- Reads a JSON object of GitHub secrets.
- Creates a Kubernetes Secret from the provided key-value pairs.
- Applies the secret to the specified namespace using kubectl.

---

## Usage

**Current Version:** `v2`

To use this action to create a Kubernetes Secret:

```yml
runs:
  using: "composite"
  steps:
    - name: Generate and apply Kubernetes Secret

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `secrets-json` | JSON object containing all GitHub secrets | ✅ | string | Yes |
| `secret-name` | Name of the Kubernetes secret to create | ✅ | string | No |
| `namespace` | Namespace in Kubernetes where the secret will be deployed | ✅ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It creates a Kubernetes Secret in the specified namespace.

---

## Jobs & Steps

- **Generate and apply Kubernetes Secret**
    - Converts GitHub secrets JSON into files, creates a Kubernetes Secret manifest, and applies it to the cluster using kubectl.

---

## Example Scenarios

- Inject sensitive credentials (API keys, DB passwords) into Kubernetes workloads.
- Automate secret creation during deployment pipelines.
- Manage environment-specific secrets dynamically from GitHub Actions.

---

## Best Practices 

- **Ensure kubectl and kubeconfig are configured** before running this action.
- **Use GitHub Encrypted Secrets** for sensitive data.
- **Validate namespace exists** before applying the secret.
- **Clean up temporary files** after use (already handled in this action).

---

## What The Action Does

This action:

- Reads a JSON object of secrets from GitHub.
- Creates temporary files for each secret key-value pair.
- Generates a Kubernetes Secret manifest and applies it to the cluster.
- Cleans up temporary files after completion.

---

## 📜Changelog

[v2.0.0] - 06-30-2025

Tags: Second Release

	•	Second stable release of the Create Kubernetes Secret from GitHub Secrets Action
	•	Reading secrets from JSON
	•	Creating and applying Kubernetes Secret
	•	Namespace targeting

---

[v2] - 06-30-2025

Tags: Release Alias

	•	v2 is a moving tag pointing to the latest stable v2.x.x version (currently v2.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-gh-secrets-to-k8s`