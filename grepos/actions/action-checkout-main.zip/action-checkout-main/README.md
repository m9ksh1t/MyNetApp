# Checkout Repository Code

This GitHub Action checks out code from the **repository with optional support for submodules and Super Linter configuration**.

---

## Features:

- Checks out repository code with flexible options.
- Supports submodules for projects with private dependencies.
- Provides Super Linter-specific checkout behavior for linting workflows.
- Allows secure authentication using a GitHub App installation token.

---

## Usage

**Current Version:** `v2`

Use this action to check out your repository’s code into the runner environment so that subsequent steps in the workflow can access and work with the code.

```yml
runs:
 using: 'composite'
 steps:
   - name: Checkout code (basic)
     if: ${{ inputs.include-super-linter == 'false' && inputs.submodules == 'false' }}
     uses: actions/checkout@v6

   - name: Checkout code with submodules
     if: ${{ inputs.submodules == 'true' && inputs.include-super-linter == 'false' }}
     uses: actions/checkout@v6
     with:
         submodules: recursive
         token: ${{ inputs.gh-app-token }}

   - name: Checkout code for Super Linter
     if: ${{ inputs.include-super-linter == 'true' && inputs.submodules == 'false' }}
     uses: actions/checkout@v6
     with:
        fetch-depth: 0

   - name: Checkout code for Super Linter with submodules
     if: ${{ inputs.include-super-linter == 'true' && inputs.submodules == 'true' }}
     uses: actions/checkout@v6
     with:
        fetch-depth: 0
        submodules: recursive
        token: ${{ inputs.gh-app-token }}
```

---

## Inputs:

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `include-super-linter` | Boolean flag to enable or disable Super Linter-specific checkout behavior | ❌ | boolean | No |
| `submodules` | Boolean flag to include submodules during checkout. Set to "true" to enable submodule token usage| ❌ | boolean | No |
| `gh-app-token` | GitHub App installation token used to authenticate access to private repositories and submodules | ❌ | string | No |

---

## Outputs : 

This action does not produce outputs directly; it performs repository checkout.

---

## Jobs & Steps :

- **Checkout code (basic)**
    if: ${{ inputs.include-super-linter == 'false' && inputs.submodules == 'false' }}
- **Checkout code with submodules**
    if: ${{ inputs.submodules == 'true' && inputs.include-super-linter == 'false' }}
- **Checkout code for Super Linter**
    if: ${{ inputs.include-super-linter == 'true' && inputs.submodules == 'false' }}
- **Checkout code for Super Linter with submodules**
    if: ${{ inputs.include-super-linter == 'true' && inputs.submodules == 'true' }}

---

## Example Scenarios

- Fetch private submodules securely using a GitHub App token in workflows that include submodule dependencies.
- Perform linting workflows requiring full commit history for accurate analysis using Super Linter.
- Combine submodule support with full history for complex projects that need both dependency resolution and linting validation.

---

## Best Practices

- Enable submodules or full history only when required to optimize workflow performance.
- Manage tokens securely by storing them in GitHub Actions secrets and passing them through workflow inputs.
- Avoid unnecessary fetch operations to reduce execution time and resource usage.
- Rotate GitHub App credentials regularly to maintain security compliance.
- Use short-lived tokens for authentication instead of long-lived credentials to minimize risk.

---

## What The Action Does
This action uses actions/checkout@v4 internally with conditional logic:

- Basic Checkout: Standard repository checkout when no special options are enabled.
- Checkout with Submodules: Adds submodules: recursive and uses gh-app-token for authentication.
- Super Linter Checkout: Sets fetch-depth: 0 for full history required by Super Linter.
- Super Linter with Submodules: Combines full history and submodule support with authentication.

## Repository

GITHUB: `BHGitOps/action-checkout`
