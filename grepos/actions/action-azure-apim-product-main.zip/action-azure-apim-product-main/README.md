## APIM Product Creation

This GitHub Action **creates or updates a product in Azure API Management (APIM)** using the Azure CLI. It supports configuration of product details such as subscription requirements, approval settings, legal terms, and state.

---

## Features

- Creates a new product in APIM if it does not exist.
- Updates an existing product with new details if it already exists.
- Supports optional parameters like approval requirement, subscription limit, and legal terms.
- Handles both create and update operations automatically.

---

## Usage

**Current Version:** `v1`

To use this action to create or update an APIM product:

```yml
runs:
  using: "composite"
  steps:
    - name: Create APIM Product using Azure CLI

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `apim-resource-group` | Resource group of the Azure APIM service | ✅ | string | No |
| `apim-service-name` | Name of the Azure APIM service | ✅ | string | No |
| `apim-product-name` | Display name of the product | ✅ | string | No |
| `apim-product-id` | Product ID | ❌ | string | No |
| `apim-product-description` | Description of the product | ❌ | string | No |
| `apim-product-subscription-required` | Specify whether subscription is required or not | ❌ | boolean | No |
| `apim-product-state` | Specify the state | ❌ | string | No |
| `apim-product-approval-required` | Specify whether approval is required or not | ❌ | boolean | No |
| `apim-product-subscriptions-limit` | Specify the subscription limit | ❌ | string | No |
| `apim-product-legal-terms` | Specify the legal terms for product | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- Creates or updates a product in the specified APIM instance.

---

## Jobs & Steps

- **Create APIM Product using Azure CLI**
    - Uses az apim product list to verify if the product already exists
    - If product exists, updates details like name, description, legal terms, subscription settings, and state.
    - If product does not exist, creates a new product with the specified configuration.
---

## Example Scenarios

- **Create a new product in APIM with subscription** required and approval enabled for enterprise APIs.
- **Update an existing product** to change its description, legal terms, and subscription settings.
- **Publish a product that was previously in notPublished** state to make it available to developers.
- **Set subscription limits and approval requirements** for a premium product to control access.

---

## Best Practices 

- **Ensure Azure CLI is installed and authenticated** before running this action.
- Use **descriptive product IDs** for easier management.
- **Validate legal terms and subscription** settings before deployment.
- **Pin the action version** for stability (e.g., @v1).

---

## What The Action Does

This action:

- Connects to the specified APIM instance.
- Checks if the product exists.
- Creates or updates the product with the provided configuration.
- Supports optional parameters like approval requirement, subscription limit, and legal terms.

---

## 📜Changelog

[v1.0.0] - 10-13-2025

Tags: First Release

	•	First stable release of APIM Product Creation action.
	•	Supports create and update operations.
    •	Handles optional parameters for subscription and approval settings.

---

[v1] - 10-13-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-azure-apim-product`

---

## 📬 Need Help?

If you have any questions or need assistance, feel free to reach out to DevSecOps.

---

This workflow is maintained by the Banner Health DevSecOps Platform Team.