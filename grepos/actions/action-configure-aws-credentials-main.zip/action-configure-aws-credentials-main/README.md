## AWS Configure Action

This GitHub Action **configures AWS CLI with credentials and assumes the specified IAM role using OIDC**. It is useful for workflows that need secure access to AWS services without storing long-term credentials.

---

## Features

- Assumes an AWS IAM role using OpenID Connect (OIDC).
- Configures AWS CLI for subsequent steps in the workflow.
- Supports specifying role ARN, session name, and AWS region.

---

## Usage

**Current Version:** `v1`

To use this action to configure AWS credentials:

```yml
runs:
  using: "composite"
  steps:
    - name: configure aws credentials

```
---

## Inputs

| Name | Description | Required | type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `oidc-assume-role` | oidc role to login to AWS | ✅ | string | No |
| `role-session-name` | specify the role session name | ✅ | string | No |
| `aws-region` | specify the region | ✅ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It configures AWS credentials for use in subsequent steps.

---

## Jobs & Steps

- **configure aws credentials**
    - Uses aws-actions/configure-aws-credentials@v6 to assume the specified IAM role and set up AWS CLI.

---

## Example Scenarios

- Deploy infrastructure using AWS CLI or CDK.
- Upload artifacts to S3.
- Trigger Lambda functions or ECS tasks.
- Run Terraform or CloudFormation commands

---

## Best Practices 

- Ensure your IAM role trusts GitHub’s OIDC provider.
- Grant least privilege permissions to the IAM role.
- Use descriptive session names for better audit logs.
- Pin the action version for stability (e.g., @v4).

---

## What The Action Does

This action:

- Assumes the specified IAM role using OIDC.
- Configures AWS CLI with temporary credentials.
- Makes AWS services accessible for subsequent steps.

---

## 📜Changelog

[v1.0.0] - 02-19-2025

Tags: Initial Release

	•	First stable release of the AWS Configure Action
	•	Configures AWS CLI with credentials and assumes the specified IAM role using OIDC.
	•	With --oidc-assume-role, --role-session-name and --aws-region.

---

[v1] - 02-19-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-configure-aws-credentials`
