## Download and Install AWS CLI Action

This GitHub Action **downloads and installs the AWS CLI (v2)** if it is not already available on the runner. It ensures that AWS CLI is ready for use in subsequent workflow steps.

---

## Features

- Checks if AWS CLI is installed.
- Downloads and installs AWS CLI v2 on Linux runners if missing.
- Updates the system path to include AWS CLI binaries.

---

## Usage

**Current Version:** `v1`

To use this action to install AWS CLI:

```yml
runs:
  using: "composite"
  steps:
    - name: Install AWS CLI Module

```
---

## Inputs

- This action does not require any inputs.

---

## Outputs

- This action does not produce explicit outputs.
- It ensures AWS CLI is installed and available in the system PATH.

---

## Jobs & Steps

- **Install AWS CLI Module**
    - Checks if AWS CLI exists; if missing, downloads and installs AWS CLI v2; updates $GITHUB_PATH for subsequent steps.

---

## Example Scenarios

- Prepare the runner for AWS CLI commands in deployment workflows.
- Ensure AWS CLI is available before configuring credentials.
- Use in workflows that interact with AWS services (S3, EC2, Lambda, etc.).

---

## Best Practices 

- **Run this step before any AWS-related actions** to avoid missing CLI errors.
- **Use caching or pre-installed runners** if possible to speed up workflows.
- **Combine with AWS Configure Action** for complete AWS setup.

---

## What The Action Does

This action:

- Verifies AWS CLI installation.
- Installs AWS CLI v2 if not present.
- Updates the PATH for immediate use.

---

## 📜Changelog

[v1.0.0] - 04-23-2025

Tags: Initial Release

	•	First stable release to Download and Install AWS CLI Action
	•	Downloads and installs the AWS CLI (v2) if it is not already available on the runner
	•	This action does not require any inputs.

---

[v1] - 04-23-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-install-aws-cli`