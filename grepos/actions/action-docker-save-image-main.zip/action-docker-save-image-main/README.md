## Save Docker Image Action

This GitHub Action **saves a specified Docker image to a tar archive file**. It is useful for workflows that need to export Docker images for later use, transfer, or storage.

---

## Features

- Saves a Docker image to a .tar file using docker save.
- Supports specifying the image name and tag.
- Creates an archive named image.tar in the current working directory.

---

## Usage

**Current Version:** `v1`

To use this action to save a Docker image:

```yml
runs:
  using: "composite"
  steps:
    - name: Save Docker Image to TAR File

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `image-tag` | The name and tag of the Docker image to save (e.g., my-image:latest) | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It creates a file named image.tar containing the specified Docker image.

---

## Jobs & Steps

- **Save Docker Image to TAR File**
    - Runs docker save -o image.tar <image-tag> to export the image as a tar archive.

---

## Example Scenarios

- Save a Docker image after building it for later deployment.
- Export an image for offline transfer or backup.
- Prepare an image for scanning or packaging in subsequent steps.

---

## Best Practices 

- **Run Docker build before this step** to ensure the image exists locally.
- **Use descriptive image tags** for clarity (e.g., my-app:1.0.0).
- **Upload the tar file as an artifact** if needed for later jobs using actions/upload-artifact.
- **Clean up tar files** after use to free disk space.

---

## What The Action Does

This action:

- Executes docker save to export the specified Docker image.
- Creates a tar archive named image.tar in the current working directory.

---

## 📜Changelog

[v1.0.0] - 05-29-2025

Tags: Initial Release

	•	First stable release of the Save Docker Image Action
	•	Saves a specified Docker image to a tar archive file
	•	With --image-tag

---

[v1] - 05-29-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-docker-save-image`