## Setup Framework Action

This GitHub Action **installs and configures a specified development framework on the runner environment**. It is useful for workflows that require a particular framework for building, testing, or deploying applications.

---

## Features

- Installs the specified framework for building source code.
- Supports multiple frameworks such as .NET Core and Node.js or Backstage (Corepack+Yarn)
- Configures the environment for framework-specific commands.

---

## Usage

**Current Version:** `v1`

To use this action to install .NET Core and Node on the runner environment:

```yml
runs:
  using: "composite"
  steps:
    - name: Setup .NET Core
      uses: actions/setup-dotnet@v5

    - name: Setup Node
      uses: actions/setup-node@v4
    
    - name: Enable corepack

    - name: Setup Dependency Manager
      uses: actions/setup-node@v4

```
---

## Inputs

| Name | Description | Required | type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `framework-type` | Type of framework used to build the code | ❌ | string | No |
| `framework-version` | Framework version that is required | ✅ | string | No |
| `yarn-version` | Specific Yarn version to install and activate (required when framework-type is 'backstage') | ✅ | string | No |

---

## Outputs

- This action does not produce outputs directly. It sets up the specified development frameworks on the runner environment.

---

## Jobs & Steps

- **Setup .NET Core**
- **Setup Node.js**
- **Enable Corepack**
- **Setup Yarn**
- **Setup Node for Backstage**

---

## Example Scenarios

- Install .NET Core for building and testing C# applications.
- Set up Node.js for Angular or JavaScript-based workflows.
- Prepare a mixed environment for projects that use both .NET and Node.js components.
- Prepare Backstage builds with Corepack/Yarn

---

## Best Practices 

- **Pin exact framework versions** to ensure consistent and reproducible builds.
- **Implement dependency caching** to speed up workflows and reduce redundant downloads.
- **Verify framework installation** before executing build or test steps to prevent failures.
- **Regularly update framework versions** to maintain security, stability, and compatibility.

---

## What The Action Does

This action uses conditional logic to install frameworks:

- If framework-type is dotnet, it uses actions/setup-dotnet@v4 with the specified version.
- If framework-type is angular or javascript, it uses actions/setup-node@v4 with the specified version.
- If framework-type is backstage, it enable corepack, yarn activate, setup-node with Yarn cache

---

## Changelog

All notable changes to this project will be documented in this section.

[v1.1.1] - 2026-02-03
- Added Backstage support
- Added Corepack + Yarn activation
- Organized by framework type

[v1] - 2025-06-09
Tags: Grouped or organized by framework type

---

## Repository 

GITHUB: `BHGitOps/action-setup-framework`
