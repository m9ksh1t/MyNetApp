## Download and Extract Artifact Action

This GitHub Action **downloads a build artifact from a previous workflow step and extracts its contents for use in subsequent jobs.** It supports .NET projects by automatically extracting tar archives to restore file permissions.

---

## Features

- Downloads artifacts using actions/download-artifact.
- Extracts tar archives for .NET projects to preserve file permissions.
- Allows specifying a custom download path.

---

## Usage

**Current Version:** `v1`

To use this action to download and extract artifacts:

```yml
runs:
  using: "composite"
  steps:
    - name: Download Artifact
    
    - name: Unzip the Tar to Get Raw Files

```
---

## Inputs

| Name | Description | Required | Type | Default |Is Sensitive? |
|------|-------------|----------|---------|----------|--------------|
| `artifact-name` | Artifact name | ✅ | string | None | No |
| `framework-type` | Type of framework used to build and deploy code | ❌ | string | None | No |
| `artifact-download-path` | Path to the downloaded artifact file to be deleted after use | ❌ | string | '.' | No |

---

## Outputs

- This action does not produce explicit outputs.
- It makes the downloaded and extracted files available for subsequent steps.

---

## Jobs & Steps

- **Download Artifact**
    - Uses actions/download-artifact@v4 to retrieve the specified artifact.
- **Extract Tar Archive**
    - For .NET projects, extracts output.tar to restore original file structure and permissions.

---

## Example Scenarios

- Download and extract .NET build output for packaging or deployment.
- Retrieve Angular build artifacts for deployment to a web server.
- Use in multi-job workflows where build and deploy steps are separated.

---

## Best Practices 

- **Use descriptive artifact names** when uploading to avoid confusion during download.
- **Clean up temporary files** after extraction if not needed.
- **Validate extracted contents** before deployment to ensure integrity.
- **Combine with caching** for dependencies to optimize build and deploy times.

---

## What The Action Does

This action:

- Downloads the specified artifact using actions/download-artifact.
- If the framework type is .NET, extracts output.tar to restore file permissions and structure.
- Leaves files ready for deployment or packaging.

---

## 📜Changelog

[v1.0.0] - 10-09-2025

Tags: Initial Release

	•	First stable release of the Download and Extract Artifact Action
	•	Supports running:
	•	downloads a build artifact and extracts its contents for use in subsequent jobs
	•	With --artifact-name, --framework-type and --artifact-download-path
	•	download and extracts artifacts

---

[v1] - 10-09-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-download-extract-artifact`