## Generate Kubernetes ConfigMap Action

This GitHub **Action creates a Kubernetes ConfigMap from either a JSON object of environment variables or a specified file**. It is useful for injecting non-sensitive configuration data into Kubernetes workloads during CI/CD pipelines.

---

## Features

- Supports two modes:
    - **From JSON variables**: Converts selected keys from a JSON object into ConfigMap entries.
    - **From file**: Creates ConfigMap from .env, .json, or generic files.
- Automatically detects file type and applies the correct kubectl flags.
- Applies the ConfigMap to the specified namespace using kubectl.

---

## Usage

**Current Version:** `v1`

To use this action to generate a ConfigMap:

```yml
runs:
  using: "composite"
  steps:
    - name: Generate and Apply ConfigMap

    - name: Create ConfigMap from file

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `vars-json` | Collection of environment variables in JSON format | ✅ | string | No |
| `vars-name` | Comma-separated list of environment variable names to be included in the Kubernetes ConfigMap | ✅ | string | No |
| `configmap-name` | Name of the ConfigMap to create | ✅ | string | No |
| `namespace` | Kubernetes namespace for deployment | ✅ | string | No |
| `configmap-file-path` | Path to the file containing variables for ConfigMap creation | ✅ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It creates a Kubernetes ConfigMap in the specified namespace

---

## Jobs & Steps

- **Generate and Apply ConfigMap**
    - Converts selected keys from a JSON object into files, creates a ConfigMap manifest, and applies it to the cluster
- **Create ConfigMap from file**
    - Detects file type (.env, .json, or generic) and creates a ConfigMap using the appropriate kubectl flags.

---

## Example Scenarios

- Inject application configuration into Kubernetes pods.
- Dynamically generate ConfigMaps from GitHub Actions environment variables.
- Use .env or .json files for configuration management in CI/CD pipelines.

---

## Best Practices 

- **Ensure kubectl and kubeconfig are configured** before running this action.
- **Validate namespace exists** before applying the ConfigMap.
- **Use descriptive ConfigMap names** for clarity.
- **Pin the action version** for stability (e.g., @v1).

---

## What The Action Does

This action:

- Detects whether to create ConfigMap from JSON or file.
- Generates ConfigMap manifest and applies it to the cluster.
- Handles .env, .json, or generic files intelligently.
- Cleans up temporary files after completion.

---

## 📜Changelog

[v1.0.0] - 10-06-2025

Tags: Initial Release

	•	First stable release of the Generate Kubernetes ConfigMap Action
	•	ConfigMap creation from JSON variables
	•	ConfigMap creation from files (.env, .json, generic)
	•	Namespace targeting

---

[v1] - 10-06-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-generate-configmap`