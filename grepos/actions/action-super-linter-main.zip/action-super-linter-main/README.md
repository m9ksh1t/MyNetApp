<h1 align="center">Super Linter Action</h1>

## Analyze, Lint and Validate

This GitHub Action runs GitHub Super Linter **to analyze and lint source code in a specified directory**. It helps maintain code quality and consistency across multiple languages by applying linting rules.

---

## Getting Started

Use the sections below to quickly understand what this action does and how to use it.

## Action Summary

The table below provides a concise overview of the GitHub Composite Action, including its name, versioning, supported cloud environments, and compatible technology stacks.

| Action Name | action-super-linter |
| :------| :-------------|
| **Latest Stable Version** | v2.0.0 |
| **Current Version** | v2.0.0 |
| **Cloud Environment** | Linux-only (runs on any GitHub-hosted Linux runner) |
| **Cloud Services** | N/A |
| **TechStacks** | Any technology stack requiring Super linter |

## Jobs & Steps

- **Run Super Linter**


## Features

- Runs GitHub Super Linter inside a Docker container.
- Supports filtering files or directories using include/exclude regex patterns.
- Allows custom linter configuration through rules file paths.
- Works locally within the GitHub Actions runner environment.

---

## Usage

**Current Version:** `v2`

To use this action to run the Super Linter on the runner environment

```yml
runs:
  using: "composite"
  steps:
    - name: Run Super Linter
      shell: bash
      run: |
```
---

## Inputs

| Name | Description | Required | type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `working-directory` | Repository subdirectory to lint. When set, the action uses this path as `DEFAULT_WORKSPACE`, so Super Linter runs relative to that subdirectory instead of the repository root. | ❌ | string | No |
| `linter-filter-regex-include` | pattern to include specific files or directories for linting | ❌ | string | No |
| `linter-filter-regex-exclude` | pattern to exclude specific files or directories for linting | ❌ | string | No |
| `linter-rules-config-path` | Path to custom configuration files for the linters | ❌ | string | No |
| `linter-default-branch` | Specifies the default branch to use as the base for linting and change detection | ❌ | string | No |
| `validate-all-codebase` | When set to true, runs linting and formatting against the entire repository instead of only changed files | ❌ | boolean | No |
| `codebase-types` | Codebase type selector. When set to any non-empty value, the action switches to codebase-type-specific validation behavior. | ❌ | string | No |

### `working-directory` Input

Use this input to run linting against a specific subdirectory in the repository.
If provided, it must be a **relative path inside the repository** and the directory must **already exist**.  
Absolute paths or paths that resolve outside the repo are not allowed.

If omitted, linting runs from the repository root.

 
### `codebase-types` Input
This input accepts a comma‑separated list of values, allowing multiple codebase types to be specified

#### ✅ Linters and Formatters Triggered per Codebase Type Input
| Value              | Meaning                                       |
|--------------------|-----------------------------------------------|
| `github-actions`   | actionlint                                    |
| `shell`            | shellcheck                                    |
| `dotnet`           | dotnet format analyzers, style, and whitespace|
| `angular`          | ESLint (linter), Prettier (formatter)         |
| `typescript`       | ESLint (linter), Prettier (formatter)         |
| `python`           | Pylint (linter), Black (formatter)            |

#### ✅ Default Behavior
- When the input is **empty**, the action uses its **default Super‑Linter behavior**.

---
## Outputs

| Name | Description | type | Is Sensitive? |
|------|-------------|---------|--------------|
| `lint-status` | Result of the lint run (pass or fail). This output indicates whether Super Linter completed successfully (pass) or detected issues (fail). | string | No |

 > [!NOTE]
 > Because `lint-status` contains a hyphen, reference it in GitHub Actions expressions using bracket notation:
 > - Step output: `${{ steps.<id>.outputs['lint-status'] }}`
 > - Job output: `${{ needs.<job>.outputs['lint-status'] }}`

---

## Usage Examples

#### Example 1: Single Codebase Type
```yaml
name: Lint .NET Codebase

on:
  pull_request:

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Run Super‑Linter for .NET
        uses: BHGitOps/action-super-linter@v2
        with:
          codebase-types: dotnet
```

#### Example 2: Multiple Codebase Types
```yaml
name: Lint Multi‑Language Repository

on:
  pull_request:

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Run Super‑Linter for Python and GitHub Actions
        uses: BHGitOps/action-super-linter@v2
        with:
          codebase-types: python,github-actions
```
---

## Example Scenarios

- Lint all JavaScript files in a project while excluding node_modules.
- Apply custom linting rules stored in .github/linters for multiple languages.
- Run Super Linter on a specific directory such as src for targeted analysis.

---

## Best Practices 

- Use regex filters to limit linting to relevant files and improve performance.
- Maintain custom linter configuration files in version control for consistency.
- Run Super Linter as part of pull request workflows to enforce code quality.
- Keep the Super Linter Docker image updated to ensure latest rules and fixes.

---

## What The Action Does

This action uses Docker to run GitHub Super Linter:

- Pulls the super-linter image from the GitHub Container Registry.
- Mounts the specified working directory into the container.
- Applies include/exclude filters and custom configuration paths.
- Executes linting checks locally and outputs results in the workflow logs.

---

## 📜Changelog

All notable changes to this project will be documented in this section.

[v2] - 2025-07-18
Tags: Major Update, Breaking Changes

[v1] - 2025-02-18
Tags: Migration of super linter action, Breaking Changes

---

## Feedback/Need Help? 📬

If you have any questions or need assistance, don't hesitate to reach out to your team lead or the Platform Engineering support team. We're here to help you succeed!
