## Container Registry Login (ECR) Action

This GitHub Action **logs into an AWS Elastic Container Registry (ECR)** using AWS CLI and Docker. It enables workflows to push or pull container images from ECR securely.

---

## Features

- Authenticates to AWS ECR using aws ecr get-login-password.
- Performs Docker login for the specified AWS account and region.
- Prepares the environment for image push/pull operations.

---

## Usage

**Current Version:** `v1`

To use this action for ECR login:

```yml
runs:
  using: "composite"
  steps:
    - name: Log into AWS ECR

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `aws-region` | AWS Region where ecr is located | ❌ | string | No |
| `aws-account-id` | AWS account id where container registry is located | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It ensures Docker is authenticated to the specified ECR registry.

---

## Jobs & Steps

- **Log into AWS ECR**
    - Uses AWS CLI to retrieve a login password and authenticates Docker to the ECR registry for the given account and region.

---

## Example Scenarios

- Authenticate before running container scans or promotions.
- Prepare for image signing or verification workflows.
- Enable secure access for deployment steps that reference ECR-hosted images.

---

## Best Practices 

- **Run AWS Configure Action first** to set up credentials before login.
- **Use least-privilege IAM roles** with ecr:GetAuthorizationToken permissions.
- **Pin the action version** for stability.
- **Combine with build and push steps** for complete CI/CD workflows.

---

## What The Action Does

This action:

- Executes aws ecr get-login-password to retrieve an authentication token.
- Pipes the token to docker login for secure authentication.
- Enables subsequent steps to interact with ECR repositories.

---

## 📜Changelog

[v1.0.0] - 04-04-2025

Tags: Initial Release

	•	First stable release of the Container Registry Login (ECR) Action
	•	AWS ECR login via AWS CLI
	•	With --aws-region and --aws-account-id

---

[v1] - 04-04-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-ecr-login`