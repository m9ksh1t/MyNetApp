# Generate GitHub App Installation Token

This GitHub Action generates a **GitHub App installation token** that can be used to **access private repositories or submodules in your workflows**. It is useful for scenarios where you need authenticated access to repositories without using personal access tokens (PATs).

---

## Action Name
`Generate GitHub App Installation Token`

---

## Features:

- Securely generates a GitHub App installation token.
- Supports specifying multiple repositories for access.
- Ideal for workflows involving private repositories or Git submodules.

---

## Usage

**Current Version:** `v1`

To use this action for GitHub App Installation Token:

```yaml
runs:
 using: 'composite'
steps:
  - name: Get GitHub App Installation Token
    id: app-token
    uses: actions/create-github-app-token@v2
    with:
      app-id: ${{ inputs.gh-app-id }}
      private-key: ${{ inputs.gh-app-private-key }}
      owner: ${{ inputs.repositories-owner }}
      repositories: ${{ inputs.repositories }}
```
---

## Inputs:

| Name | Description | Required | type |
|------|-------------|----------|---------|
| `gh-app-id` | GitHub App ID used for authentication and token generation | ✅ | string |
| `gh-app-private-key` | Private key for the GitHub App, used to authenticate and generate the token | ✅ | string |
| `repositories-owner` | GitHub organization or user that owns the repositories | ❌ | `BHGitOps` |
| `repositories` | Comma-separated list of repositories requiring access (e.g., `repo1,repo2,repo3`) | ❌ | string |

---

## Outputs : 

| Name | Description |
|------|-------------|
| `gh-app-token` | GitHub App installation token generated for accessing private repositories |

---

## Jobs & Steps
- **Get GitHub App Installation Token**

---

## Example Scenarios

- Access Private Submodules: Use the generated token to securely fetch private submodules during workflow execution.
- Multi-Repo Workflows: Dynamically generate tokens to access multiple private repositories in CI/CD pipelines.
- Automated Release Process: Create short-lived tokens during release workflows to avoid storing long-lived PATs.

---

## Best Practices 

- Store Secrets Securely: Always keep gh-app-private-key and gh-app-id in GitHub Actions secrets.
- Limit Repository Scope: Only include repositories that are necessary for the workflow.
- Rotate Private Key: Regularly rotate your GitHub App private key for enhanced security.
- Short-Lived Tokens: Rely on the temporary nature of installation tokens instead of creating long-lived credentials.

---

## How It Works :

This action uses the official actions/create-github-app-token to generate a temporary installation token for your GitHub App.

`Here’s the basic flow` :

- You provide your GitHub App ID and private key (stored securely as secrets).
- The action authenticates as your GitHub App and requests an installation token.
- The token is scoped to the repositories you specify and is valid for a short time (usually 1 hour).

`You can use this token in later steps to` :

- Clone private repositories
- Access private submodules
- Perform authenticated API calls without using a personal access token (PAT).

## Repository

GITHUB: `BHGitOps/action-generate-github-app-token`