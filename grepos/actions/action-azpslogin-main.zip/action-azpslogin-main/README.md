## Azure Login Action

This GitHub Action **logs into Azure using a Service Principal and updates the session for subsequent** Azure CLI or PowerShell commands. It is useful for workflows that need to interact with Azure resources such as AKS, Key Vault, or Storage accounts.

---

## Features

- Authenticates to Azure using azure/login@v2.
- Supports Service Principal credentials (client-id, tenant-id, subscription-id).
- Enables Azure PowerShell session for advanced scripting.
---

## Usage

**Current Version:** `v1`

To use this action to log in to Azure:

```yml
runs:
  using: "composite"
  steps:
    - name: Azure login

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `client-id` | client id to login to Azure | ✅ | string | Yes |
| `tenant-id` | tenant id to login to Azure | ✅ | string | No |
| `subscription-id` | subscription id to login to Azure | ✅ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- Establishes an authenticated Azure session for subsequent steps.

---

## Jobs & Steps

- **Azure login**
    - Uses azure/login@v3 to authenticate with Azure.
    - Enables Azure PowerShell session for advanced scripting.

---

## Example Scenarios

- Authenticate before deploying resources to Azure.
- Prepare Azure session for running az CLI commands.
- Enable PowerShell scripts for Azure resource management.

---

## Best Practices 

- **Store credentials securely** in GitHub Secrets.
- **Use least privilege Service Principal** for authentication.
- **Pin the action version** for stability (e.g., @v1).

---

## What The Action Does

This action:

- Logs into Azure using Service Principal credentials.
- Updates the session for Azure CLI and PowerShell commands.
- Enables secure automation in CI/CD workflows.

---

## 📜Changelog

[v1.0.0] - 02-11-2025

Tags: Initial Release

	•	First stable release of Azure Login Action
	•	Supports Service Principal authentication
    •	Enables Azure PowerShell session

---

[v1] - 02-11-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-azpslogin`

---

## 📬 Need Help?

If you have any questions or need assistance, feel free to reach out to DevSecOps.

---

This workflow is maintained by the Banner Health DevSecOps Platform Team.
