## Configure NuGet Package Source Action

This GitHub Action **configures a NuGet package source for either GitHub Packages or Azure Artifacts**. It supports authentication using **GitHub tokens or Azure DevOps Personal Access Tokens (PATs)**, enabling secure access to private package feeds.

---

## Features

- Adds a NuGet source for GitHub Packages or Azure Artifacts.
- Supports authentication for private feeds using tokens.
- Allows custom naming for NuGet sources.

---

## Usage

**Current Version:** `v1`

To configure a NuGet source for GitHub Packages or Azure Artifacts:

```yml
runs:
 using: 'composite'
 steps:
   - name: Configure NuGet Source for GitHub Packages

   - name: Add NuGet Source to Azure Artifacts

```
---

## Inputs


| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `package-source-org` | The GitHub organization that hosts the NuGet package source | ✅ | string | No |
| `github-token` | GitHub token used for authentication when accessing GitHub Packages | ✅ | string | Yes |
| `package-source` | The source of the NuGet package. Accepted values: "github" or "azure-artifacts" | ✅ | string | No |
| `azure-org` | Azure DevOps organization name (required if using Azure Artifacts) | ❌ | string | No |
| `azure-feed` | Name of the Azure Artifacts feed (required if using Azure Artifacts) | ❌ | string | No |
| `azure-pat` | Azure DevOps Personal Access Token for authentication (required if using Azure Artifacts) | ❌ | string | Yes |
| `package-source-name` | Custom alias to assign to the NuGet source | ❌ | string | No |
| `azure-user-name` | Username for Azure DevOps authentication. (e.g., Azure DevOps) | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It configures NuGet sources for secure package retrieval.

---

## Jobs & Steps

- **Configure NuGet Source for GitHub Packages**
- **Configure NuGet Source for Azure Artifacts**

---

## Example Scenarios

- Add GitHub Packages as a NuGet source for private .NET libraries.
- Configure Azure Artifacts feed for enterprise .NET projects.
- Use custom source names for better organization in multi-feed environments.

---

## Best Practices

- **Use GitHub Secrets** for **github-token** and **azure-pat** to protect sensitive credentials.
- **Validate source configuration** by running **dotnet nuget list source** after setup.
- **Restrict PAT permissions** to follow least privilege principle.
- **Rotate tokens regularly** for security compliance.

---

## What The Action Does

This action:

- Adds a NuGet source for GitHub Packages using dotnet nuget add source with GitHub token authentication.
- Adds a NuGet source for Azure Artifacts using dotnet nuget add source with Azure DevOps PAT authentication.
- Stores credentials in clear text for compatibility with NuGet CLI (ensure runner security).

---

## Changelog

All notable changes to this project will be documented in this section.

[v1] - 2025-06-06

Tags: Initial release with GitHub Packages and Azure Artifacts support.

## Repository

GITHUB: `BHGitOps/action-configure-nuget-source`