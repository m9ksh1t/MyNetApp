## Pull Container Image Action

This GitHub Action **pulls a container image from AWS Elastic Container Registry (ECR)**. It is useful for workflows that need to retrieve pre-built images for deployment, testing, or scanning.

---

## Features

- Pulls a Docker image from AWS ECR using the specified repository and tag.
- Supports custom AWS account ID, region, and repository name.
- Works with authenticated Docker sessions (requires prior ECR login).

---

## Usage

**Current Version:** `v1`

To use this action to pull a container image from ECR:

```yml
runs:
  using: "composite"
  steps:
    - name: Pull Image from AWS ECR

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `aws-account-id` | AWS account id where container registry is located | ❌ | string | No |
| `aws-region` | AWS Region where ecr is located | ❌ | string | No |
| `container-repository` | Container repository name | ❌ | string | No |
| `image-tag` | Image tag name to use for the container image (e.g. latest) | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It ensures the specified Docker image is pulled and available locally.

---

## Jobs & Steps

- **Pull Image from AWS ECR**
    - Executes docker pull to retrieve the specified image from ECR using the provided account ID, region, repository name, and tag.

---

## Example Scenarios

- Pull a production-ready image for deployment in ECS or EKS.
- Retrieve an image for vulnerability scanning or SBOM generation.
- Use pre-built images for integration or performance testing.

---

## Best Practices 

- **Authenticate to ECR first** using the Container Registry Login (ECR) Action.
- **Use descriptive tags** for clarity (e.g., app:v1.0.0).
- **Pin the action version** for stability (e.g., @v1).
- **Combine with deployment steps** for a complete CI/CD workflow.

---

## What The Action Does

This action:

- Executes docker pull to download the specified image from AWS ECR.
- Uses the provided AWS account ID, region, repository name, and image tag to construct the full image URI.

---

## 📜Changelog

[v1.0.0] - 04-02-2025

Tags: Initial Release

    • First stable release of the Pull Container Image Action
    • Pulling Docker images from AWS ECR
    • Custom image tags and repository names
    • With --aws-region, --aws-account-id, --container-repository and --image-tag
---

[v1] - 04-02-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-ecr-pull`