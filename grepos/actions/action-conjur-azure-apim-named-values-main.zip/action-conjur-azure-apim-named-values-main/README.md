# [Action Name]

---

## Action usage and description
Action Description

---

## Features

- Feature 1 (List out all the features of this action.)
- Feature 2
- Feature 3

---

## Usage

**Latest Stable/Current Version:** `v1` (or `v2`, etc.)
To use this workflow in your repository:

#### Example: What this workflow does
```yaml
- name: Step/Job Name
  uses: <ORG>/<action-name>@<version number>
  with:
    [input-name]: "[value]"
    [input-name]: "[value]"
```

---

### Inputs

| Name              | Description                                                            | Required | Type   | Is Sensitive? | Default |
|-------------------|------------------------------------------------------------------------|----------|--------|------------------|--------|
| `Input Name 1` | Detailed description of the Input 1                   | ❌ | string | No  | - |
| `Input Name 2` | Detailed description of the Input 2                   | ✅ | string | Yes | - |
| `Input Name 3` | Detailed description of the Input 2                   | ✅ | string | Yes | - |


### 🔒 Input Rules

- `Input Name 1` and `Input Name 2` are required for <action>.

- List out all possible values for the parameter

---

### What the Action Does

**1. List out all the points that this action does**

**2. List out all the points that this action does**

Insert code if required:
```yaml
insert few line of code here if required
```

---

### Example Scenarios
- Example Scenarios 1
- Example Scenarios 2

---

### Best Practices
- Best Practices 1 **For Bold**
- Best Practices 1

---

## 📜 Changelog
All notable changes to this project will be documented in this section.


### [v2] - yyyy-MM-dd 
**Tags:** Breaking Changes 
- **Added:** Inputs 3 added for <description>
- **Changed:** Code enhanced to validate this inputs

 
### [v1] - yyyy-MM-dd 
**Tags:** Major Update, Breaking Changes 
- **Changed:** Code enhanced to validate this inputs

---

### Repository
**GitHub**: `BHGitOps/action-name`
