## APIM Attach API to Product Action

This GitHub Action **attaches an API to a Product in Azure API Management (APIM) using the** Azure CLI. Associating APIs with Products enables access control, subscription requirements, and packaging APIs into logical groups—commonly used for API lifecycle management and publishing workflows.

---

## Features

- Attaches an API to a specified APIM Product.
- Uses Azure CLI for secure, reliable interaction with APIM.
- Supports automation in CI/CD pipelines.
- Fails fast if required inputs are missing.
- Lightweight and suitable for deployment, publishing, and API onboarding workflows.

---

## Usage

**Current Version:** `v1`

To use this action to attach an API to a Product:

```yml
runs:
  using: "composite"
  steps:
    - name: Attach API to a Product

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `apim-resource-group` | Resource group of the Azure APIM | ✅ | string | No |
| `apim-service-name` | service name of the APIM | ✅ | string | No |
| `apim-api-id` | specify the api id | ✅ | string | No |
| `apim-product-id` | Product ID | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- Action logs will clearly indicate success or failure of the API‑Product association.

---

## Jobs & Steps

- **Attach API to a Product**
    - Executes the Azure CLI command.
    - Maps the API ID to the selected Product inside APIM
    - Uses resource group and service name parameters to locate APIM instance
    - Logs completion and error details when applicable.
---

## Example Scenarios

- Publish an API into a public or private Product.
- Automate the API onboarding process into APIM.
- Attach APIs to versioned Products (e.g., starter, premium).
- CI pipelines where API specification updates require re‑attaching to a Product.
- Promote APIs into test or production Products during multi‑stage deployments.

---

## Best Practices 

- **Ensure the Product exists before** attaching APIs.
- **Use consistent API IDs across environments** for predictable deployment.
- Combine with **APIM import, product creation, and policy actions** for full automation.
- Run after **any API update or API versioning steps to ensure association** is preserved.
- **Pin the action version** for stability (e.g., @v1).

---

## What The Action Does

This action:

- Connects to an Azure API Management instance via Azure CLI.
- Attaches an API to the specified APIM Product.
- Throws Azure CLI errors directly for easy troubleshooting.
- Supports automation for CI/CD and API lifecycle management.

---

## 📜Changelog

[v1.0.0] - 02-25-2025

Tags: Initial Release

	•	First stable release of APIM Attach API to Product Action. 
	•	Supports API‑Product association using Azure CLI.
    •	Optimized for CI/CD workflows and automated API onboarding.

---

[v1] - 02-25-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-azure-apim-attach-api-to-product`

---

## 📬 Need Help?

If you have any questions or need assistance, feel free to reach out to DevSecOps.

---

This workflow is maintained by the Banner Health DevSecOps Platform Team.