## CyberArk Conjur Secret Fetcher Action

This GitHub Action **securely fetches secrets from CyberArk Conjur using API key authentication** and makes them available as environment variables and a JSON file for subsequent workflow steps.

---

## Features

- Authenticates with CyberArk Conjur using Host ID and API key.
- Fetches multiple secrets from Conjur based on provided variable paths.
- Masks secrets in logs for security.
- Exports secrets as:
    - Environment variables for immediate use.
    - JSON file for structured access in later steps.
---

## Usage

**Current Version:** `v2`

To use this action to fetch secrets from CyberArk Conjur:

```yml
runs:
  using: "composite"
  steps:
    - name: Fetch secrets from Conjur Cloud

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `conjur_appliance_url` | URL path to the CyberArk Conjur instance endpoint | ✅ | string | No |
| `conjur_account` | Account configured for the Conjur instance during deployment | ✅ | string | No |
| `conjur_workload_id` | Host ID granted to your application by Conjur when created via policy | ✅ | string | No |
| `conjur_api_key` | API key for authenticating with the Conjur instance | ✅ | string | Yes |
| `conjur_variable_path` | List of secret variable paths to fetch from Conjur, separated by semicolons | ✅ | string | No |

---

## Outputs

- **Environment Variables**: Each secret is exported as an environment variable using the provided VAR_NAME.
- **JSON File**: A file named secrets-json containing all fetched secrets in JSON format. Path exported as secrets-json in GitHub environment.

---

## Jobs & Steps

- **Authenticate with Conjur**
    - Uses API key and Host ID to obtain an authentication token.
- **Fetch Secrets**
    - Retrieves secrets from Conjur using the token and variable paths.
- **Export Secrets**
    - Masks secrets in logs, sets them as environment variables, and writes them to a JSON file.

---

## Example Scenarios

- Fetch database credentials and API keys from Conjur for secure deployment.
- Load multiple secrets into environment variables for build or test jobs.
- Generate a JSON file for passing secrets to other actions or scripts.

---

## Best Practices 

- **Store API key in GitHub Secrets** to prevent exposure.
- **Validate variable paths** before running the action to avoid errors.
- **Mask sensitive data** in logs (already handled by this action).
- **Rotate API keys regularly** for security compliance.

---

## What The Action Does

This action:

- Authenticates with CyberArk Conjur using API key and Host ID.
- Fetches secrets from specified variable paths.
- Masks secrets in logs for security.
- Exports secrets as environment variables and a JSON file for downstream steps.

---

## 📜Changelog

[v2.0.0] - 12-02-2025

Tags: Second Release

	•	Second stable release of the CyberArk Conjur Secret Fetcher Action
	•	Securely fetches secrets from CyberArk Conjur using API key authentication 
	•	With --conjur_appliance_url, --conjur_account, --conjur_workload_id, --conjur_api_key  and --conjur_variable_path

---

[v2] - 12-02-2025

Tags: Release Alias

	•	v2 is a moving tag pointing to the latest stable v2.x.x version (currently v2.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-cyberark-conjur-secret-fetcher`