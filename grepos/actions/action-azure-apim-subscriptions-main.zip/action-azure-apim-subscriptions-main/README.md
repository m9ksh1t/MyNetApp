## APIM Subscription Management

This GitHub Action **creates, cancels, or deletes subscriptions in Azure API Management (APIM)** using Azure REST API. It supports bulk operations from a JSON file and includes a dry-run mode for safe previews.

---

## Features

- Create new subscriptions for a specified product.
- Cancel subscriptions (soft delete) without removing them permanently.
- Delete subscriptions permanently from APIM.
- Supports bulk operations via JSON file.
- Includes dry-run mode for previewing deletions without executing them.
- Automatically resolves APIM user IDs from email addresses.

---

## Usage

**Current Version:** `v3`

To use this action to manage subscriptions in APIM:

```yml
runs:
  using: "composite"
  steps:
    - name: Process Subscriptions

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `apim-subscription-id` | Azure subscription ID | ✅ | string | No |
| `apim-resource-group` | Resource group name | ✅ | string | No |
| `apim-service-name` | APIM service name | ✅ | string | No |
| `apim-product-id` | Product ID | ✅ | string | No |
| `apim-subscriptions-file-path` | Path to the JSON file with an array of subscription objects, each containing a subscription_name, owner, action ("create", "cancel", or "delete"), and display_name | ❌ | string | No |
| `apim-dry-run` | Preview mode (true/false) | ❌ | boolean | No |
| `api-version` | APIM management API version | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- Logs summary of operations: Total, Success, Failed, Skipped, and breakdown by action type.

---

## Jobs & Steps

- **Process Subscriptions**
    - Converts email addresses to APIM user IDs for subscription ownership.
    - Reads JSON file and performs create, cancel, or delete actions.
    - Tracks success and failure counts.
    - If no JSON file is provided, deletes all subscriptions for the specified product.
    - Supports dry-run mode for previewing deletions.
---

## Example Scenarios

- Create multiple subscriptions for a product using a JSON file.
- Cancel existing subscriptions without deleting them permanently.
- Delete all subscriptions for a product during cleanup.
- Preview deletions using dry-run mode before executing.

---

## Best Practices 

- **Ensure Azure CLI and REST API access** before running this action.
- **Validate JSON structure for subscription objects** before execution.
- **Use dry-run mode for safe previews** before bulk deletion.
- **Combine with Azure Login Action** for authentication.
- **Pin the action version** for stability (e.g., @v3).

---

## What The Action Does

This action:

- Connects to the specified APIM instance.
- Creates, cancels, or deletes subscriptions based on configuration.
- Supports bulk operations and dry-run previews.
- Resolves APIM user IDs automatically from email addresses.

---

## 📜Changelog

[v3.0.0] - 11-11-2025

Tags: Third Release

	•	Third stable release of APIM Subscription Management action.
	•	Supports create, cancel, and delete operations.
    •	Handles bulk operations via JSON file and dry-run mode.

---

[v3] - 11-11-2025

Tags: Release Alias

	•	v3 is a moving tag pointing to the latest stable v3.x.x version (currently v3.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-azure-apim-subscriptions`

---

## 📬 Need Help?

If you have any questions or need assistance, feel free to reach out to DevSecOps.

---

This workflow is maintained by the Banner Health DevSecOps Platform Team.