## Authenticate EKS Action

This GitHub Action **updates the kubeconfig to authenticate with an Amazon EKS cluster**. It enables workflows to interact with Kubernetes clusters hosted on AWS EKS using kubectl.

---

## Features

- Configures kubeconfig for the specified EKS cluster.
- Uses AWS CLI to authenticate and set up cluster access.
- Prepares the runner for Kubernetes operations like kubectl apply, kubectl get pods, etc.

---

## Usage

**Current Version:** `v1`

To use this action to authenticate with EKS:

```yml
runs:
  using: "composite"
  steps:
    - name: Update kube config for EKS

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `aws-region` | AWS region where the EKS cluster is located | ✅ | string | No |
| `cluster-name` | Name of the EKS cluster | ✅ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It ensures kubeconfig is updated and kubectl can interact with the specified EKS cluster.

---

## Jobs & Steps

- **Update kube config for EKS**
    - Executes aws eks update-kubeconfig to authenticate and configure access to the specified EKS cluster.
---

## Example Scenarios

- Deploy Kubernetes manifests to an EKS cluster.
- Run integration tests against workloads in EKS.
- Automate cluster operations in CI/CD pipelines.

---

## Best Practices 

- **Run AWS Configure Action first** to set up credentials before authentication.
- **Install kubectl** before this step using the Install Kubectl Action.
- **Use least-privilege IAM roles** with eks:DescribeCluster permissions.
- **Pin the action version** for stability (e.g., @v1).

---

## What The Action Does

This action:

- Calls aws eks update-kubeconfig with the provided cluster name and region.
- Updates kubeconfig so kubectl commands can target the EKS cluster.

---

## 📜Changelog

[v1.0.0] - 04-25-2025

Tags: Initial Release

	•	First stable release of the Authenticate EKS Action
	•	Updating kubeconfig for EKS clusters
	•	AWS-region and cluster-name inputs

---

[v1] - 04-25-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-authenticate-eks`