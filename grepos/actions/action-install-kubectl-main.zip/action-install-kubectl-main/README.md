## Install Kubectl Action

This GitHub Action **installs kubectl on the runner** if it is not already available. It ensures that Kubernetes CLI is ready for use in subsequent workflow steps.

---

## Features

- Checks if kubectl is already installed.
- Downloads and installs kubectl (Amazon EKS version or latest stable).
- Updates the system PATH for immediate use.

---

## Usage

**Current Version:** `v1`

To use this action to install kubectl:

```yml
runs:
  using: "composite"
  steps:
    - name: Download and install kubectl

```
---

## Inputs

- This action does not require any inputs.

---

## Outputs

- This action does not produce explicit outputs.
- It ensures kubectl is installed and available in the system PATH.

---

## Jobs & Steps

- **Download and install kubectl**
    - Checks if kubectl exists; if missing, downloads and installs the binary; updates $GITHUB_PATH for subsequent steps.

---

## Example Scenarios

- Prepare the runner for Kubernetes deployments.
- Use kubectl to apply manifests to EKS or other Kubernetes clusters.
- Combine with AWS CLI and kubeconfig setup for full cluster automation.

---

## Best Practices 

- **Run this step before any Kubernetes-related actions** to avoid missing CLI errors.
- **Pin the version of kubectl** for consistency across environments.
- **Combine with authentication steps** (e.g., AWS IAM Authenticator or kubeconfig setup).

---

## What The Action Does

This action:

- Verifies if kubectl is installed.
- Installs kubectl if missing (Amazon EKS version).
- Updates PATH for immediate use in subsequent steps.

---

## 📜Changelog

[v1.0.0] - 04-25-2025

Tags: Initial Release

	•	First stable release of the Install Kubectl Action
	•	Checking for existing installation
	•	Installing kubectl from Amazon EKS distribution
    •	Updating PATH for GitHub Actions runner

---

[v1] - 04-25-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-install-kubectl`