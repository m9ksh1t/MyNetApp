## Install Az Module Action

This GitHub Action **installs the required Azure PowerShell modules (Az.Accounts and Az.ApiManagement)** in the current environment. It is useful for workflows that need to manage Azure resources using PowerShell scripts.

---

## Features

- Installs **Az.Accounts** module for authentication and account management.
- Installs **Az.ApiManagement** module for managing Azure API Management resources.
- Uses PowerShell (pwsh) for module installation.
---

## Usage

**Current Version:** `v1`

To use this action to install Az modules:

```yml
runs:
  using: "composite"
  steps:
    - name: Install Az Module

```
---

## Inputs

- This action does not require any inputs.

---

## Outputs

- This action does not produce explicit outputs.
- Installs the specified Az modules in the current environment.

---

## Jobs & Steps

- **Install Az Module**
    - Installs **Az.Accounts and Az.ApiManagement** modules using PowerShell.
    - Ensures modules are available for subsequent steps in the workflow.

---

## Example Scenarios

- Prepare environment for Azure PowerShell scripts.
- Automate API Management tasks in CI/CD pipelines.
- Enable authentication and resource management in Azure.

---

## Best Practices 

- **Ensure PowerShell (pwsh) is available** on the runner.
- Combine with **Azure Login Action** for authenticated operations.
- **Pin the action version** for stability (e.g., @v1).

---

## What The Action Does

This action:

- Installs required Az modules from the PowerShell Gallery.
- Makes them available for subsequent PowerShell-based Azure operations.

---

## 📜Changelog

[v1.0.0] - 02-19-2025

Tags: Initial Release

	•	First stable release of Install Az Module Action
	•	Installs Az.Accounts and Az.ApiManagement modules

---

[v1] - 02-19-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-install-az-module`

---

## 📬 Need Help?

If you have any questions or need assistance, feel free to reach out to DevSecOps.

---

This workflow is maintained by the Banner Health DevSecOps Platform Team.