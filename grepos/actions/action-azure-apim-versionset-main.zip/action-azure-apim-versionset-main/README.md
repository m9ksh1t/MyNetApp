## Create API Version Set Action

This GitHub Action **creates or updates an API Version Set in Azure API Management (APIM)** using the Azure CLI. API Version Sets allow you to manage multiple versions of an API under a single logical grouping, enabling versioning strategies such as Segment, Query, or Header.

---

## Features

- Creates a new API Version Set or updates an existing one.
- Supports versioning schemes:
    - Segment – Version in the URL path.
    - Query – Version in a query parameter.
    - Header – Version in a custom header.
- Allows specifying display name, description, and versioning details.
- Uses Azure CLI for secure and declarative management.

---

## Usage

**Current Version:** `v1`

To use this action to create or update an API Version Set:

```yml
runs:
  using: "composite"
  steps:
    - name: Version set creation

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `apim-resource-group` | resource group of the azure resource | ✅ | string | No |
| `apim-service-name` | service name of the APIM | ✅ | string | No |
| `apim-version-set-display-name` | Required name of API Version Set | ✅ | string | No |
| `apim-version-set-versioning-scheme` | An value that determines where the API Version identifer will be located in a HTTP request. Possible values include: Segment, Query, Header | ✅ | string | No |
| `apim-api-version-set-id` | Describes the Version Set to be used with the API | ❌ | string | No |
| `apim-version-set-query-name` | Name of query parameter that indicates the API Version if versioningScheme is set to query | ❌ | string | No |
| `apim-version-set-header-name` | Name of header parameter that indicates the API Version if versioningScheme is set to header | ❌ | string | No |
| `apim-version-set-description` | Description of API Version Set | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- Creates or updates an API Version Set in the specified APIM instance.

---

## Jobs & Steps

- **Version set creation**
    - Checks if the API Version Set exists using az apim api versionset list.
    - If it exists:
        - Updates the version set with provided details.
    - If it does not exist:
        - Creates a new version set with the specified versioning scheme and parameters.  

---

## Example Scenarios

- Create a version set for APIs that support multiple versions.
- Update versioning strategy for existing APIs.
- Automate version set management during CI/CD deployments.

---

## Best Practices 

- **Ensure Azure CLI is installed and authenticated** before running this action.
- **Validate versioning scheme and related** parameters (query name or header name).
- **Combine with Azure Login Action** for authentication.
- **Pin the action version** for stability (e.g., @v1).

---

## What The Action Does

This action:

- Connects to the specified APIM instance.
- Creates or updates an API Version Set with the provided configuration.
- Supports versioning schemes: Segment, Query, Header.

---

## 📜Changelog

[v1.0.0] - 10-21-2025

Tags: Initial Release

	•	First stable release of Create API Version Set Action
	•	Supports create and update operations
    •	Handles versioning schemes and optional parameters

---

[v1] - 10-21-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-azure-apim-versionset`

---

## 📬 Need Help?

If you have any questions or need assistance, feel free to reach out to DevSecOps.

---

This workflow is maintained by the Banner Health DevSecOps Platform Team.