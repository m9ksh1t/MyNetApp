## Deploy API Policy Action

This GitHub Action **deploys policies to an Azure API Management (APIM) API or its operations** using Azure PowerShell. It supports applying a single policy to one operation or multiple policies across multiple operations in a single API.

---

## Features

- Apply operation-level policies to an API in APIM.
- Supports single operation or multiple operations deployment.
- Uses Azure PowerShell for secure and declarative policy management.
- Accepts XML policy files for APIM compliance.

---

## Usage

**Current Version:** `v2`

To use this action to deploy API operation-level policies:

```yml
runs:
  using: "composite"
  steps:
    - name: Apply API Operation-Level Policies

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `apim-resource-group` | Azure Resource Group containing the APIM instance | ❌ | string | No |
| `apim-service-name` | Name of the Azure API Management (APIM) service | ❌ | string | No |
| `apim-api-id` | Unique identifier of the API within APIM | ❌ | string | No |
| `apim-policy-source-file` | Path to the XML policy file for a single operation | ❌ | string | No |
| `apim-operation-id` | Operation ID within the API to apply the policy to | ❌ | string | No |
| `apim-policy-folder` | Directory containing multiple operation-level policy files named by operation ID | ❌ | string | No |
| `hasMultipleOperations` | Set to true to apply policies to multiple operations using files in the specified folder | ❌ | boolean | No |

---

## Outputs

- This action does not produce explicit outputs.
- Applies policies to one or multiple API operations in APIM.

---

## Jobs & Steps

- **Apply API Operation-Level Policies**
    - Creates an APIM context using New-AzApiManagementContext.
    - If hasMultipleOperations is true:
        - Iterates through all XML files in the specified folder.
        - Applies each policy to its corresponding operation based on file name.
    - If hasMultipleOperations is false:
        - Applies a single policy to the specified operation using the provided XML file.

---

## Example Scenarios

- Apply authentication policies to specific API operations.
- Enforce rate limits or quotas for selected operations.
- Automate operation-level policy deployment during CI/CD.

---

## Best Practices 

- **Ensure Azure PowerShell and Az modules are** installed before running this action.
- **Validate XML policy format** to avoid deployment errors.
- **Combine with Azure Login** Action for authentication.
- **Pin the action version** for stability (e.g., @v2).

---

## What The Action Does

This action:

- Connects to the specified APIM instance.
- Applies policies to one or multiple operations within an API.
- Uses Azure PowerShell for secure and declarative deployment.

---

## 📜Changelog

[v2.0.0] - 10-21-2025

Tags: Second Release

	•	Second stable release of Deploy API Policy Action
	•	Supports single and multiple operation-level policy deployment
    •	Handles XML-based policy files

---

[v2] - 10-21-2025

Tags: Release Alias

	•	v2 is a moving tag pointing to the latest stable v2.x.x version (currently v2.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-azure-apim-operation-policy-deploy`

---

## 📬 Need Help?

If you have any questions or need assistance, feel free to reach out to DevSecOps.

---

This workflow is maintained by the Banner Health DevSecOps Platform Team.