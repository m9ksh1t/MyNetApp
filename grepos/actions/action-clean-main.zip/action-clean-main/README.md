## Clean Action

This GitHub Action **cleans build artifacts for .NET or Angular projects before building the source code**. It ensures a fresh build environment by removing previously compiled files and temporary data.

---

## Features

- Cleans .NET projects using dotnet clean.
- Cleans Angular projects using npm run clean.
- Supports specifying a working directory and optional solution/project file.

---

## Usage

**Current Version:** `v1`

To use this action to clean your project:

```yml
runs:
 using: 'composite'
 steps:
   - name: Dotnet Clean

   - name: Angular Clean

```
---

## Inputs


| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `framework-type` | Type of framework used to build and deploy code | ❌ | string | No |
| `working-directory` | Working directory to clean | ✅ | string | No |
| `file-name-to-build` | Solution or project file that needs to be cleaned before build | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It cleans build artifacts for the specified framework.

---

## Jobs & Steps

- **Dotnet Clean**
- **Angular Clean**

---

## Example Scenarios

- Clean a .NET solution before running dotnet build.
- Clean Angular build artifacts before running npm run build.
- Use in CI/CD pipelines to ensure fresh builds and avoid stale artifacts.

---

## Best Practices

- Run clean before build to avoid conflicts with old artifacts.
- Validate clean scripts for Angular projects (ensure npm run clean exists in package.json).
- Combine with caching for dependencies to optimize build times.

---

## What The Action Does

This action:

- For .NET projects, runs dotnet clean on the specified file (solution or project).
- For Angular projects, runs npm run clean in the given working directory.
- Ensures a clean state for subsequent build steps.

---

## 📜Changelog

[v1.0.0] - 06-09-2025

Tags: Initial release with .NET and Angular clean support.

	•	First stable release to cleans build artifacts for .NET or Angular projects 
	•	Supports running:
	•	With --framework-type, --working-directory, and --file-name-to-build
	•	Validates --framework-type and --working-directory input
	•	cleans build artifacts for .NET or Angular projects

---

[v1] - 06-09-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository

GITHUB: `BHGitOps/action-clean`
