## Fetch Azure DevOps Access Token Action

This GitHub Action **retrieves an Azure DevOps access token using the Azure CLI and sets it as an environment variable for use in subsequent steps**. It is useful for workflows that need to interact with Azure DevOps REST APIs or services securely.

---

## Features

- Fetches an access token for Azure DevOps using Azure CLI.
- Sets the token as an environment variable (`AZURE_DEVOPS_ACCESSTOKEN`) for later steps.
- Supports specifying a custom resource ID or defaults to the Azure DevOps resource ID.

---

## Usage

**Current Version:** `v1`

To use this action to retrieve an Azure DevOps access token:

```yml
runs:
 using: 'composite'
 steps:
   - name: Retrieve Azure DevOps Access Token

```
---

## Inputs


| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `resource-id` | Application (client) ID or resource ID to use for Azure DevOps. If not provided, defaults to the Azure DevOps resource ID (`499b84ac-1321-427f-aa17-267ca6975798`). | ❌ | string | No |

---

## Outputs

- This action does not generate any direct outputs.
- Instead, it sets the following environment variable: AZURE_DEVOPS_ACCESSTOKEN – Contains the retrieved Azure DevOps access token.

---

## Jobs & Steps

- **Retrieve Azure DevOps Access Token**

---

## Example Scenarios

- Authenticate with Azure DevOps REST API for pipeline automation.
- Use the token to trigger builds or releases in Azure DevOps.
- Access Azure DevOps resources securely from GitHub Actions workflows.

---

## Best Practices

- Use GitHub Secrets for Azure CLI authentication (e.g., by running azure/login prior to this step).
- Ensure the token is successfully retrieved before using it in any API calls.
- Regularly rotate credentials to maintain security compliance.
- Apply the principle of least privilege by restricting the service principal’s permissions.

---

## What The Action Does

This action:

- Calls az account get-access-token with the specified resource ID (or default Azure DevOps resource ID).
- Extracts the accessToken value.
- Exports the token as AZURE_DEVOPS_ACCESSTOKEN in the GitHub Actions environment for subsequent steps.

---

## Changelog

All notable changes to this project will be documented in this section.

[v1] - 2025-06-20

Tags: Initial release with Azure DevOps token retrieval support.

## Repository

GITHUB: `BHGitOps/action-azure-devops-access-token`