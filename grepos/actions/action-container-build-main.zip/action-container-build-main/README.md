## Docker Build Action

This GitHub Action **builds a Docker image using a specified Dockerfile, image tag, and build context**. It supports custom Dockerfile paths and build contexts for flexible container image creation.

---

## Features

- Builds Docker images with a custom or default Dockerfile.
- Supports specifying:
    - Image tag (e.g., my-image:latest)
    - Build context (defaults to current directory)
    - Working directory for the build process.
- Uses docker build or docker buildx for efficient builds.

---

## Usage

**Current Version:** `v1`

To use this action to build a Docker image:

```yml
runs:
  using: "composite"
  steps:
    - name: Build Docker Image with Custom Dockerfile
    
    - name: Build Docker Image with Default Dockerfile

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `working-directory` | The directory from which the Docker build command should be run | ❌ | string | No |
| `image-tag` | The name and tag to assign to the built Docker image (e.g., my-image:latest) | ❌ | string | No |
| `docker-file-path` | The path to the Dockerfile to use for building the image. If not provided, the default Dockerfile in the context directory will be used | ❌ | string | No |
| `docker-build-context` | The path to the Docker build context. Defaults to the current directory if not specified | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It creates a Docker image tagged as specified in image-tag.

---

## Jobs & Steps

- **Build Docker Image with Custom Dockerfile**
    - Uses docker build with -f option for custom Dockerfile path.
- **Build Docker Image with Default Dockerfile**
    - Uses docker buildx build from the specified working directory.

---

## Example Scenarios

- Build a Docker image for a microservice using a custom Dockerfile.
- Use a specific build context for multi-stage builds.
- Build images for different environments by passing different tags.

---

## Best Practices 

- **Authenticate with Docker registry** before pushing images (e.g., docker/login-action).
- **Use caching** with docker buildx for faster builds.
- **Pin image tags** to avoid ambiguity (e.g., my-app:1.0.0 instead of latest).
- **Validate Dockerfile syntax** before running the build.

---

## What The Action Does

This action:

- Checks if a custom Dockerfile path is provided:
    - If yes, runs docker build with -f and specified context.
    - If no, runs docker buildx build using the default Dockerfile in the working directory.
- Tags the image with the provided image-tag.

---

## 📜Changelog

[v1.0.0] - 05-29-2025

Tags: Initial Release

	•	First stable release of the Docker Build Action
	•	Supports running:
	•	builds a Docker image using a specified Dockerfile, image tag, and build context
	•	With --working-directory, --image-tag, --docker-file-path,  and --docker-build-context
	•	Build Docker Image with tag

---

[v1] - 05-29-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-docker-build`