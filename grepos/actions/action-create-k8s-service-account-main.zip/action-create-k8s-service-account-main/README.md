## Provision Kubernetes Service Account Action

This GitHub Action **provisions a Kubernetes Service Account and annotates it with either an AWS IAM Role (for EKS) or an Azure Managed Identity Client ID (for AKS)**. It enables secure workload identity integration so pods can access cloud resources without embedding static credentials.

---

## Features

- Creates a Kubernetes Service Account in a specified namespace.
- Conditionally annotates the Service Account for:
    - EKS: eks.amazonaws.com/role-arn= IAM Role ARN
    - AKS: azure.workload.identity/client-id= Managed Identity Client ID
- Idempotent behavior - creation is skipped if the Service Account already exists.
- Verifies the provisioned Service Account at the end.

---

## Usage

**Current Version:** `v1`

To use this action to provision and annotate a Service Account:

```yml
runs:
  using: "composite"
  steps:
    - name: Provision Kubernetes Service Account

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `service-account-name` | Name of the Kubernetes service account to be created | ✅ | string | Yes |
| `namespace` | Kubernetes namespace where the service account will be created | ✅ | string | No |
| `service-account-role` | IAM role ARN to associate with the service account for EKS | ❌ | string | No |
| `service-account-client-id` | ClientID to associate with the service account for AKS | ❌ | string | No |

---

## Outputs

- This action does not produce explicit outputs.
- It creates (or verifies) a Kubernetes Service Account and, if provided, applies the appropriate cloud identity annotation.

---

## Jobs & Steps

- **Provision Kubernetes Service Account**
    - Creates the Service Account in the specified namespace; if service-account-role is provided, annotates with eks.amazonaws.com/role-arn; if service-account-client-id is provided, annotates with azure.workload.identity/client-id; finally, retrieves and prints the Service Account details.

---

## Example Scenarios

- **EKS IRSA setup**: Associate a pod with an AWS IAM Role for S3, DynamoDB, or other AWS services.
- **AKS Workload Identity**: Bind a pod to an Azure Managed Identity for accessing Key Vault, Storage, or other Azure services.
- **Multi-cloud pipelines**: Use conditional inputs to target EKS or AKS from a single action.
- **Deployment readiness**: Ensure the Service Account exists before applying workload manifests.

---

## Best Practices 

- **Install and configure kubectl and kubeconfig**: before running this action (e.g., using Install Kubectl + Authenticate EKS actions).
- **Namespace management**: Ensure the target namespace exists, or create it prior to this step.
- **Least privilege**: Grant minimal required permissions to IAM roles or Managed Identities.
- **Consistent naming**: Use descriptive Service Account names aligned with workload responsibilities.
- **Version pinning**: Pin this action version (e.g., @v1) in your workflows for stability.

---

## What The Action Does

This action:

- Creates a Kubernetes Service Account in the specified namespace (skipping if it already exists).
- Applies cloud-specific annotations:
    - eks.amazonaws.com/role-arn= IAM Role ARN for EKS (IRSA).
    - azure.workload.identity/client-id= Managed Identity Client ID for AKS (Workload Identity).
- Prints the Service Account details for verification.

---

## 📜Changelog

[v1.0.0] - 05-14-2025

Tags: Initial Release

	•	First stable release of the Provision Kubernetes Service Account Action
	•	Creation of Service Accounts
	•	EKS IAM Role annotation (eks.amazonaws.com/role-arn)
	•	AKS Managed Identity annotation (azure.workload.identity/client-id)

---

[v1] - 05-14-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-create-k8s-service-account`