## Upload Artifacts Action

This GitHub Action **uploads build artifacts to GitHub for later use in workflows or downloads**. It supports .NET and general projects, with special handling for .nupkg files and preserving file permissions.

---

## Features

- Uploads files, directories, or wildcard patterns as artifacts.
- Preserves file permissions for .NET builds by creating a tar archive.
- Supports conditional upload for .nupkg files.
- Allows custom artifact naming.

---

## Usage

**Current Version:** `v1`

To use this action to upload artifacts:

```yml
runs:
  using: "composite"
  steps:
    - name: Tar files to preserve file permissions

    - name: Upload .NET Artifacts

    - name: Upload General Artifacts
```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `build-artifacts` | A file, directory or wildcard pattern that describes what to upload | ❌ | string | No |
| `artifact-name` | Artifact name for the package to be published | ❌ | string | No |
| `framework-type` | Type of framework used to build and deploy code | ❌ | string | No |
| `publish-nupkg-file` | Boolean variable to publish/skip the nupkg file | ❌ | boolean | No |

---

## Outputs

- This action does not produce explicit outputs.
- It uploads artifacts to GitHub for later retrieval in workflows.

---

## Jobs & Steps

- **Tar files to preserve file permissions**
- **Upload .NET Artifacts**
- **Upload General Artifacts**

---

## Example Scenarios

- Upload .NET build output as a tar archive for deployment.
- Upload Angular build directory for packaging.
- Upload .nupkg files for publishing to NuGet feeds.

---

## Best Practices 

- **Use descriptive artifact names** for clarity in multi-job workflows.
- **Limit artifact size** by excluding unnecessary files to optimize upload/download times.
- **Secure sensitive files** by avoiding inclusion of secrets or credentials in artifacts.
- **Combine with caching** for dependencies to reduce build times.

---

## What The Action Does

This action:

- For .NET projects (when publish-nupkg-file is false):
    - Creates a tar archive of the build artifacts to preserve file permissions.
    - Uploads the tar archive using actions/upload-artifact@v4.
- For other frameworks or when publish-nupkg-file is true:
    - Uploads the specified files or directories directly.

---

## 📜Changelog

[v1.0.0] - 06-09-2025

Tags: Initial Release

	•	First stable release of the Action Upload Artifacts
	•	Supports running:
	•	uploads build artifacts to GitHub for later use in workflows or downloads
	•	With build-artifacts, artifact-name, framework-type, and publish-nupkg-file inputs

---

[v1] - 06-09-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-upload-artifacts`