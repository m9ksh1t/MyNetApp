## Get ECR or ACR Image Digest Action

This GitHub **Action fetches the container image digest from AWS ECR or Azure ACR without pulling the image**. It’s ideal for creating immutable image references (by digest) used in deployments, promotions, and security/scanning workflows.

---

## Features

- Retrieves image digest from AWS ECR or Azure ACR without docker pull.
- Constructs and exports a fully qualified image URI with digest (e.g., repo@sha256:...) to $GITHUB_ENV.
- Smart registry detection based on provided inputs (ECR when aws-region + aws-account-id are present; otherwise ACR when container-registry is provided).

---

## Usage

**Current Version:** `v1`

Use this action to get an image digest from either ECR or ACR:

```yml
runs:
  using: "composite"
  steps:
    - name: Get image digest from ECR or ACR

```
---

## Inputs

| Name | Description | Required | Type | Is Sensitive? |
|------|-------------|----------|---------|--------------|
| `aws-region` | AWS Region where ECR is located | ❌ | string | No |
| `aws-account-id` | AWS account id where container registry is located | ❌ | string | No |
| `container-repository` | Container repository name | ❌ | string | No |
| `container-registry` | Target Azure container registry name for ACR login | ❌ | string | No |
| `image-tag` | Image tag name to use for the container image (e.g.latest) | ✅ | string | No |

---

## Outputs

- Environment Variable: IMAGE_URI Fully qualified image URI with digest (e.g., 123456789012.dkr.ecr.us-east-1.amazonaws.com/my-app@sha256:... or myregistry.azurecr.io/my-app@sha256:...)
- Console Output: Retrieved digest: <sha256:...>

---

## Jobs & Steps

- **Get image digest from ECR or ACR**
    - Detects registry; if ECR, uses aws ecr describe-images; if ACR, uses az acr repository show-manifests; writes IMAGE_URI to $GITHUB_ENV.

---

## Example Scenarios

- **Immutable deployments**: Deploy with digest rather than tag to avoid tag drift.
- **Promotion pipelines**: Validate the digest in staging and reuse it in production.
- **Security/scanning**: Fetch digest for SBOM generation and vulnerability scans without pulling.
- **Cross-cloud workflows**: Single action supports both AWS ECR and Azure ACR.

---

## Best Practices 

- **Authenticate before running**:
	- ECR: Configure AWS credentials and permissions (ecr:DescribeImages).
	- ACR: az must be logged in; ensure read permissions (e.g., AcrPull).
- **Validate repository/tag exist** to prevent empty digest results.
- **Use least-privilege** access for registry read operations.
- **Pin action versions** and CLI tools for reproducibility.

---

## What The Action Does

This action:

- Determines target registry based on inputs (ECR vs ACR).
- Queries the registry manifest to extract the image digest.
- Builds a fully qualified image URI with digest and exports it via $GITHUB_ENV.

---

## 📜Changelog

[v1.0.0] - 10-06-2025

Tags: Initial Release

	•	First stable release of the Get ECR or ACR Image Digest Action
	•	Fetch image digest from AWS ECR or Azure ACR without pulling.
	•	Export IMAGE_URI to $GITHUB_ENV.
	•	Print retrieved digest to logs.

---

[v1] - 10-06-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-get-image-digest`