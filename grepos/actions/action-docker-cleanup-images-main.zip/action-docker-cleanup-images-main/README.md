## Docker Cleanup Utility Action

This GitHub Action **frees up disk space on the GitHub Actions runner by removing unused Docker resources, including images, containers, networks, and volumes**. It helps prevent disk space issues during workflows that involve Docker builds.

---

## Features

- Cleans up:
    - Unused Docker images
    - Stopped containers
    - Dangling volumes
    - Unused networks
- Uses docker system prune -af --volumes for a complete cleanup.

---

## Usage

**Current Version:** `v1`

To use this action to clean up Docker resources:

```yml
runs:
  using: "composite"
  steps:
    - name: Clean up Docker resources

```
---

## Inputs

- This action does not require any inputs.

---

## Outputs

- This action does not produce explicit outputs.
- It frees up disk space by removing unused Docker resources.

---

## Jobs & Steps

- **Clean up Docker resources**
    - Executes docker system prune -af --volumes to remove all unused Docker data.

---

## Example Scenarios

- After building and pushing Docker images to avoid disk space exhaustion.
- Before starting a new Docker build to ensure a clean environment.
- In workflows that run multiple Docker builds on the same runner.

---

## Best Practices 

- **Run this action after Docker builds** to reclaim space.
- **Avoid running during active builds** to prevent accidental removal of needed resources.
- **Combine with caching strategies** for dependencies to optimize performance.
- **Use in self-hosted runners** where disk space is limited.

---

## What The Action Does

This action:

- Executes docker system prune -af --volumes:
    - -a: Removes all unused images (not just dangling).
    - -f: Forces cleanup without confirmation.
    - --volumes: Removes unused volumes.
- Logs cleanup start and completion messages.

---

## 📜Changelog

[v1.0.0] - 07-24-2025

Tags: Initial Release

	•	First stable release of the Docker Cleanup Utility Action
	•	Frees up disk space on the GitHub Actions runner by removing unused Docker resources

---

[v1] - 07-24-2025

Tags: Release Alias

	•	v1 is a moving tag pointing to the latest stable v1.x.x version (currently v1.0.0)
	•	Allows referencing the action without pinning to a patch version

---

## Repository 

GITHUB: `BHGitOps/action-docker-cleanup-images`